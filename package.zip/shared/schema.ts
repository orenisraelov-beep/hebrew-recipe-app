import { pgTable, text, serial, integer, boolean, timestamp, jsonb, varchar, uniqueIndex } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { sql } from "drizzle-orm";

// === ADMINS ===
export const admins = pgTable("admins", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  role: text("role").notNull().default("admin"),
  active: boolean("active").notNull().default(true),
  forcePasswordChange: boolean("force_password_change").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertAdminSchema = createInsertSchema(admins).omit({
  id: true,
  createdAt: true,
});

export type Admin = typeof admins.$inferSelect;
export type InsertAdmin = z.infer<typeof insertAdminSchema>;
export type AdminSafe = Omit<Admin, "password">;

// === RECIPES ===
export const recipes = pgTable("recipes", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  ingredients: jsonb("ingredients").$type<string[]>().notNull(),
  preparation: jsonb("preparation").$type<string[]>().notNull(),
  imageUrl: text("image_url"),
  category: text("category").notNull(),
  tags: text("tags").array(),
  suitableDays: text("suitable_days").array(),
  suitableHolidays: text("suitable_holidays").array(),
  createdByAdminId: integer("created_by_admin_id"),
  preparationTime: integer("preparation_time"),
  totalTime: integer("total_time"),
  servings: integer("servings"),
  difficulty: text("difficulty"),
  origin: text("origin"),
  authorName: text("author_name"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertRecipeSchema = createInsertSchema(recipes).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type Recipe = typeof recipes.$inferSelect;
export type InsertRecipe = z.infer<typeof insertRecipeSchema>;
export type CreateRecipeRequest = InsertRecipe;
export type UpdateRecipeRequest = Partial<InsertRecipe>;

// === RECIPE IMAGES ===
export const recipeImages = pgTable("recipe_images", {
  id: serial("id").primaryKey(),
  recipeId: integer("recipe_id").notNull(),
  imagePath: text("image_path").notNull(),
  displayOrder: integer("display_order").notNull().default(0),
});

export const insertRecipeImageSchema = createInsertSchema(recipeImages).omit({ id: true });
export type RecipeImage = typeof recipeImages.$inferSelect;
export type InsertRecipeImage = z.infer<typeof insertRecipeImageSchema>;

// === RECIPE STEPS ===
export const recipeSteps = pgTable("recipe_steps", {
  id: serial("id").primaryKey(),
  recipeId: integer("recipe_id").notNull(),
  stepNumber: integer("step_number").notNull(),
  stepText: text("step_text").notNull(),
  stepImagePath: text("step_image_path"),
});

export const insertRecipeStepSchema = createInsertSchema(recipeSteps).omit({ id: true });
export type RecipeStep = typeof recipeSteps.$inferSelect;
export type InsertRecipeStep = z.infer<typeof insertRecipeStepSchema>;

// === INGREDIENT CATEGORIES ===
export const ingredientCategories = pgTable("ingredient_categories", {
  id: serial("id").primaryKey(),
  nameHebrew: text("name_hebrew").notNull().unique(),
});

export const insertIngredientCategorySchema = createInsertSchema(ingredientCategories).omit({ id: true });
export type IngredientCategory = typeof ingredientCategories.$inferSelect;
export type InsertIngredientCategory = z.infer<typeof insertIngredientCategorySchema>;

// === INGREDIENTS MASTER ===
export const ingredientsMaster = pgTable("ingredients_master", {
  id: serial("id").primaryKey(),
  nameHebrew: text("name_hebrew").notNull().unique(),
  categoryId: integer("category_id"),
  subcategory: text("subcategory"),
  displayOrder: integer("display_order").notNull().default(0),
});

export const insertIngredientMasterSchema = createInsertSchema(ingredientsMaster).omit({ id: true });
export type IngredientMaster = typeof ingredientsMaster.$inferSelect;
export type InsertIngredientMaster = z.infer<typeof insertIngredientMasterSchema>;

export interface IngredientMasterWithCategory extends IngredientMaster {
  categoryName?: string;
}

export interface IngredientCategoryWithIngredients extends IngredientCategory {
  ingredients: IngredientMaster[];
}

// === USER INGREDIENTS (selected per device) ===
export const userIngredients = pgTable("user_ingredients", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  ingredientId: integer("ingredient_id").notNull(),
});

export const insertUserIngredientSchema = createInsertSchema(userIngredients).omit({ id: true });
export type UserIngredient = typeof userIngredients.$inferSelect;

// === RECIPE INGREDIENTS ===
export const recipeIngredients = pgTable("recipe_ingredients", {
  id: serial("id").primaryKey(),
  recipeId: integer("recipe_id").notNull(),
  ingredientName: text("ingredient_name").notNull(),
  quantity: text("quantity"),
  unit: text("unit"),
  ingredientId: integer("ingredient_id"),
});

export const insertRecipeIngredientSchema = createInsertSchema(recipeIngredients).omit({ id: true });
export type RecipeIngredient = typeof recipeIngredients.$inferSelect;
export type InsertRecipeIngredient = z.infer<typeof insertRecipeIngredientSchema>;

// === USER FAVORITES ===
export const userFavorites = pgTable("user_favorites", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  recipeId: integer("recipe_id").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserFavoriteSchema = createInsertSchema(userFavorites).omit({ id: true, createdAt: true });
export type UserFavorite = typeof userFavorites.$inferSelect;
export type InsertUserFavorite = z.infer<typeof insertUserFavoriteSchema>;

// === SHOPPING LIST ===
export const shoppingListItems = pgTable("shopping_list_items", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  ingredientName: text("ingredient_name").notNull(),
  quantity: text("quantity"),
  unit: text("unit"),
  recipeTitle: text("recipe_title"),
  completed: boolean("completed").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertShoppingListItemSchema = createInsertSchema(shoppingListItems).omit({ id: true, createdAt: true });
export type ShoppingListItem = typeof shoppingListItems.$inferSelect;
export type InsertShoppingListItem = z.infer<typeof insertShoppingListItemSchema>;

// === RECIPE RATINGS ===
export const recipeRatings = pgTable("recipe_ratings", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  recipeId: integer("recipe_id").notNull(),
  rating: integer("rating").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => [
  uniqueIndex("recipe_ratings_user_recipe_idx").on(table.userId, table.recipeId),
]);

export const insertRecipeRatingSchema = createInsertSchema(recipeRatings).omit({ id: true, createdAt: true });
export type RecipeRating = typeof recipeRatings.$inferSelect;
export type InsertRecipeRating = z.infer<typeof insertRecipeRatingSchema>;

// === MEAL PLANS ===
export const mealPlans = pgTable("meal_plans", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  dayOfWeek: text("day_of_week").notNull(),
  recipeId: integer("recipe_id").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertMealPlanSchema = createInsertSchema(mealPlans).omit({ id: true, createdAt: true });
export type MealPlan = typeof mealPlans.$inferSelect;
export type InsertMealPlan = z.infer<typeof insertMealPlanSchema>;

// === QUERY / RESPONSE TYPES ===
export interface RecipeQueryParams {
  search?: string;
  category?: string;
  tag?: string;
  difficulty?: string;
  origin?: string;
  maxPrepTime?: number;
  maxTotalTime?: number;
  ingredients?: string;
  ingredientIds?: string;
  author?: string;
}

export interface RecipeWithAdmin extends Recipe {
  createdByAdmin?: string;
  images?: RecipeImage[];
  averageRating?: number;
  ratingCount?: number;
}

export interface RecipeFull extends RecipeWithAdmin {
  images: RecipeImage[];
  steps: RecipeStep[];
  structuredIngredients: RecipeIngredient[];
  userRating?: number;
}

export const DIFFICULTY_OPTIONS = ["קל", "בינוני", "קשה", "מומחה"] as const;
export const ORIGIN_OPTIONS = ["מרוקאי", "תימני", "אשכנזי", "איטלקי", "ישראלי", "ערבי", "הודי", "פרסי", "אתיופי"] as const;
export const UNIT_OPTIONS = ["גרם", "ק\"ג", "מ\"ל", "ליטר", "כף", "כפית", "כוס", "יחידה"] as const;
export const DAYS_OF_WEEK = ["ראשון", "שני", "שלישי", "רביעי", "חמישי", "שישי", "שבת"] as const;
