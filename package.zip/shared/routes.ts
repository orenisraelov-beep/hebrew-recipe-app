import { z } from 'zod';
import { insertRecipeSchema, insertAdminSchema } from './schema';

export const errorSchemas = {
  validation: z.object({ message: z.string(), field: z.string().optional() }),
  notFound: z.object({ message: z.string() }),
  internal: z.object({ message: z.string() }),
  unauthorized: z.object({ message: z.string() }),
};

export const api = {
  recipes: {
    list: { method: 'GET' as const, path: '/api/recipes' as const, responses: { 200: z.array(z.any()) } },
    get: { method: 'GET' as const, path: '/api/recipes/:id' as const, responses: { 200: z.any(), 404: errorSchemas.notFound } },
    create: { method: 'POST' as const, path: '/api/recipes' as const, input: insertRecipeSchema, responses: { 201: z.any(), 400: errorSchemas.validation, 401: errorSchemas.unauthorized } },
    update: { method: 'PUT' as const, path: '/api/recipes/:id' as const, input: insertRecipeSchema.partial(), responses: { 200: z.any(), 400: errorSchemas.validation, 404: errorSchemas.notFound, 401: errorSchemas.unauthorized } },
    delete: { method: 'DELETE' as const, path: '/api/recipes/:id' as const, responses: { 204: z.void(), 404: errorSchemas.notFound, 401: errorSchemas.unauthorized } },
    suggest: { method: 'GET' as const, path: '/api/recipes/suggest' as const, responses: { 200: z.object({ recipe: z.any(), reason: z.string() }), 404: errorSchemas.notFound } },
  },
  admins: {
    login: { method: 'POST' as const, path: '/api/admin/login' as const, input: z.object({ username: z.string(), password: z.string() }), responses: { 200: z.any(), 401: errorSchemas.unauthorized } },
    logout: { method: 'POST' as const, path: '/api/admin/logout' as const, responses: { 200: z.any() } },
    me: { method: 'GET' as const, path: '/api/admin/me' as const, responses: { 200: z.any(), 401: errorSchemas.unauthorized } },
    changePassword: { method: 'POST' as const, path: '/api/admin/change-password' as const, input: z.object({ oldPassword: z.string(), newPassword: z.string() }), responses: { 200: z.any(), 400: errorSchemas.validation } },
    list: { method: 'GET' as const, path: '/api/admins' as const, responses: { 200: z.array(z.any()) } },
    create: { method: 'POST' as const, path: '/api/admins' as const, input: insertAdminSchema, responses: { 201: z.any(), 400: errorSchemas.validation } },
    update: { method: 'PUT' as const, path: '/api/admins/:id' as const, input: insertAdminSchema.partial(), responses: { 200: z.any() } },
    delete: { method: 'DELETE' as const, path: '/api/admins/:id' as const, responses: { 204: z.void() } },
    toggleActive: { method: 'PATCH' as const, path: '/api/admins/:id/toggle-active' as const, responses: { 200: z.any() } },
  },
  upload: {
    image: { method: 'POST' as const, path: '/api/upload/image' as const, responses: { 200: z.object({ url: z.string() }), 400: errorSchemas.validation } },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
