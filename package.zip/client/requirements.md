## Packages
framer-motion | For smooth page transitions and micro-interactions
react-hook-form | For complex recipe submission forms
@hookform/resolvers | For Zod validation in forms
clsx | For conditional class names
tailwind-merge | For merging tailwind classes safely

## Notes
App must be RTL (Right-to-Left) for Hebrew support.
Authentication uses Replit Auth blueprint.
Images will use Unsplash placeholders if no user image is provided.
