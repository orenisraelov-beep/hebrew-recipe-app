import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Layout } from "@/components/layout";

import Home from "@/pages/home";
import RecipeDetails from "@/pages/recipe-details";
import Admin from "@/pages/admin";
import AuthPage from "@/pages/auth-page";
import ChangePassword from "@/pages/change-password";
import FavoritesPage from "@/pages/favorites";
import ShoppingListPage from "@/pages/shopping-list";
import MealPlannerPage from "@/pages/meal-planner";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/recipe/:id" component={RecipeDetails} />
        <Route path="/favorites" component={FavoritesPage} />
        <Route path="/shopping-list" component={ShoppingListPage} />
        <Route path="/meal-planner" component={MealPlannerPage} />
        <Route path="/admin" component={Admin} />
        <Route path="/auth" component={AuthPage} />
        <Route path="/change-password" component={ChangePassword} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
