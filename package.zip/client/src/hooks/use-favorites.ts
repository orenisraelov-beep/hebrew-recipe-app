import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { userFetch } from "@/lib/user-id";
import { useCallback } from "react";

export function useFavorites() {
  const queryClient = useQueryClient();

  const { data: favoriteIds = [] } = useQuery<number[]>({
    queryKey: ["/api/user/favorites"],
    queryFn: async () => {
      const res = await userFetch("/api/user/favorites");
      if (!res.ok) return [];
      return res.json();
    },
  });

  const { data: favoriteCounts = {} } = useQuery<Record<number, number>>({
    queryKey: ["/api/favorites/counts"],
    queryFn: async () => {
      const res = await fetch("/api/favorites/counts");
      if (!res.ok) return {};
      return res.json();
    },
  });

  const addMutation = useMutation({
    mutationFn: async (recipeId: number) => {
      await userFetch(`/api/user/favorites/${recipeId}`, { method: "POST" });
    },
    onMutate: async (recipeId: number) => {
      await queryClient.cancelQueries({ queryKey: ["/api/user/favorites"] });
      await queryClient.cancelQueries({ queryKey: ["/api/favorites/counts"] });
      const prev = queryClient.getQueryData<number[]>(["/api/user/favorites"]);
      const prevCounts = queryClient.getQueryData<Record<number, number>>(["/api/favorites/counts"]);
      queryClient.setQueryData<number[]>(["/api/user/favorites"], (old = []) => [...old, recipeId]);
      queryClient.setQueryData<Record<number, number>>(["/api/favorites/counts"], (old = {}) => ({
        ...old,
        [recipeId]: (old[recipeId] || 0) + 1,
      }));
      return { prev, prevCounts };
    },
    onError: (_err, _id, context) => {
      if (context?.prev) queryClient.setQueryData(["/api/user/favorites"], context.prev);
      if (context?.prevCounts) queryClient.setQueryData(["/api/favorites/counts"], context.prevCounts);
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user/favorites"] });
      queryClient.invalidateQueries({ queryKey: ["/api/user/favorites/recipes"] });
      queryClient.invalidateQueries({ queryKey: ["/api/favorites/counts"] });
    },
  });

  const removeMutation = useMutation({
    mutationFn: async (recipeId: number) => {
      await userFetch(`/api/user/favorites/${recipeId}`, { method: "DELETE" });
    },
    onMutate: async (recipeId: number) => {
      await queryClient.cancelQueries({ queryKey: ["/api/user/favorites"] });
      await queryClient.cancelQueries({ queryKey: ["/api/favorites/counts"] });
      const prev = queryClient.getQueryData<number[]>(["/api/user/favorites"]);
      const prevCounts = queryClient.getQueryData<Record<number, number>>(["/api/favorites/counts"]);
      queryClient.setQueryData<number[]>(["/api/user/favorites"], (old = []) => old.filter(id => id !== recipeId));
      queryClient.setQueryData<Record<number, number>>(["/api/favorites/counts"], (old = {}) => ({
        ...old,
        [recipeId]: Math.max((old[recipeId] || 0) - 1, 0),
      }));
      return { prev, prevCounts };
    },
    onError: (_err, _id, context) => {
      if (context?.prev) queryClient.setQueryData(["/api/user/favorites"], context.prev);
      if (context?.prevCounts) queryClient.setQueryData(["/api/favorites/counts"], context.prevCounts);
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user/favorites"] });
      queryClient.invalidateQueries({ queryKey: ["/api/user/favorites/recipes"] });
      queryClient.invalidateQueries({ queryKey: ["/api/favorites/counts"] });
    },
  });

  const toggleFavorite = useCallback((id: number) => {
    if (favoriteIds.includes(id)) {
      removeMutation.mutate(id);
    } else {
      addMutation.mutate(id);
    }
  }, [favoriteIds, addMutation, removeMutation]);

  const isFavorite = useCallback(
    (id: number) => favoriteIds.includes(id),
    [favoriteIds]
  );

  const getFavoriteCount = useCallback(
    (id: number) => favoriteCounts[id] || 0,
    [favoriteCounts]
  );

  return { favorites: favoriteIds, toggleFavorite, isFavorite, getFavoriteCount, favoriteCounts };
}
