import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import type { Recipe, InsertRecipe, RecipeQueryParams, RecipeWithAdmin, RecipeFull } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { userFetch } from "@/lib/user-id";

export function useRecipes(params?: RecipeQueryParams) {
  return useQuery<RecipeWithAdmin[]>({
    queryKey: ["/api/recipes", params],
    queryFn: async () => {
      const query = new URLSearchParams();
      if (params?.search) query.append("search", params.search);
      if (params?.category) query.append("category", params.category);
      if (params?.tag) query.append("tag", params.tag);
      if (params?.difficulty) query.append("difficulty", params.difficulty);
      if (params?.origin) query.append("origin", params.origin);
      if (params?.maxPrepTime) query.append("maxPrepTime", String(params.maxPrepTime));
      if (params?.maxTotalTime) query.append("maxTotalTime", String(params.maxTotalTime));
      if (params?.ingredients) query.append("ingredients", params.ingredients);
      if (params?.ingredientIds) query.append("ingredientIds", params.ingredientIds);
      if (params?.author) query.append("author", params.author);
      const res = await fetch(`/api/recipes?${query.toString()}`);
      if (!res.ok) throw new Error("Failed to fetch recipes");
      return res.json();
    },
  });
}

export function useRecipe(id: number) {
  return useQuery<RecipeFull>({
    queryKey: ["/api/recipes", id],
    queryFn: async () => {
      const res = await userFetch(`/api/recipes/${id}`);
      if (!res.ok) throw new Error("Failed to fetch recipe");
      return res.json();
    },
    enabled: !!id,
  });
}

export function useCreateRecipe() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: any) => {
      const res = await fetch("/api/recipes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to create recipe");
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/recipes"] });
      toast({ title: "המתכון נוסף בהצלחה!", description: "המתכון שלך זמין כעת בחיפוש." });
    },
    onError: (error) => {
      toast({ title: "שגיאה ביצירת מתכון", description: error.message, variant: "destructive" });
    },
  });
}

export function useUpdateRecipe() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ id, ...updates }: { id: number; [key: string]: any }) => {
      const res = await fetch(`/api/recipes/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updates),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to update recipe");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/recipes"] });
      toast({ title: "המתכון עודכן", description: "השינויים נשמרו בהצלחה." });
    },
  });
}

export function useDeleteRecipe() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (id: number) => {
      const res = await fetch(`/api/recipes/${id}`, {
        method: "DELETE",
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to delete recipe");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/recipes"] });
      toast({ title: "המתכון נמחק", variant: "destructive" });
    },
  });
}

export function useSuggestion() {
  return useQuery({
    queryKey: ["/api/recipes/suggest"],
    queryFn: async () => {
      const res = await fetch("/api/recipes/suggest");
      if (!res.ok) throw new Error("Failed to get suggestion");
      return res.json() as Promise<{ recipe: RecipeWithAdmin; reason: string }>;
    },
    enabled: false,
  });
}

export async function uploadImage(file: File): Promise<string> {
  const formData = new FormData();
  formData.append("image", file);
  const res = await fetch("/api/upload/image", {
    method: "POST",
    body: formData,
    credentials: "include",
  });
  if (!res.ok) throw new Error("Upload failed");
  const { url } = await res.json();
  return url;
}

export async function uploadImages(files: File[]): Promise<string[]> {
  const urls: string[] = [];
  for (const file of files) {
    const url = await uploadImage(file);
    urls.push(url);
  }
  return urls;
}
