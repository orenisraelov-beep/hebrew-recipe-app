import { useState, useRef, useEffect, useCallback } from "react";
import { useQuery } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { List, X, Loader2, ChevronDown, ChevronUp } from "lucide-react";
import type { IngredientCategory, IngredientMasterWithCategory } from "@shared/schema";

interface IngredientAutocompleteProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  testId?: string;
}

export function IngredientAutocomplete({ value, onChange, placeholder, testId }: IngredientAutocompleteProps) {
  const [showDropdown, setShowDropdown] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const { data: suggestions = [], isLoading } = useQuery<IngredientMasterWithCategory[]>({
    queryKey: ["/api/ingredients", value],
    queryFn: async () => {
      if (!value || value.length < 1) return [];
      const res = await fetch(`/api/ingredients?search=${encodeURIComponent(value)}`);
      return res.json();
    },
    enabled: value.length >= 1 && showDropdown,
    staleTime: 5000,
  });

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setShowDropdown(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleSelect = useCallback((name: string) => {
    onChange(name);
    setShowDropdown(false);
  }, [onChange]);

  return (
    <div className="flex gap-1 flex-1" ref={containerRef}>
      <div className="relative flex-1">
        <Input
          ref={inputRef}
          placeholder={placeholder}
          value={value}
          onChange={e => {
            onChange(e.target.value);
            setShowDropdown(true);
          }}
          onFocus={() => { if (value.length >= 1) setShowDropdown(true); }}
          data-testid={testId}
        />
        {showDropdown && value.length >= 1 && (
          <div className="absolute z-50 top-full left-0 right-0 mt-1 bg-popover border rounded-md shadow-lg max-h-48 overflow-y-auto">
            {isLoading ? (
              <div className="flex justify-center p-3">
                <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
              </div>
            ) : suggestions.length > 0 ? (
              suggestions.map(s => (
                <button
                  key={s.id}
                  type="button"
                  className="w-full text-right px-3 py-2 text-sm border-b last:border-b-0 bg-popover active:bg-accent transition-colors"
                  onClick={() => handleSelect(s.nameHebrew)}
                  data-testid={`autocomplete-item-${s.id}`}
                >
                  <span className="font-medium">{s.nameHebrew}</span>
                  {s.categoryName && (
                    <span className="text-xs text-muted-foreground mr-2">({s.categoryName})</span>
                  )}
                </button>
              ))
            ) : (
              <div className="px-3 py-2 text-xs text-muted-foreground text-center">
                לא נמצאו תוצאות — ניתן להמשיך לכתוב חופשי
              </div>
            )}
          </div>
        )}
      </div>
      <Button
        type="button"
        variant="outline"
        size="icon"
        className="flex-shrink-0"
        onClick={() => setShowModal(true)}
        data-testid={`btn-pick-from-list-${testId}`}
      >
        <List className="h-4 w-4" />
      </Button>

      {showModal && (
        <IngredientPickerModal
          onSelect={(name) => { handleSelect(name); setShowModal(false); }}
          onClose={() => setShowModal(false)}
        />
      )}
    </div>
  );
}

function IngredientPickerModal({ onSelect, onClose }: { onSelect: (name: string) => void; onClose: () => void }) {
  const [search, setSearch] = useState("");
  const [expandedCategories, setExpandedCategories] = useState<Set<number>>(new Set());
  const modalRef = useRef<HTMLDivElement>(null);

  const { data: categories = [], isLoading } = useQuery<(IngredientCategory & { ingredients: IngredientMasterWithCategory[] })[]>({
    queryKey: ["/api/ingredient-categories"],
  });

  const toggleCategory = (id: number) => {
    setExpandedCategories(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const filteredCategories = categories.map(cat => ({
    ...cat,
    ingredients: cat.ingredients.filter(ing =>
      !search || ing.nameHebrew.includes(search)
    ),
  })).filter(cat => cat.ingredients.length > 0);

  useEffect(() => {
    if (search && filteredCategories.length > 0) {
      setExpandedCategories(new Set(filteredCategories.map(c => c.id)));
    }
  }, [search]);

  return (
    <div className="fixed inset-0 z-[100] bg-black/50 flex items-end sm:items-center justify-center" onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div
        ref={modalRef}
        className="bg-background w-full sm:max-w-lg sm:rounded-lg rounded-t-xl max-h-[80vh] flex flex-col"
        data-testid="modal-ingredient-picker"
      >
        <div className="flex items-center justify-between p-4 border-b">
          <h3 className="font-bold text-lg">בחר מצרך מהרשימה</h3>
          <Button variant="ghost" size="icon" onClick={onClose} data-testid="btn-close-ingredient-modal">
            <X className="h-5 w-5" />
          </Button>
        </div>

        <div className="p-3 border-b">
          <Input
            placeholder="חפש מצרך..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            data-testid="input-search-ingredient-modal"
          />
        </div>

        <div className="flex-1 overflow-y-auto p-3 space-y-2">
          {isLoading ? (
            <div className="flex justify-center p-6">
              <Loader2 className="h-6 w-6 animate-spin" />
            </div>
          ) : filteredCategories.length === 0 ? (
            <p className="text-center text-muted-foreground py-6">לא נמצאו מצרכים</p>
          ) : (
            filteredCategories.map(cat => (
              <div key={cat.id} className="border rounded-lg">
                <button
                  type="button"
                  className="w-full flex items-center justify-between p-3 text-sm font-bold active:bg-accent transition-colors"
                  onClick={() => toggleCategory(cat.id)}
                  data-testid={`btn-category-${cat.id}`}
                >
                  <span>{cat.nameHebrew} ({cat.ingredients.length})</span>
                  {expandedCategories.has(cat.id) ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                </button>
                {expandedCategories.has(cat.id) && (
                  <div className="border-t p-2 flex flex-wrap gap-1.5">
                    {cat.ingredients.map(ing => (
                      <Badge
                        key={ing.id}
                        variant="outline"
                        className="cursor-pointer active:bg-primary active:text-primary-foreground transition-colors py-1.5 px-2.5 text-sm"
                        onClick={() => onSelect(ing.nameHebrew)}
                        data-testid={`pick-ingredient-${ing.id}`}
                      >
                        {ing.nameHebrew}
                      </Badge>
                    ))}
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
