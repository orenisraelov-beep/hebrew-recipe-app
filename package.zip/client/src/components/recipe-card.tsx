import { type RecipeWithAdmin } from "@shared/schema";
import { Link } from "wouter";
import { Clock, Timer, Users, Heart, Star, User } from "lucide-react";
import { motion } from "framer-motion";
import { ImageCarousel } from "./image-carousel";

interface RecipeCardProps {
  recipe: RecipeWithAdmin;
  index?: number;
  isFavorite?: boolean;
  onToggleFavorite?: (id: number) => void;
  favoriteCount?: number;
}

export function RecipeCard({ recipe, index = 0, isFavorite = false, onToggleFavorite, favoriteCount = 0 }: RecipeCardProps) {
  const allImages = buildImageList(recipe);

  const formatTime = (minutes: number | null | undefined) => {
    if (!minutes) return null;
    if (minutes >= 60) {
      const h = Math.floor(minutes / 60);
      const m = minutes % 60;
      return m > 0 ? `${h}:${String(m).padStart(2, "0")} שעות` : `${h} שעות`;
    }
    return `${minutes} דק׳`;
  };

  const handleFavorite = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    onToggleFavorite?.(recipe.id);
  };

  const cardOverlay = (
    <>
      <div className="absolute top-3 right-3 flex flex-wrap gap-2 z-10">
        <span className="px-2 py-1 text-xs font-bold bg-background/90 backdrop-blur text-foreground rounded-lg shadow-sm">
          {recipe.category === "Meat" ? "בשרי" : recipe.category === "Dairy" ? "חלבי" : "פרווה"}
        </span>
        {recipe.difficulty && (
          <span className="px-2 py-1 text-xs font-bold bg-primary/90 text-primary-foreground backdrop-blur rounded-lg shadow-sm">
            {recipe.difficulty}
          </span>
        )}
      </div>
      <button
        onClick={handleFavorite}
        className="absolute top-3 left-3 flex items-center gap-1 px-2 py-1 rounded-full bg-background/80 backdrop-blur-sm shadow-sm hover:bg-background transition-colors z-10"
        data-testid={`btn-favorite-${recipe.id}`}
      >
        <Heart
          className={`w-4 h-4 transition-colors ${
            isFavorite ? "fill-red-500 text-red-500" : "text-muted-foreground"
          }`}
        />
        {favoriteCount > 0 && (
          <span className={`text-xs font-bold ${isFavorite ? "text-red-500" : "text-muted-foreground"}`} data-testid={`text-fav-count-${recipe.id}`}>
            {favoriteCount}
          </span>
        )}
      </button>
    </>
  );

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: index * 0.05 }}
    >
      <Link href={`/recipe/${recipe.id}`} className="block h-full group">
        <div className="h-full bg-card border border-border/50 rounded-2xl overflow-hidden shadow-sm hover:shadow-xl hover:shadow-primary/10 hover:-translate-y-1 transition-all duration-300 flex flex-col" data-testid={`card-recipe-home-${recipe.id}`}>
          {allImages.length > 0 ? (
            <ImageCarousel
              images={allImages}
              alt={recipe.title}
              className="aspect-[4/3] bg-muted"
              testIdPrefix={`card-carousel-${recipe.id}`}
              overlay={cardOverlay}
            />
          ) : (
            <div className="relative aspect-[4/3] bg-muted">
              <div className="w-full h-full flex items-center justify-center bg-secondary text-secondary-foreground/20">
                <Clock className="w-12 h-12" />
              </div>
              {cardOverlay}
            </div>
          )}

          <div className="p-4 flex-grow flex flex-col justify-between">
            <div>
              <h3 className="text-lg font-bold text-foreground leading-tight group-hover:text-primary transition-colors">
                {recipe.title}
              </h3>
              <div className="flex items-center gap-2 mt-1 flex-wrap">
                {recipe.origin && (
                  <span className="text-xs text-muted-foreground">{recipe.origin}</span>
                )}
                {recipe.averageRating && recipe.averageRating > 0 ? (
                  <span className="flex items-center gap-0.5 text-xs font-bold text-amber-500" data-testid={`text-rating-${recipe.id}`}>
                    <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                    {recipe.averageRating} / 10
                    {recipe.ratingCount ? <span className="text-muted-foreground font-normal">({recipe.ratingCount})</span> : null}
                  </span>
                ) : null}
              </div>
              {recipe.authorName && (
                <p className="text-xs text-muted-foreground mt-1 flex items-center gap-1" data-testid={`text-author-${recipe.id}`}>
                  <User className="w-3 h-3" />
                  הועלה ע״י: {recipe.authorName}
                </p>
              )}
              <p className="mt-1 text-sm text-muted-foreground line-clamp-2">
                {recipe.description || "מתכון נהדר ששווה לנסות..."}
              </p>
            </div>

            <div className="mt-4 pt-4 border-t flex items-center justify-between text-xs text-muted-foreground font-medium">
              <div className="flex items-center gap-4">
                {recipe.preparationTime && (
                  <span className="flex items-center gap-1" data-testid={`text-preptime-${recipe.id}`}>
                    <Clock className="w-3.5 h-3.5" />
                    <span>הכנה: {formatTime(recipe.preparationTime)}</span>
                  </span>
                )}
                {recipe.totalTime && (
                  <span className="flex items-center gap-1" data-testid={`text-totaltime-${recipe.id}`}>
                    <Timer className="w-3.5 h-3.5" />
                    <span>סה״כ: {formatTime(recipe.totalTime)}</span>
                  </span>
                )}
                {!recipe.preparationTime && !recipe.totalTime && (
                  <span className="flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5" />
                    <span>—</span>
                  </span>
                )}
              </div>
              <span className="flex items-center gap-1">
                <Users className="w-3.5 h-3.5" />
                {recipe.servings ? `${recipe.servings}` : "—"}
              </span>
            </div>
          </div>
        </div>
      </Link>
    </motion.div>
  );
}

function buildImageList(recipe: RecipeWithAdmin): string[] {
  const imgs: string[] = [];
  if (recipe.images && recipe.images.length > 0) {
    for (const img of recipe.images) {
      if (img.imagePath) imgs.push(img.imagePath);
    }
  }
  if (imgs.length === 0 && recipe.imageUrl) {
    imgs.push(recipe.imageUrl);
  }
  return imgs;
}
