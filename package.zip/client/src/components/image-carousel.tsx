import { useState, useRef, useCallback } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";

interface ImageCarouselProps {
  images: string[];
  alt?: string;
  className?: string;
  testIdPrefix?: string;
  overlay?: React.ReactNode;
  showGradient?: boolean;
}

export function ImageCarousel({
  images,
  alt = "תמונה",
  className = "",
  testIdPrefix = "carousel",
  overlay,
  showGradient = false,
}: ImageCarouselProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const touchStartX = useRef<number | null>(null);
  const touchDeltaX = useRef(0);
  const isSwiping = useRef(false);

  const goNext = useCallback(() => {
    setCurrentIndex((i) => (i + 1) % images.length);
  }, [images.length]);

  const goPrev = useCallback(() => {
    setCurrentIndex((i) => (i - 1 + images.length) % images.length);
  }, [images.length]);

  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    touchStartX.current = e.touches[0].clientX;
    touchDeltaX.current = 0;
    isSwiping.current = false;
  }, []);

  const handleTouchMove = useCallback((e: React.TouchEvent) => {
    if (touchStartX.current === null) return;
    touchDeltaX.current = e.touches[0].clientX - touchStartX.current;
    if (Math.abs(touchDeltaX.current) > 10) {
      isSwiping.current = true;
    }
  }, []);

  const handleTouchEnd = useCallback(() => {
    if (touchStartX.current === null) return;
    const swipeThreshold = 50;
    if (touchDeltaX.current < -swipeThreshold) {
      goNext();
    } else if (touchDeltaX.current > swipeThreshold) {
      goPrev();
    }
    touchStartX.current = null;
    touchDeltaX.current = 0;
    setTimeout(() => {
      isSwiping.current = false;
    }, 0);
  }, [goNext, goPrev]);

  const handleClick = useCallback((e: React.MouseEvent, action: () => void) => {
    e.preventDefault();
    e.stopPropagation();
    action();
  }, []);

  const handleContainerClick = useCallback((e: React.MouseEvent) => {
    if (isSwiping.current) {
      e.preventDefault();
      e.stopPropagation();
    }
  }, []);

  if (images.length === 0) return null;

  const hasMultiple = images.length > 1;

  return (
    <div
      className={`relative overflow-hidden ${className}`}
      onTouchStart={hasMultiple ? handleTouchStart : undefined}
      onTouchMove={hasMultiple ? handleTouchMove : undefined}
      onTouchEnd={hasMultiple ? handleTouchEnd : undefined}
      onClickCapture={hasMultiple ? handleContainerClick : undefined}
      data-testid={`${testIdPrefix}-container`}
    >
      <img
        src={images[currentIndex]}
        alt={`${alt} ${currentIndex + 1}`}
        className="w-full h-full object-cover transition-opacity duration-300"
        loading="lazy"
        data-testid={`${testIdPrefix}-image`}
      />

      {showGradient && (
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent pointer-events-none" />
      )}

      {hasMultiple && (
        <>
          <button
            onClick={(e) => handleClick(e, goPrev)}
            className="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-black/40 backdrop-blur-sm text-white flex items-center justify-center hover:bg-black/60 transition-colors z-10"
            data-testid={`${testIdPrefix}-prev`}
            aria-label="תמונה קודמת"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
          <button
            onClick={(e) => handleClick(e, goNext)}
            className="absolute left-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-black/40 backdrop-blur-sm text-white flex items-center justify-center hover:bg-black/60 transition-colors z-10"
            data-testid={`${testIdPrefix}-next`}
            aria-label="תמונה הבאה"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <div className="absolute bottom-2 left-1/2 -translate-x-1/2 flex gap-1.5 z-10">
            {images.map((_, i) => (
              <button
                key={i}
                onClick={(e) => handleClick(e, () => setCurrentIndex(i))}
                className={`rounded-full transition-all ${
                  i === currentIndex ? "bg-white w-4 h-2" : "bg-white/50 w-2 h-2"
                }`}
                aria-label={`תמונה ${i + 1}`}
              />
            ))}
          </div>
        </>
      )}

      {overlay}
    </div>
  );
}
