import { ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { ChefHat, Plus, Home, LogIn, Heart, ShoppingCart, Calendar } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";

export function Layout({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const { user } = useAuth();

  const mainNavItems = [
    { href: "/", icon: Home, label: "בית" },
    { href: "/favorites", icon: Heart, label: "מועדפים" },
    { href: "/shopping-list", icon: ShoppingCart, label: "קניות" },
    { href: "/meal-planner", icon: Calendar, label: "תכנון" },
    ...(user
      ? [{ href: "/admin", icon: Plus, label: "ניהול" }]
      : [{ href: "/auth", icon: LogIn, label: "כניסה" }]),
  ];

  return (
    <div className="min-h-screen bg-background text-foreground pb-20 md:pb-0" dir="rtl">
      <header className="hidden md:block sticky top-0 z-50 w-full border-b bg-background/80 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between gap-4">
          <Link href="/" className="flex items-center gap-2 hover:opacity-80 transition-opacity">
            <div className="bg-primary/10 p-2 rounded-full">
              <ChefHat className="h-6 w-6 text-primary" />
            </div>
            <span className="text-xl font-bold bg-gradient-to-l from-primary to-orange-600 bg-clip-text text-transparent">
              מתכונים חכמים
            </span>
          </Link>

          <nav className="flex items-center gap-6 flex-wrap">
            <Link href="/" className={`text-sm font-medium transition-colors hover:text-primary ${location === '/' ? 'text-primary' : 'text-muted-foreground'}`}>
              דף הבית
            </Link>
            <Link href="/favorites" className={`text-sm font-medium transition-colors hover:text-primary ${location === '/favorites' ? 'text-primary' : 'text-muted-foreground'}`}>
              מועדפים
            </Link>
            <Link href="/shopping-list" className={`text-sm font-medium transition-colors hover:text-primary ${location === '/shopping-list' ? 'text-primary' : 'text-muted-foreground'}`}>
              רשימת קניות
            </Link>
            <Link href="/meal-planner" className={`text-sm font-medium transition-colors hover:text-primary ${location === '/meal-planner' ? 'text-primary' : 'text-muted-foreground'}`}>
              תכנון שבועי
            </Link>
            {user ? (
              <>
                <Link href="/admin" className={`text-sm font-medium transition-colors hover:text-primary ${location.startsWith('/admin') ? 'text-primary' : 'text-muted-foreground'}`}>
                  ניהול מתכונים
                </Link>
                <div className="flex items-center gap-3 mr-4 pl-4 border-l">
                  <span className="text-sm text-muted-foreground">שלום, {user.username}</span>
                </div>
              </>
            ) : (
              <Link href="/auth" className="text-sm font-medium text-muted-foreground hover:text-primary transition-colors" data-testid="link-admin-login">
                כניסת מנהל
              </Link>
            )}
          </nav>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6 md:py-8 max-w-5xl animate-in fade-in duration-500">
        {children}
      </main>

      <div className="md:hidden fixed bottom-0 left-0 right-0 border-t bg-background/95 backdrop-blur z-50 pb-safe">
        <div className="flex justify-around items-center h-16">
          {mainNavItems.map((item) => {
            const Icon = item.icon;
            const isActive = location === item.href || (item.href !== '/' && location.startsWith(item.href));
            return (
              <Link key={item.href} href={item.href} className="flex flex-col items-center justify-center w-full h-full">
                <div className={`p-1.5 rounded-md transition-all duration-300 ${isActive ? 'bg-primary/10 text-primary scale-110' : 'text-muted-foreground'}`}>
                  <Icon className="h-5 w-5" />
                </div>
                <span className={`text-[10px] mt-0.5 font-medium ${isActive ? 'text-primary' : 'text-muted-foreground'}`}>
                  {item.label}
                </span>
              </Link>
            );
          })}
        </div>
      </div>
    </div>
  );
}
