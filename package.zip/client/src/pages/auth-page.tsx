import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ChefHat, Lock, Eye, EyeOff, Loader2, LogIn } from "lucide-react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { useEffect } from "react";

export default function AuthPage() {
  const { user, isLoading, login, isLoggingIn, loginError } = useAuth();
  const [, setLocation] = useLocation();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (user && !isLoading) {
      if (user.forcePasswordChange) {
        setLocation("/change-password");
      } else {
        setLocation("/admin");
      }
    }
  }, [user, isLoading, setLocation]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (!username.trim() || !password.trim()) {
      setError("נא למלא את כל השדות");
      return;
    }
    try {
      await login({ username: username.trim(), password });
    } catch (err: any) {
      setError(err.message || "שגיאה בהתחברות");
    }
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center">
      <Card className="w-full max-w-md shadow-2xl shadow-primary/10 border-border/50">
        <CardHeader className="text-center pb-2">
          <div className="mx-auto w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-4">
            <Lock className="w-8 h-8 text-primary" />
          </div>
          <h1 className="text-2xl font-black" data-testid="text-login-title">כניסת מנהל</h1>
          <p className="text-muted-foreground">אנא התחבר כדי לנהל מתכונים</p>
        </CardHeader>
        <CardContent className="pt-6">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">שם משתמש</label>
              <Input
                data-testid="input-username"
                placeholder="הכנס שם משתמש"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                autoComplete="username"
                dir="ltr"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">סיסמה</label>
              <div className="relative">
                <Input
                  data-testid="input-password"
                  type={showPassword ? "text" : "password"}
                  placeholder="הכנס סיסמה"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  autoComplete="current-password"
                  dir="ltr"
                />
                <button
                  type="button"
                  className="absolute left-3 top-2.5 text-muted-foreground"
                  onClick={() => setShowPassword(!showPassword)}
                  data-testid="button-toggle-password"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {(error || loginError) && (
              <p className="text-sm text-destructive text-center" data-testid="text-login-error">
                {error || loginError}
              </p>
            )}

            <Button
              type="submit"
              data-testid="button-login"
              className="w-full h-12 text-lg font-bold"
              disabled={isLoggingIn}
            >
              {isLoggingIn ? (
                <Loader2 className="ml-2 h-5 w-5 animate-spin" />
              ) : (
                <>
                  <LogIn className="ml-2 h-5 w-5" />
                  כניסה
                </>
              )}
            </Button>
          </form>

          <div className="mt-8 text-center">
            <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground/60">
              <ChefHat className="w-4 h-4" />
              <span>מערכת ניהול מתכונים חכמה</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
