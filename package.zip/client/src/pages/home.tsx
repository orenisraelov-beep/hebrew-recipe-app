import { useState, useEffect, useRef, useCallback } from "react";
import { useRecipes, useSuggestion } from "@/hooks/use-recipes";
import { RecipeCard } from "@/components/recipe-card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, Sparkles, Filter, X, Mic, MicOff, SlidersHorizontal, ChefHat, ChevronDown, ChevronUp, Plus, Loader2, User } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useToast } from "@/hooks/use-toast";
import { useFavorites } from "@/hooks/use-favorites";
import { useQuery, useMutation } from "@tanstack/react-query";
import { DIFFICULTY_OPTIONS, ORIGIN_OPTIONS, type RecipeQueryParams, type IngredientCategoryWithIngredients, type IngredientCategory } from "@shared/schema";
import { userFetch } from "@/lib/user-id";
import { apiRequest, queryClient } from "@/lib/queryClient";

const QUICK_FILTERS = [
  { id: "all", label: "הכל" },
  { id: "shabbat", label: "שבת", type: "tag" as const },
  { id: "weekday", label: "יום חול", type: "tag" as const },
  { id: "holiday", label: "חג", type: "tag" as const },
  { id: "meat", label: "בשרי", type: "category" as const, value: "Meat" },
  { id: "dairy", label: "חלבי", type: "category" as const, value: "Dairy" },
  { id: "parve", label: "פרווה", type: "category" as const, value: "Parve" },
  { id: "dessert", label: "קינוח", type: "tag" as const },
  { id: "winter", label: "חורף", type: "tag" as const },
  { id: "summer", label: "קיץ", type: "tag" as const },
];

const PREP_TIME_OPTIONS = [
  { label: "הכל", value: undefined },
  { label: "עד 15 דק׳", value: 15 },
  { label: "עד 30 דק׳", value: 30 },
  { label: "עד 60 דק׳", value: 60 },
];

const TOTAL_TIME_OPTIONS = [
  { label: "הכל", value: undefined },
  { label: "עד 30 דק׳", value: 30 },
  { label: "עד שעה", value: 60 },
  { label: "עד שעתיים", value: 120 },
];

export default function Home() {
  const [searchTerm, setSearchTerm] = useState("");
  const [activeFilter, setActiveFilter] = useState("all");
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [advDifficulty, setAdvDifficulty] = useState<string | undefined>();
  const [advOrigin, setAdvOrigin] = useState<string | undefined>();
  const [advMaxPrepTime, setAdvMaxPrepTime] = useState<number | undefined>();
  const [advMaxTotalTime, setAdvMaxTotalTime] = useState<number | undefined>();
  const [advAuthor, setAdvAuthor] = useState<string | undefined>();
  const [isListening, setIsListening] = useState(false);
  const [showIngredients, setShowIngredients] = useState(false);
  const [selectedIngredientIds, setSelectedIngredientIds] = useState<number[]>([]);
  const [ingredientSearch, setIngredientSearch] = useState("");
  const [expandedCategories, setExpandedCategories] = useState<Set<number>>(new Set());
  const { toast } = useToast();
  const recognitionRef = useRef<any>(null);

  const filterConfig = QUICK_FILTERS.find(f => f.id === activeFilter);
  const queryParams: RecipeQueryParams = {
    search: searchTerm || undefined,
    category: filterConfig?.type === "category" ? (filterConfig as any).value || filterConfig.label : undefined,
    tag: filterConfig?.type === "tag" ? filterConfig.label : undefined,
    difficulty: advDifficulty,
    origin: advOrigin,
    maxPrepTime: advMaxPrepTime,
    maxTotalTime: advMaxTotalTime,
    ingredientIds: selectedIngredientIds.length > 0 ? selectedIngredientIds.join(",") : undefined,
    author: advAuthor,
  };

  const { data: recipes, isLoading, error } = useRecipes(queryParams);
  const { refetch: fetchSuggestion, isFetching: isSuggesting } = useSuggestion();
  const { isFavorite, toggleFavorite, getFavoriteCount } = useFavorites();

  const { data: categoriesWithIngredients = [] } = useQuery<IngredientCategoryWithIngredients[]>({
    queryKey: ["/api/ingredient-categories"],
  });

  const { data: authors = [] } = useQuery<string[]>({
    queryKey: ["/api/authors"],
  });

  const { data: userIngredientIds = [] } = useQuery<number[]>({
    queryKey: ["/api/user/ingredients"],
    queryFn: () => userFetch("/api/user/ingredients").then(r => r.json()),
  });

  useEffect(() => {
    if (userIngredientIds.length > 0 && selectedIngredientIds.length === 0) {
      setSelectedIngredientIds(userIngredientIds);
    }
  }, [userIngredientIds]);

  const toggleIngredientId = (id: number) => {
    setSelectedIngredientIds(prev => {
      const next = prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id];
      userFetch("/api/user/ingredients", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ingredientIds: next }),
      });
      return next;
    });
  };

  const clearIngredientSelection = () => {
    setSelectedIngredientIds([]);
    userFetch("/api/user/ingredients", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ingredientIds: [] }),
    });
  };

  const toggleCategory = (catId: number) => {
    setExpandedCategories(prev => {
      const next = new Set(prev);
      if (next.has(catId)) next.delete(catId); else next.add(catId);
      return next;
    });
  };

  const [showAddIngredient, setShowAddIngredient] = useState(false);
  const [addIngName, setAddIngName] = useState("");
  const [addIngCategoryId, setAddIngCategoryId] = useState<string>("");

  const addIngredientMutation = useMutation({
    mutationFn: (data: { nameHebrew: string; categoryId: number | null }) =>
      apiRequest("POST", "/api/ingredients", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/ingredient-categories"] });
      setAddIngName("");
      setAddIngCategoryId("");
      setShowAddIngredient(false);
      toast({ title: "המצרך נוסף בהצלחה" });
    },
    onError: () => toast({ title: "שגיאה בהוספת מצרך", variant: "destructive" }),
  });

  const allCategories = categoriesWithIngredients.map(cat => ({ id: cat.id, nameHebrew: cat.nameHebrew }));

  const filteredCategories = categoriesWithIngredients.map(cat => ({
    ...cat,
    ingredients: ingredientSearch
      ? cat.ingredients.filter(ing => ing.nameHebrew.includes(ingredientSearch))
      : cat.ingredients,
  })).filter(cat => cat.ingredients.length > 0);

  const hasActiveAdvanced = advDifficulty || advOrigin || advMaxPrepTime || advMaxTotalTime || advAuthor;

  const clearAdvanced = () => {
    setAdvDifficulty(undefined);
    setAdvOrigin(undefined);
    setAdvMaxPrepTime(undefined);
    setAdvMaxTotalTime(undefined);
    setAdvAuthor(undefined);
  };

  const startVoiceSearch = useCallback(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      toast({ title: "חיפוש קולי לא נתמך בדפדפן זה", variant: "destructive" });
      return;
    }
    const recognition = new SpeechRecognition();
    recognition.lang = "he-IL";
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      setSearchTerm(transcript);
      setIsListening(false);
    };
    recognition.onerror = () => setIsListening(false);
    recognition.onend = () => setIsListening(false);
    recognition.start();
    recognitionRef.current = recognition;
    setIsListening(true);
  }, [toast]);

  const stopVoiceSearch = useCallback(() => {
    recognitionRef.current?.stop();
    setIsListening(false);
  }, []);


  const handleSuggestion = async () => {
    try {
      const result = await fetchSuggestion();
      if (result.data) {
        toast({
          title: "הצעה להיום!",
          description: `${result.data.reason}: ${result.data.recipe.title}`,
          action: <Button variant="outline" size="sm" onClick={() => window.location.href=`/recipe/${result.data.recipe.id}`}>צפה</Button>,
        });
      }
    } catch (e) {
      toast({ title: "לא הצלחנו למצוא הצעה כרגע", variant: "destructive" });
    }
  };

  return (
    <div className="space-y-6">
      <section className="relative">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/10 to-orange-500/5 rounded-3xl -z-10 blur-3xl transform rotate-1 scale-110 opacity-50" />
        <div className="flex flex-col gap-5 items-center text-center py-6">
          <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="space-y-2">
            <h1 className="text-4xl md:text-5xl font-black text-foreground tracking-tight">
              מה נבשל <span className="text-primary">היום?</span>
            </h1>
            <p className="text-muted-foreground text-lg max-w-md mx-auto">
              חיפוש מתכונים חכם לכל אירוע, חג ויום בשבוע
            </p>
          </motion.div>

          <div className="w-full max-w-md relative group">
            <div className="absolute inset-y-0 right-3 flex items-center pointer-events-none text-muted-foreground group-focus-within:text-primary transition-colors">
              <Search className="w-5 h-5" />
            </div>
            <Input
              placeholder="חפש מתכון..."
              className="pr-10 pl-20 h-14 rounded-2xl shadow-sm border-2 border-transparent bg-white focus:border-primary/20 focus:ring-4 focus:ring-primary/10 text-lg transition-all"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              data-testid="input-search"
            />
            <div className="absolute inset-y-0 left-2 flex items-center gap-1">
              {searchTerm && (
                <button
                  onClick={() => setSearchTerm("")}
                  className="p-1.5 text-muted-foreground hover:text-foreground"
                  data-testid="btn-clear-search"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
              <button
                onClick={isListening ? stopVoiceSearch : startVoiceSearch}
                className={`p-2 rounded-full transition-all ${isListening ? 'bg-red-500 text-white animate-pulse' : 'text-muted-foreground hover:text-primary hover:bg-primary/10'}`}
                data-testid="btn-voice-search"
              >
                {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
              </button>
            </div>
          </div>

          <div className="flex gap-2 flex-wrap justify-center">
            <Button
              onClick={handleSuggestion}
              disabled={isSuggesting}
              className="rounded-full px-6 h-10 bg-gradient-to-r from-primary to-orange-600 hover:shadow-lg hover:shadow-primary/25 transition-all duration-300"
              data-testid="btn-suggest"
            >
              {isSuggesting ? "חושב..." : (
                <span className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4" />
                  הצע מתכון להיום
                </span>
              )}
            </Button>
            <Button
              variant="outline"
              onClick={() => setShowIngredients(!showIngredients)}
              className={`rounded-full px-6 h-10 gap-2 ${showIngredients || selectedIngredientIds.length > 0 ? 'border-primary text-primary' : ''}`}
              data-testid="btn-ingredients-search"
            >
              <ChefHat className="w-4 h-4" />
              יש לי בבית
              {selectedIngredientIds.length > 0 && (
                <span className="bg-primary text-primary-foreground text-xs px-1.5 rounded-full">{selectedIngredientIds.length}</span>
              )}
            </Button>
          </div>
        </div>
      </section>

      <AnimatePresence>
        {showIngredients && (
          <motion.section
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden"
          >
            <div className="bg-card border rounded-2xl p-4 space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-sm">בחר מצרכים שיש לך בבית</h3>
                {selectedIngredientIds.length > 0 && (
                  <button onClick={clearIngredientSelection} className="text-xs text-muted-foreground hover:text-foreground" data-testid="btn-clear-ingredients">
                    נקה בחירה ({selectedIngredientIds.length})
                  </button>
                )}
              </div>

              <div className="flex gap-2">
                <div className="relative flex-1">
                  <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    value={ingredientSearch}
                    onChange={(e) => setIngredientSearch(e.target.value)}
                    placeholder="חפש מצרך..."
                    className="pr-10 h-9 text-sm rounded-xl"
                    data-testid="input-ingredient-search"
                  />
                </div>
                <Button
                  size="sm"
                  variant="outline"
                  className="h-9 rounded-xl gap-1 text-xs shrink-0"
                  onClick={() => setShowAddIngredient(!showAddIngredient)}
                  data-testid="btn-add-new-ingredient"
                >
                  <Plus className="w-3.5 h-3.5" />
                  הוסף מצרך
                </Button>
              </div>

              <AnimatePresence>
                {showAddIngredient && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    className="overflow-hidden"
                  >
                    <form
                      onSubmit={(e) => {
                        e.preventDefault();
                        if (addIngName.trim()) {
                          addIngredientMutation.mutate({
                            nameHebrew: addIngName.trim(),
                            categoryId: addIngCategoryId ? Number(addIngCategoryId) : null,
                          });
                        }
                      }}
                      className="bg-secondary/30 rounded-xl p-3 space-y-2"
                    >
                      <div className="flex gap-2 items-end">
                        <div className="flex-1">
                          <label className="text-xs font-medium mb-1 block">שם המצרך</label>
                          <Input
                            value={addIngName}
                            onChange={(e) => setAddIngName(e.target.value)}
                            placeholder="שם המצרך"
                            className="h-8 text-sm"
                            data-testid="input-pantry-add-name"
                          />
                        </div>
                        <div className="w-32">
                          <label className="text-xs font-medium mb-1 block">קטגוריה</label>
                          <Select value={addIngCategoryId} onValueChange={setAddIngCategoryId}>
                            <SelectTrigger className="h-8 text-sm" data-testid="select-pantry-add-category">
                              <SelectValue placeholder="בחר" />
                            </SelectTrigger>
                            <SelectContent>
                              {allCategories.map((cat) => (
                                <SelectItem key={cat.id} value={String(cat.id)}>{cat.nameHebrew}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      <div className="flex gap-2 justify-end">
                        <Button type="button" variant="ghost" size="sm" className="h-7 text-xs" onClick={() => setShowAddIngredient(false)}>
                          ביטול
                        </Button>
                        <Button type="submit" size="sm" className="h-7 text-xs" disabled={addIngredientMutation.isPending} data-testid="btn-pantry-submit-ingredient">
                          {addIngredientMutation.isPending ? <Loader2 className="w-3 h-3 animate-spin ml-1" /> : <Plus className="w-3 h-3 ml-1" />}
                          הוסף
                        </Button>
                      </div>
                    </form>
                  </motion.div>
                )}
              </AnimatePresence>

              <div className="max-h-64 overflow-y-auto space-y-1">
                {filteredCategories.map(cat => {
                  const isExpanded = expandedCategories.has(cat.id) || !!ingredientSearch;
                  const selectedCount = cat.ingredients.filter(ing => selectedIngredientIds.includes(ing.id)).length;
                  return (
                    <div key={cat.id} className="border rounded-xl overflow-hidden">
                      <button
                        onClick={() => toggleCategory(cat.id)}
                        className="flex items-center justify-between w-full px-3 py-2 text-sm font-medium bg-secondary/50 hover:bg-secondary/80 transition-colors"
                        data-testid={`btn-category-toggle-${cat.id}`}
                      >
                        <span className="flex items-center gap-2">
                          {cat.nameHebrew}
                          {selectedCount > 0 && (
                            <span className="bg-primary text-primary-foreground text-xs px-1.5 rounded-full">{selectedCount}</span>
                          )}
                        </span>
                        {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                      </button>
                      {isExpanded && (
                        <div className="flex flex-wrap gap-1.5 p-2">
                          {cat.ingredients.map(ing => (
                            <button
                              key={ing.id}
                              onClick={() => toggleIngredientId(ing.id)}
                              className={`px-3 py-1 rounded-full text-xs font-medium transition-all ${
                                selectedIngredientIds.includes(ing.id)
                                  ? 'bg-primary text-primary-foreground shadow-sm'
                                  : 'bg-muted text-muted-foreground hover:bg-muted/80'
                              }`}
                              data-testid={`btn-ingredient-${ing.id}`}
                            >
                              {ing.nameHebrew}
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  );
                })}
                {filteredCategories.length === 0 && (
                  <p className="text-center py-4 text-muted-foreground text-xs">
                    {ingredientSearch ? "לא נמצאו מצרכים" : "אין מצרכים זמינים"}
                  </p>
                )}
              </div>
            </div>
          </motion.section>
        )}
      </AnimatePresence>

      <section className="sticky top-16 md:top-20 z-40 bg-background/95 backdrop-blur py-2 -mx-4 px-4 md:mx-0 md:px-0">
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-2 md:pb-0">
          <button
            onClick={() => setShowAdvanced(!showAdvanced)}
            className={`flex items-center gap-1 whitespace-nowrap px-3 py-2 rounded-xl text-sm font-medium transition-all duration-200 ${
              showAdvanced || hasActiveAdvanced
                ? 'bg-primary text-primary-foreground shadow-md'
                : 'bg-secondary text-secondary-foreground hover:bg-secondary/80'
            }`}
            data-testid="btn-advanced-filters"
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            סינון
          </button>
          {QUICK_FILTERS.map((filter) => (
            <button
              key={filter.id}
              onClick={() => setActiveFilter(filter.id)}
              className={`whitespace-nowrap px-4 py-2 rounded-xl text-sm font-medium transition-all duration-200 ${
                activeFilter === filter.id
                  ? 'bg-primary text-primary-foreground shadow-md shadow-primary/20 scale-105'
                  : 'bg-secondary text-secondary-foreground hover:bg-secondary/80'
              }`}
            >
              {filter.label}
            </button>
          ))}
        </div>
      </section>

      <AnimatePresence>
        {showAdvanced && (
          <motion.section
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden"
          >
            <div className="bg-card border rounded-2xl p-4 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-sm">סינון מתקדם</h3>
                {hasActiveAdvanced && (
                  <button onClick={clearAdvanced} className="text-xs text-primary hover:underline" data-testid="btn-clear-advanced">
                    נקה סינון
                  </button>
                )}
              </div>

              <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                <div>
                  <label className="text-xs text-muted-foreground mb-1 block">קושי</label>
                  <select
                    value={advDifficulty || ""}
                    onChange={e => setAdvDifficulty(e.target.value || undefined)}
                    className="w-full rounded-lg border bg-background px-3 py-2 text-sm"
                    data-testid="select-difficulty"
                  >
                    <option value="">הכל</option>
                    {DIFFICULTY_OPTIONS.map(d => <option key={d} value={d}>{d}</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-xs text-muted-foreground mb-1 block">מוצא</label>
                  <select
                    value={advOrigin || ""}
                    onChange={e => setAdvOrigin(e.target.value || undefined)}
                    className="w-full rounded-lg border bg-background px-3 py-2 text-sm"
                    data-testid="select-origin"
                  >
                    <option value="">הכל</option>
                    {ORIGIN_OPTIONS.map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-xs text-muted-foreground mb-1 block">זמן הכנה</label>
                  <select
                    value={advMaxPrepTime ?? ""}
                    onChange={e => setAdvMaxPrepTime(e.target.value ? Number(e.target.value) : undefined)}
                    className="w-full rounded-lg border bg-background px-3 py-2 text-sm"
                    data-testid="select-prep-time"
                  >
                    {PREP_TIME_OPTIONS.map(o => <option key={o.label} value={o.value ?? ""}>{o.label}</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-xs text-muted-foreground mb-1 block">זמן כולל</label>
                  <select
                    value={advMaxTotalTime ?? ""}
                    onChange={e => setAdvMaxTotalTime(e.target.value ? Number(e.target.value) : undefined)}
                    className="w-full rounded-lg border bg-background px-3 py-2 text-sm"
                    data-testid="select-total-time"
                  >
                    {TOTAL_TIME_OPTIONS.map(o => <option key={o.label} value={o.value ?? ""}>{o.label}</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-xs text-muted-foreground mb-1 block">מחבר</label>
                  <select
                    value={advAuthor || ""}
                    onChange={e => setAdvAuthor(e.target.value || undefined)}
                    className="w-full rounded-lg border bg-background px-3 py-2 text-sm"
                    data-testid="select-author"
                  >
                    <option value="">כל המחברים</option>
                    {authors.map(a => <option key={a} value={a}>{a}</option>)}
                  </select>
                </div>
              </div>
            </div>
          </motion.section>
        )}
      </AnimatePresence>

      <section>
        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div key={i} className="bg-card h-80 rounded-2xl animate-pulse bg-muted/50" />
            ))}
          </div>
        ) : error ? (
          <div className="text-center py-20 text-muted-foreground">
            <p>שגיאה בטעינת המתכונים. נסה לרענן.</p>
          </div>
        ) : recipes?.length === 0 ? (
          <div className="text-center py-20">
            <div className="inline-block p-4 rounded-full bg-secondary mb-4">
              <Search className="w-8 h-8 text-muted-foreground" />
            </div>
            <h3 className="text-xl font-bold text-foreground">לא נמצאו מתכונים</h3>
            <p className="text-muted-foreground mt-2">נסה לשנות את מילות החיפוש או הסינון</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {recipes?.map((recipe, index) => (
              <RecipeCard key={recipe.id} recipe={recipe} index={index} isFavorite={isFavorite(recipe.id)} onToggleFavorite={toggleFavorite} favoriteCount={getFavoriteCount(recipe.id)} />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
