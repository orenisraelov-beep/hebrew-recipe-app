import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { userFetch } from "@/lib/user-id";
import { ShoppingCart, Trash2, ArrowRight, Check, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import type { ShoppingListItem } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

export default function ShoppingListPage() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: items = [], isLoading } = useQuery<ShoppingListItem[]>({
    queryKey: ["/api/user/shopping-list"],
    queryFn: async () => {
      const res = await userFetch("/api/user/shopping-list");
      if (!res.ok) return [];
      return res.json();
    },
  });

  const toggleMutation = useMutation({
    mutationFn: async (id: number) => {
      await userFetch(`/api/user/shopping-list/${id}/toggle`, { method: "PATCH" });
    },
    onSettled: () => queryClient.invalidateQueries({ queryKey: ["/api/user/shopping-list"] }),
  });

  const removeMutation = useMutation({
    mutationFn: async (id: number) => {
      await userFetch(`/api/user/shopping-list/${id}`, { method: "DELETE" });
    },
    onMutate: async (id) => {
      await queryClient.cancelQueries({ queryKey: ["/api/user/shopping-list"] });
      const prev = queryClient.getQueryData<ShoppingListItem[]>(["/api/user/shopping-list"]);
      queryClient.setQueryData<ShoppingListItem[]>(["/api/user/shopping-list"], (old = []) => old.filter(i => i.id !== id));
      return { prev };
    },
    onError: (_err, _id, ctx) => {
      if (ctx?.prev) queryClient.setQueryData(["/api/user/shopping-list"], ctx.prev);
    },
    onSettled: () => queryClient.invalidateQueries({ queryKey: ["/api/user/shopping-list"] }),
  });

  const clearMutation = useMutation({
    mutationFn: async () => {
      await userFetch("/api/user/shopping-list", { method: "DELETE" });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user/shopping-list"] });
      toast({ title: "הרשימה נוקתה" });
    },
  });

  const unchecked = items.filter(i => !i.completed);
  const checked = items.filter(i => i.completed);

  return (
    <div className="space-y-8 max-w-2xl mx-auto">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-green-100 dark:bg-green-900/30 rounded-full">
            <ShoppingCart className="w-6 h-6 text-green-600" />
          </div>
          <h1 className="text-3xl font-black" data-testid="text-shopping-title">רשימת קניות</h1>
        </div>
        <Link href="/">
          <Button variant="ghost" size="sm" className="gap-2">
            <ArrowRight className="w-4 h-4" />
            חזרה
          </Button>
        </Link>
      </div>

      {isLoading ? (
        <div className="space-y-3">
          {[1, 2, 3, 4].map(i => (
            <div key={i} className="h-14 rounded-xl animate-pulse bg-muted/50" />
          ))}
        </div>
      ) : items.length === 0 ? (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center py-20"
        >
          <div className="inline-block p-4 rounded-full bg-secondary mb-4">
            <ShoppingCart className="w-8 h-8 text-muted-foreground" />
          </div>
          <h3 className="text-xl font-bold">הרשימה ריקה</h3>
          <p className="text-muted-foreground mt-2">הוסף מצרכים מדף המתכון</p>
          <Link href="/">
            <Button className="mt-4" data-testid="btn-browse-recipes">עיין במתכונים</Button>
          </Link>
        </motion.div>
      ) : (
        <>
          {items.length > 0 && (
            <div className="flex justify-end">
              <Button
                variant="destructive"
                size="sm"
                onClick={() => clearMutation.mutate()}
                disabled={clearMutation.isPending}
                data-testid="btn-clear-list"
              >
                <Trash2 className="w-4 h-4 ml-2" />
                נקה רשימה
              </Button>
            </div>
          )}

          {unchecked.length > 0 && (
            <div className="space-y-2">
              <AnimatePresence>
                {unchecked.map(item => (
                  <motion.div
                    key={item.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    className="flex items-center gap-3 p-3 bg-card border rounded-xl"
                    data-testid={`shopping-item-${item.id}`}
                  >
                    <button
                      onClick={() => toggleMutation.mutate(item.id)}
                      className="w-6 h-6 rounded-full border-2 border-muted-foreground/30 flex items-center justify-center hover:border-primary transition-colors flex-shrink-0"
                      data-testid={`btn-toggle-${item.id}`}
                    />
                    <div className="flex-grow min-w-0">
                      <span className="font-medium text-sm">
                        {item.quantity && <span className="text-primary font-bold">{item.quantity} </span>}
                        {item.unit && <span className="text-muted-foreground">{item.unit} </span>}
                        {item.ingredientName}
                      </span>
                      {item.recipeTitle && (
                        <p className="text-xs text-muted-foreground truncate">{item.recipeTitle}</p>
                      )}
                    </div>
                    <button
                      onClick={() => removeMutation.mutate(item.id)}
                      className="text-muted-foreground hover:text-destructive transition-colors flex-shrink-0"
                      data-testid={`btn-remove-${item.id}`}
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          )}

          {checked.length > 0 && (
            <div className="space-y-2">
              <h3 className="text-sm font-bold text-muted-foreground">הושלמו ({checked.length})</h3>
              {checked.map(item => (
                <div
                  key={item.id}
                  className="flex items-center gap-3 p-3 bg-muted/30 border border-border/30 rounded-xl opacity-60"
                  data-testid={`shopping-item-done-${item.id}`}
                >
                  <button
                    onClick={() => toggleMutation.mutate(item.id)}
                    className="w-6 h-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center flex-shrink-0"
                    data-testid={`btn-toggle-done-${item.id}`}
                  >
                    <Check className="w-3 h-3" />
                  </button>
                  <span className="flex-grow line-through text-sm text-muted-foreground">
                    {item.quantity && `${item.quantity} `}
                    {item.unit && `${item.unit} `}
                    {item.ingredientName}
                  </span>
                  <button
                    onClick={() => removeMutation.mutate(item.id)}
                    className="text-muted-foreground hover:text-destructive transition-colors flex-shrink-0"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
}
