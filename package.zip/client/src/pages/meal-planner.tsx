import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { userFetch } from "@/lib/user-id";
import { useRecipes } from "@/hooks/use-recipes";
import { Calendar, ArrowRight, Plus, X, ChefHat, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Link } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { DAYS_OF_WEEK, type MealPlan, type RecipeWithAdmin } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

export default function MealPlannerPage() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [selectingDay, setSelectingDay] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState("");

  const { data: plans = [] } = useQuery<MealPlan[]>({
    queryKey: ["/api/user/meal-plans"],
    queryFn: async () => {
      const res = await userFetch("/api/user/meal-plans");
      if (!res.ok) return [];
      return res.json();
    },
  });

  const { data: recipes = [] } = useRecipes();

  const addPlanMutation = useMutation({
    mutationFn: async ({ dayOfWeek, recipeId }: { dayOfWeek: string; recipeId: number }) => {
      await userFetch("/api/user/meal-plans", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ dayOfWeek, recipeId }),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user/meal-plans"] });
      setSelectingDay(null);
      setSearchTerm("");
      toast({ title: "המתכון נוסף לתכנון!" });
    },
  });

  const removeItemMutation = useMutation({
    mutationFn: async (id: number) => {
      await userFetch(`/api/user/meal-plans/item/${id}`, { method: "DELETE" });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user/meal-plans"] });
    },
  });

  const clearDayMutation = useMutation({
    mutationFn: async (day: string) => {
      await userFetch(`/api/user/meal-plans/${encodeURIComponent(day)}`, { method: "DELETE" });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user/meal-plans"] });
      toast({ title: "כל המתכונים ליום זה הוסרו" });
    },
  });

  const getPlansForDay = (day: string) => plans.filter(p => p.dayOfWeek === day);
  const getRecipeById = (id: number) => recipes.find(r => r.id === id);

  const filteredRecipes = searchTerm
    ? recipes.filter(r => r.title.includes(searchTerm) || r.description?.includes(searchTerm))
    : recipes;

  return (
    <div className="space-y-6 max-w-3xl mx-auto">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-blue-100 dark:bg-blue-900/30 rounded-full">
            <Calendar className="w-6 h-6 text-blue-600" />
          </div>
          <h1 className="text-3xl font-black" data-testid="text-planner-title">תכנון שבועי</h1>
        </div>
        <Link href="/">
          <Button variant="ghost" size="sm" className="gap-2">
            <ArrowRight className="w-4 h-4" />
            חזרה
          </Button>
        </Link>
      </div>

      <div className="space-y-3">
        {DAYS_OF_WEEK.map((day, i) => {
          const dayPlans = getPlansForDay(day);

          return (
            <motion.div
              key={day}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              className="bg-card border rounded-2xl p-4"
              data-testid={`day-card-${day}`}
            >
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-lg font-bold">{day}</h3>
                <div className="flex items-center gap-2">
                  {dayPlans.length > 0 && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => clearDayMutation.mutate(day)}
                      className="text-muted-foreground hover:text-destructive h-8 px-2"
                      data-testid={`btn-clear-day-${day}`}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  )}
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => { setSelectingDay(selectingDay === day ? null : day); setSearchTerm(""); }}
                    className="gap-1 h-8"
                    data-testid={`btn-add-recipe-${day}`}
                  >
                    <Plus className="w-4 h-4" />
                    הוסף מתכון
                  </Button>
                </div>
              </div>

              {dayPlans.length === 0 && selectingDay !== day && (
                <p className="text-sm text-muted-foreground py-2">אין מתכונים ליום זה</p>
              )}

              <AnimatePresence>
                {dayPlans.map(plan => {
                  const recipe = getRecipeById(plan.recipeId);
                  if (!recipe) return null;
                  return (
                    <motion.div
                      key={plan.id}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: 10 }}
                      className="flex items-center gap-3 py-2 border-b last:border-b-0"
                      data-testid={`meal-item-${plan.id}`}
                    >
                      <Link href={`/recipe/${recipe.id}`} className="flex items-center gap-3 flex-grow min-w-0 hover:text-primary transition-colors">
                        {recipe.imageUrl ? (
                          <img src={recipe.imageUrl} alt={recipe.title} className="w-12 h-12 rounded-lg object-cover flex-shrink-0" />
                        ) : (
                          <div className="w-12 h-12 rounded-lg bg-muted flex items-center justify-center flex-shrink-0">
                            <ChefHat className="w-5 h-5 text-muted-foreground" />
                          </div>
                        )}
                        <div className="min-w-0">
                          <p className="font-medium text-sm truncate">{recipe.title}</p>
                          {recipe.preparationTime && (
                            <p className="text-xs text-muted-foreground">{recipe.preparationTime} דק׳ הכנה</p>
                          )}
                        </div>
                      </Link>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => removeItemMutation.mutate(plan.id)}
                        className="text-muted-foreground flex-shrink-0 h-8 w-8"
                        data-testid={`btn-remove-item-${plan.id}`}
                      >
                        <X className="w-5 h-5" />
                      </Button>
                    </motion.div>
                  );
                })}
              </AnimatePresence>

              {selectingDay === day && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  className="mt-3 border-t pt-3"
                >
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="text-sm font-bold text-muted-foreground">בחר מתכון ליום {day}</h4>
                    <Button variant="ghost" size="icon" onClick={() => { setSelectingDay(null); setSearchTerm(""); }} className="h-7 w-7" data-testid={`btn-close-picker-${day}`}>
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                  <Input
                    type="text"
                    placeholder="חפש מתכון..."
                    value={searchTerm}
                    onChange={e => setSearchTerm(e.target.value)}
                    className="mb-3"
                    data-testid={`input-search-recipe-${day}`}
                  />
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-60 overflow-y-auto">
                    {filteredRecipes.map(r => (
                      <button
                        key={r.id}
                        onClick={() => addPlanMutation.mutate({ dayOfWeek: day, recipeId: r.id })}
                        className="flex items-center gap-3 p-2 rounded-xl hover:bg-secondary transition-colors text-right"
                        data-testid={`btn-pick-recipe-${r.id}`}
                      >
                        {r.imageUrl ? (
                          <img src={r.imageUrl} alt={r.title} className="w-10 h-10 rounded-lg object-cover flex-shrink-0" />
                        ) : (
                          <div className="w-10 h-10 rounded-lg bg-muted flex items-center justify-center flex-shrink-0">
                            <ChefHat className="w-5 h-5 text-muted-foreground" />
                          </div>
                        )}
                        <span className="text-sm font-medium truncate">{r.title}</span>
                      </button>
                    ))}
                    {filteredRecipes.length === 0 && (
                      <p className="text-sm text-muted-foreground col-span-2 text-center py-4">לא נמצאו מתכונים</p>
                    )}
                  </div>
                </motion.div>
              )}
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
