import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { KeyRound, Loader2, Eye, EyeOff } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function ChangePassword() {
  const { user, isLoading, changePassword, isChangingPassword } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [oldPassword, setOldPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPasswords, setShowPasswords] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!isLoading && !user) {
      setLocation("/auth");
    }
  }, [isLoading, user, setLocation]);

  if (isLoading || !user) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (newPassword.length < 4) {
      setError("הסיסמה חייבת להכיל לפחות 4 תווים");
      return;
    }
    if (newPassword !== confirmPassword) {
      setError("הסיסמאות אינן תואמות");
      return;
    }

    try {
      await changePassword({ oldPassword, newPassword });
      toast({ title: "הסיסמה שונתה בהצלחה" });
      setLocation("/admin");
    } catch (err: any) {
      setError(err.message || "שגיאה בשינוי הסיסמה");
    }
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center">
      <Card className="w-full max-w-md shadow-2xl shadow-primary/10 border-border/50">
        <CardHeader className="text-center pb-2">
          <div className="mx-auto w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-4">
            <KeyRound className="w-8 h-8 text-primary" />
          </div>
          <h1 className="text-2xl font-black" data-testid="text-change-password-title">שינוי סיסמה</h1>
          <p className="text-muted-foreground">
            {user.forcePasswordChange ? "יש לשנות את הסיסמה בכניסה הראשונה" : "עדכון סיסמה"}
          </p>
        </CardHeader>
        <CardContent className="pt-6">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">סיסמה נוכחית</label>
              <Input
                data-testid="input-old-password"
                type={showPasswords ? "text" : "password"}
                value={oldPassword}
                onChange={(e) => setOldPassword(e.target.value)}
                dir="ltr"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">סיסמה חדשה</label>
              <Input
                data-testid="input-new-password"
                type={showPasswords ? "text" : "password"}
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                dir="ltr"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">אימות סיסמה חדשה</label>
              <Input
                data-testid="input-confirm-password"
                type={showPasswords ? "text" : "password"}
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                dir="ltr"
              />
            </div>

            <button
              type="button"
              className="text-xs text-muted-foreground flex items-center gap-1"
              onClick={() => setShowPasswords(!showPasswords)}
            >
              {showPasswords ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
              {showPasswords ? "הסתר סיסמאות" : "הצג סיסמאות"}
            </button>

            {error && (
              <p className="text-sm text-destructive text-center" data-testid="text-error">{error}</p>
            )}

            <Button
              type="submit"
              data-testid="button-change-password"
              className="w-full h-12 text-lg font-bold"
              disabled={isChangingPassword}
            >
              {isChangingPassword ? (
                <Loader2 className="ml-2 h-5 w-5 animate-spin" />
              ) : (
                "שנה סיסמה"
              )}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
