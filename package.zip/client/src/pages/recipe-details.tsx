import { useState, useCallback, useEffect } from "react";
import { useRecipe } from "@/hooks/use-recipes";
import { useFavorites } from "@/hooks/use-favorites";
import { useRoute, Link } from "wouter";
import { ArrowRight, Clock, Users, ChefHat, Share2, Printer, Timer, Flame, Globe, Heart, ShoppingCart, Play, Pause, X, ChevronLeft, ChevronRight, Volume2, Star, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { motion, AnimatePresence } from "framer-motion";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { userFetch } from "@/lib/user-id";
import type { RecipeFull } from "@shared/schema";
import { ImageCarousel } from "@/components/image-carousel";

function ImageGallery({ recipe }: { recipe: RecipeFull }) {
  const allImages: string[] = [];
  if (recipe.images && recipe.images.length > 0) {
    recipe.images.forEach(img => allImages.push(img.imagePath));
  } else if (recipe.imageUrl) {
    allImages.push(recipe.imageUrl);
  }

  if (allImages.length === 0) {
    return (
      <div className="w-full aspect-video bg-secondary rounded-3xl flex items-center justify-center">
        <ChefHat className="w-20 h-20 text-muted-foreground/30" />
      </div>
    );
  }

  const detailOverlay = (
    <div className="absolute bottom-0 right-0 p-6 md:p-10 w-full text-white z-10 pointer-events-none">
      <div className="flex flex-wrap gap-2 mb-3">
        <span className="px-3 py-1 rounded-full bg-primary text-primary-foreground text-xs font-bold shadow-lg">
          {recipe.category}
        </span>
        {recipe.difficulty && (
          <span className="px-3 py-1 rounded-full bg-white/20 backdrop-blur text-white text-xs font-medium border border-white/30">
            {recipe.difficulty}
          </span>
        )}
        {recipe.origin && (
          <span className="px-3 py-1 rounded-full bg-white/20 backdrop-blur text-white text-xs font-medium border border-white/30">
            {recipe.origin}
          </span>
        )}
      </div>
      <h1 className="text-3xl md:text-5xl font-black tracking-tight mb-2 drop-shadow-md" data-testid="text-recipe-title">
        {recipe.title}
      </h1>
    </div>
  );

  return (
    <ImageCarousel
      images={allImages}
      alt={recipe.title}
      className="aspect-video w-full rounded-3xl shadow-2xl shadow-primary/5 border border-border/50"
      testIdPrefix="detail-carousel"
      overlay={detailOverlay}
      showGradient
    />
  );
}

function CookingMode({ recipe, onClose }: { recipe: RecipeFull; onClose: () => void }) {
  const [currentStep, setCurrentStep] = useState(0);
  const hasSteps = recipe.steps && recipe.steps.length > 0;
  const steps = hasSteps ? recipe.steps.map(s => s.stepText) : (recipe.preparation as string[]) || [];
  const stepImages = hasSteps ? recipe.steps.map(s => s.stepImagePath) : [];
  const total = steps.length;

  useEffect(() => {
    document.body.style.overflow = "hidden";
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === "ArrowLeft" && currentStep < total - 1) setCurrentStep(c => c + 1);
      if (e.key === "ArrowRight" && currentStep > 0) setCurrentStep(c => c - 1);
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", handleKey);
    return () => {
      document.body.style.overflow = "";
      window.removeEventListener("keydown", handleKey);
    };
  }, [currentStep, total, onClose]);

  const speakStep = () => {
    if ("speechSynthesis" in window) {
      window.speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(steps[currentStep]);
      u.lang = "he-IL";
      u.rate = 0.9;
      window.speechSynthesis.speak(u);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[100] bg-black text-white flex flex-col"
      dir="rtl"
    >
      <div className="flex items-center justify-between p-4 border-b border-white/10">
        <div className="flex items-center gap-3">
          <ChefHat className="w-5 h-5 text-primary" />
          <span className="font-bold text-sm truncate max-w-[200px]">{recipe.title}</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-sm text-white/60">{currentStep + 1} / {total}</span>
          <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full transition-colors" data-testid="btn-close-cooking">
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="w-full bg-white/10 h-1">
        <div className="bg-primary h-full transition-all duration-300" style={{ width: `${((currentStep + 1) / total) * 100}%` }} />
      </div>

      <div className="flex-grow flex flex-col items-center justify-center p-6 md:p-12">
        <motion.div
          key={currentStep}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center max-w-2xl w-full space-y-6"
        >
          <div className="w-16 h-16 rounded-full bg-primary/20 text-primary flex items-center justify-center text-2xl font-black mx-auto">
            {currentStep + 1}
          </div>
          <p className="text-xl md:text-3xl leading-relaxed font-medium" data-testid={`cooking-step-${currentStep}`}>
            {steps[currentStep]}
          </p>
          {stepImages[currentStep] && (
            <img src={stepImages[currentStep]!} alt={`שלב ${currentStep + 1}`} className="max-h-48 rounded-2xl mx-auto object-cover" />
          )}
          <button
            onClick={speakStep}
            className="p-3 rounded-full bg-white/10 hover:bg-white/20 transition-colors mx-auto block"
            data-testid="btn-speak-step"
          >
            <Volume2 className="w-5 h-5" />
          </button>
        </motion.div>
      </div>

      <div className="p-4 flex items-center justify-between border-t border-white/10">
        <Button
          variant="ghost"
          onClick={() => setCurrentStep(c => c - 1)}
          disabled={currentStep === 0}
          className="text-white hover:bg-white/10 gap-2"
          data-testid="btn-prev-step"
        >
          <ChevronRight className="w-5 h-5" />
          הקודם
        </Button>

        {currentStep === total - 1 ? (
          <Button onClick={onClose} className="bg-primary hover:bg-primary/90 gap-2" data-testid="btn-finish-cooking">
            סיים בישול
          </Button>
        ) : (
          <Button
            variant="ghost"
            onClick={() => setCurrentStep(c => c + 1)}
            className="text-white hover:bg-white/10 gap-2"
            data-testid="btn-next-step"
          >
            הבא
            <ChevronLeft className="w-5 h-5" />
          </Button>
        )}
      </div>
    </motion.div>
  );
}

function RatingSelector({ recipeId, currentRating, averageRating, ratingCount }: {
  recipeId: number;
  currentRating?: number;
  averageRating?: number;
  ratingCount?: number;
}) {
  const [selectedRating, setSelectedRating] = useState<number | undefined>(currentRating);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  useEffect(() => {
    setSelectedRating(currentRating);
  }, [currentRating]);

  const rateMutation = useMutation({
    mutationFn: async (rating: number) => {
      const res = await userFetch(`/api/user/rating/${recipeId}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ rating }),
      });
      if (!res.ok) throw new Error("Failed to rate");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/recipes", recipeId] });
      queryClient.invalidateQueries({ queryKey: ["/api/recipes"] });
      toast({ title: "הדירוג נשמר!" });
    },
  });

  const handleRate = (rating: number) => {
    setSelectedRating(rating);
    rateMutation.mutate(rating);
  };

  return (
    <Card className="p-5">
      <div className="flex flex-col gap-3">
        <div className="flex items-center justify-between">
          <h3 className="font-bold text-sm flex items-center gap-2">
            <Star className="w-4 h-4 text-amber-500" />
            דרג מתכון זה
          </h3>
          {averageRating && averageRating > 0 ? (
            <span className="flex items-center gap-1 text-sm font-bold text-amber-500" data-testid="text-average-rating">
              <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
              {averageRating} / 10
              <span className="text-muted-foreground font-normal text-xs">({ratingCount} דירוגים)</span>
            </span>
          ) : (
            <span className="text-xs text-muted-foreground">טרם דורג</span>
          )}
        </div>
        <div className="flex gap-1 justify-center flex-wrap" data-testid="rating-selector">
          {Array.from({ length: 10 }, (_, i) => i + 1).map(num => (
            <button
              key={num}
              type="button"
              onClick={() => handleRate(num)}
              disabled={rateMutation.isPending}
              className={`w-9 h-9 rounded-lg text-sm font-bold transition-all ${
                selectedRating && num <= selectedRating
                  ? 'bg-amber-400 text-white shadow-sm'
                  : 'bg-muted text-muted-foreground'
              }`}
              data-testid={`btn-rate-${num}`}
            >
              {num}
            </button>
          ))}
        </div>
        {selectedRating && (
          <p className="text-center text-xs text-muted-foreground">
            הדירוג שלך: <span className="font-bold text-amber-500">{selectedRating} / 10</span>
          </p>
        )}
      </div>
    </Card>
  );
}

export default function RecipeDetails() {
  const [, params] = useRoute("/recipe/:id");
  const id = parseInt(params?.id || "0");
  const { data: recipe, isLoading, error } = useRecipe(id);
  const { toast } = useToast();
  const { isFavorite, toggleFavorite, getFavoriteCount } = useFavorites();
  const queryClient = useQueryClient();
  const [cookingMode, setCookingMode] = useState(false);

  const addToShoppingMutation = useMutation({
    mutationFn: async (recipe: RecipeFull) => {
      const hasStructured = recipe.structuredIngredients && recipe.structuredIngredients.length > 0;
      const items = hasStructured
        ? recipe.structuredIngredients.map(ing => ({
            ingredientName: ing.ingredientName,
            quantity: ing.quantity || null,
            unit: ing.unit || null,
            recipeTitle: recipe.title,
          }))
        : (recipe.ingredients as string[]).map(name => ({
            ingredientName: name,
            quantity: null,
            unit: null,
            recipeTitle: recipe.title,
          }));

      const res = await userFetch("/api/user/shopping-list/batch", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ items }),
      });
      if (!res.ok) throw new Error("Failed to add items");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user/shopping-list"] });
      toast({ title: "המצרכים נוספו לרשימת הקניות!" });
    },
    onError: () => {
      toast({ title: "שגיאה בהוספה לרשימה", variant: "destructive" });
    },
  });

  if (isLoading) return (
    <div className="w-full h-[60vh] flex items-center justify-center">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
    </div>
  );

  if (error || !recipe) return (
    <div className="text-center py-20">
      <h2 className="text-2xl font-bold">המתכון לא נמצא</h2>
      <Link href="/">
        <Button className="mt-4">חזור לדף הבית</Button>
      </Link>
    </div>
  );

  const handleShare = async () => {
    const shareData = {
      title: recipe.title,
      text: `${recipe.title}\n${recipe.description || ""}\n\nמתכון מ-מתכונים חכמים`,
      url: window.location.href,
    };

    if (navigator.share) {
      try { await navigator.share(shareData); } catch {}
    } else {
      try {
        await navigator.clipboard.writeText(`${shareData.title}\n${shareData.text}\n${shareData.url}`);
        toast({ title: "הקישור הועתק!" });
      } catch {
        toast({ title: "לא ניתן לשתף", variant: "destructive" });
      }
    }
  };

  const formatTime = (minutes: number | null | undefined) => {
    if (!minutes) return null;
    if (minutes >= 60) {
      const h = Math.floor(minutes / 60);
      const m = minutes % 60;
      return m > 0 ? `${h} שעות ו-${m} דק׳` : `${h} שעות`;
    }
    return `${minutes} דק׳`;
  };

  const hasStructuredIngredients = recipe.structuredIngredients && recipe.structuredIngredients.length > 0;
  const hasSteps = recipe.steps && recipe.steps.length > 0;
  const favorite = isFavorite(recipe.id);

  return (
    <>
      <AnimatePresence>
        {cookingMode && <CookingMode recipe={recipe} onClose={() => setCookingMode(false)} />}
      </AnimatePresence>

      <article className="max-w-4xl mx-auto pb-20">
        <nav className="flex items-center justify-between gap-2 mb-6">
          <Link href="/">
            <Button variant="ghost" size="sm" className="gap-2">
              <ArrowRight className="w-4 h-4" />
              חזרה
            </Button>
          </Link>
          <div className="flex gap-2">
            <Button
              variant="outline"
              className={`rounded-full transition-all gap-1.5 px-3 ${favorite ? 'bg-red-50 border-red-200 text-red-500 dark:bg-red-900/20 dark:border-red-800' : ''}`}
              onClick={() => toggleFavorite(recipe.id)}
              data-testid="btn-toggle-favorite"
            >
              <Heart className={`w-4 h-4 ${favorite ? 'fill-current' : ''}`} />
              {getFavoriteCount(recipe.id) > 0 && (
                <span className="text-sm font-bold" data-testid="text-recipe-fav-count">{getFavoriteCount(recipe.id)}</span>
              )}
            </Button>
            <Button variant="outline" size="icon" className="rounded-full" onClick={handleShare} data-testid="button-share">
              <Share2 className="w-4 h-4" />
            </Button>
            <Button variant="outline" size="icon" className="rounded-full" onClick={() => window.print()} data-testid="button-print">
              <Printer className="w-4 h-4" />
            </Button>
          </div>
        </nav>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
          <ImageGallery recipe={recipe} />

          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {recipe.preparationTime && (
              <Card className="p-4 flex items-center gap-3">
                <div className="p-2 bg-primary/10 rounded-full text-primary"><Clock className="w-5 h-5" /></div>
                <div>
                  <p className="text-xs text-muted-foreground">זמן הכנה</p>
                  <p className="font-bold text-sm" data-testid="text-prep-time">{formatTime(recipe.preparationTime)}</p>
                </div>
              </Card>
            )}
            {recipe.totalTime && (
              <Card className="p-4 flex items-center gap-3">
                <div className="p-2 bg-blue-100 dark:bg-blue-900/30 rounded-full text-blue-600 dark:text-blue-400"><Timer className="w-5 h-5" /></div>
                <div>
                  <p className="text-xs text-muted-foreground">זמן כולל</p>
                  <p className="font-bold text-sm" data-testid="text-total-time">{formatTime(recipe.totalTime)}</p>
                </div>
              </Card>
            )}
            {recipe.servings && (
              <Card className="p-4 flex items-center gap-3">
                <div className="p-2 bg-orange-100 dark:bg-orange-900/30 rounded-full text-orange-600 dark:text-orange-400"><Users className="w-5 h-5" /></div>
                <div>
                  <p className="text-xs text-muted-foreground">מנות</p>
                  <p className="font-bold text-sm" data-testid="text-servings">{recipe.servings} סועדים</p>
                </div>
              </Card>
            )}
            {recipe.difficulty && (
              <Card className="p-4 flex items-center gap-3">
                <div className="p-2 bg-red-100 dark:bg-red-900/30 rounded-full text-red-600 dark:text-red-400"><Flame className="w-5 h-5" /></div>
                <div>
                  <p className="text-xs text-muted-foreground">קושי</p>
                  <p className="font-bold text-sm" data-testid="text-difficulty">{recipe.difficulty}</p>
                </div>
              </Card>
            )}
          </div>

          <div className="flex flex-wrap gap-2 items-center">
            {recipe.origin && (
              <Badge variant="secondary" className="gap-1"><Globe className="w-3 h-3" />{recipe.origin}</Badge>
            )}
            {recipe.tags?.map(tag => (
              <Badge key={tag} variant="outline">{tag}</Badge>
            ))}
          </div>

          {recipe.authorName && (
            <div className="flex items-center gap-2 text-sm text-muted-foreground" data-testid="text-recipe-author">
              <User className="w-4 h-4" />
              <span>הועלה ע״י: <span className="font-semibold text-foreground">{recipe.authorName}</span></span>
            </div>
          )}

          <RatingSelector
            recipeId={recipe.id}
            currentRating={recipe.userRating}
            averageRating={recipe.averageRating}
            ratingCount={recipe.ratingCount}
          />

          <div className="flex flex-wrap gap-3">
            <Button
              onClick={() => setCookingMode(true)}
              className="bg-gradient-to-r from-primary to-orange-600 gap-2 rounded-full px-6"
              data-testid="btn-cooking-mode"
            >
              <Play className="w-4 h-4" />
              מצב בישול
            </Button>
            <Button
              variant="outline"
              onClick={() => addToShoppingMutation.mutate(recipe)}
              disabled={addToShoppingMutation.isPending}
              className="gap-2 rounded-full px-6"
              data-testid="btn-add-shopping"
            >
              <ShoppingCart className="w-4 h-4" />
              {addToShoppingMutation.isPending ? "מוסיף..." : "הוסף לרשימת קניות"}
            </Button>
          </div>

          {recipe.description && (
            <p className="text-lg text-muted-foreground leading-relaxed">{recipe.description}</p>
          )}

          <div className="grid md:grid-cols-12 gap-8 mt-12">
            <div className="md:col-span-4 space-y-6">
              <div className="bg-secondary/50 p-6 rounded-3xl border border-secondary sticky top-24">
                <h2 className="text-xl font-bold flex items-center gap-2 mb-6">
                  <div className="w-1 h-6 bg-primary rounded-full" />
                  מצרכים
                </h2>
                <ul className="space-y-4">
                  {hasStructuredIngredients ? (
                    recipe.structuredIngredients.map((ing, i) => (
                      <li key={i} className="flex items-start gap-3 text-sm md:text-base" data-testid={`text-ingredient-${i}`}>
                        <input type="checkbox" className="mt-1 w-4 h-4 rounded border-gray-300 text-primary focus:ring-primary/25" />
                        <span className="leading-tight">
                          {ing.quantity && <span className="font-semibold">{ing.quantity} </span>}
                          {ing.unit && <span className="text-muted-foreground">{ing.unit} </span>}
                          {ing.ingredientName}
                        </span>
                      </li>
                    ))
                  ) : (
                    (recipe.ingredients as string[]).map((ingredient, i) => (
                      <li key={i} className="flex items-start gap-3 text-sm md:text-base">
                        <input type="checkbox" className="mt-1 w-4 h-4 rounded border-gray-300 text-primary focus:ring-primary/25" />
                        <span className="leading-tight">{ingredient}</span>
                      </li>
                    ))
                  )}
                </ul>
              </div>
            </div>

            <div className="md:col-span-8 space-y-8">
              <h2 className="text-2xl font-bold flex items-center gap-3">
                <ChefHat className="w-6 h-6 text-primary" />
                אופן ההכנה
              </h2>

              <div className="space-y-8 relative before:absolute before:top-4 before:bottom-0 before:right-4 before:w-0.5 before:bg-border/50">
                {hasSteps ? (
                  recipe.steps.map((step, i) => (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, x: -20 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: i * 0.1 }}
                      className="relative pr-12"
                    >
                      <span className="absolute right-0 top-0 w-8 h-8 rounded-full bg-background border-2 border-primary text-primary flex items-center justify-center font-bold text-sm shadow-sm z-10">
                        {step.stepNumber}
                      </span>
                      <div className="bg-card p-5 rounded-2xl border shadow-sm">
                        <p className="text-foreground leading-relaxed" data-testid={`text-step-${i}`}>{step.stepText}</p>
                        {step.stepImagePath && (
                          <div className="mt-3 rounded-xl overflow-hidden">
                            <img src={step.stepImagePath} alt={`שלב ${step.stepNumber}`} className="w-full max-h-64 object-cover" />
                          </div>
                        )}
                      </div>
                    </motion.div>
                  ))
                ) : (
                  (recipe.preparation as string[]).map((step, i) => (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, x: -20 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: i * 0.1 }}
                      className="relative pr-12"
                    >
                      <span className="absolute right-0 top-0 w-8 h-8 rounded-full bg-background border-2 border-primary text-primary flex items-center justify-center font-bold text-sm shadow-sm z-10">
                        {i + 1}
                      </span>
                      <div className="bg-card p-5 rounded-2xl border shadow-sm">
                        <p className="text-foreground leading-relaxed">{step}</p>
                      </div>
                    </motion.div>
                  ))
                )}
              </div>

              <div className="bg-primary/5 p-6 rounded-2xl border border-primary/10 mt-12 text-center">
                <h3 className="text-lg font-bold text-primary mb-2">בתאבון!</h3>
                <p className="text-sm text-muted-foreground">אהבת את המתכון? שתף אותו עם חברים</p>
                <Button variant="outline" size="sm" className="mt-3" onClick={handleShare} data-testid="button-share-bottom">
                  <Share2 className="w-4 h-4 ml-2" />
                  שתף מתכון
                </Button>
              </div>
            </div>
          </div>
        </motion.div>
      </article>
    </>
  );
}
