import { useQuery } from "@tanstack/react-query";
import { userFetch } from "@/lib/user-id";
import { RecipeCard } from "@/components/recipe-card";
import { useFavorites } from "@/hooks/use-favorites";
import { Heart, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { motion } from "framer-motion";
import type { RecipeWithAdmin } from "@shared/schema";

export default function FavoritesPage() {
  const { isFavorite, toggleFavorite, getFavoriteCount } = useFavorites();

  const { data: recipes = [], isLoading } = useQuery<RecipeWithAdmin[]>({
    queryKey: ["/api/user/favorites/recipes"],
    queryFn: async () => {
      const res = await userFetch("/api/user/favorites/recipes");
      if (!res.ok) return [];
      return res.json();
    },
  });

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-red-100 dark:bg-red-900/30 rounded-full">
            <Heart className="w-6 h-6 text-red-500" />
          </div>
          <h1 className="text-3xl font-black" data-testid="text-favorites-title">המועדפים שלי</h1>
        </div>
        <Link href="/">
          <Button variant="ghost" size="sm" className="gap-2" data-testid="link-back-home">
            <ArrowRight className="w-4 h-4" />
            חזרה
          </Button>
        </Link>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3].map((i) => (
            <div key={i} className="bg-card h-80 rounded-2xl animate-pulse bg-muted/50" />
          ))}
        </div>
      ) : recipes.length === 0 ? (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center py-20"
        >
          <div className="inline-block p-4 rounded-full bg-secondary mb-4">
            <Heart className="w-8 h-8 text-muted-foreground" />
          </div>
          <h3 className="text-xl font-bold text-foreground">אין מועדפים עדיין</h3>
          <p className="text-muted-foreground mt-2">לחץ על הלב במתכונים כדי להוסיף אותם לכאן</p>
          <Link href="/">
            <Button className="mt-4" data-testid="btn-browse-recipes">עיין במתכונים</Button>
          </Link>
        </motion.div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {recipes.map((recipe, index) => (
            <RecipeCard
              key={recipe.id}
              recipe={recipe}
              index={index}
              isFavorite={isFavorite(recipe.id)}
              onToggleFavorite={toggleFavorite}
              favoriteCount={getFavoriteCount(recipe.id)}
            />
          ))}
        </div>
      )}
    </div>
  );
}
