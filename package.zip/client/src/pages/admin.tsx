import { useState, useRef, useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useRecipes, useCreateRecipe, useUpdateRecipe, useDeleteRecipe, uploadImage } from "@/hooks/use-recipes";
import { useAdmins, useCreateAdmin, useDeleteAdmin, useToggleAdminActive } from "@/hooks/use-admins";
import { type RecipeWithAdmin, type AdminSafe, type IngredientCategory, type IngredientMasterWithCategory, DIFFICULTY_OPTIONS, ORIGIN_OPTIONS, UNIT_OPTIONS } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Plus, Trash2, Save, Loader2, Camera, Upload, LogOut,
  Edit2, Users, ChefHat, Shield, ShieldCheck, Power, KeyRound,
  X, Check, ImagePlus, Clock, GripVertical, Apple, Search
} from "lucide-react";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { IngredientAutocomplete } from "@/components/ingredient-autocomplete";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";

type Tab = "recipes" | "add-recipe" | "edit-recipe" | "admins" | "ingredients";

export default function Admin() {
  const { user, isLoading: isAuthLoading, logout, isSuperAdmin } = useAuth();
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState<Tab>("recipes");
  const [editingRecipe, setEditingRecipe] = useState<RecipeWithAdmin | null>(null);

  useEffect(() => {
    if (!isAuthLoading && !user) setLocation("/auth");
    if (user?.forcePasswordChange) setLocation("/change-password");
  }, [user, isAuthLoading, setLocation]);

  if (isAuthLoading || !user) {
    return <div className="flex justify-center p-20"><Loader2 className="animate-spin" /></div>;
  }

  const handleEditRecipe = (recipe: RecipeWithAdmin) => {
    setEditingRecipe(recipe);
    setActiveTab("edit-recipe");
  };

  const handleBackToList = () => {
    setEditingRecipe(null);
    setActiveTab("recipes");
  };

  const tabs = [
    { id: "recipes" as Tab, label: "מתכונים", icon: ChefHat },
    { id: "add-recipe" as Tab, label: "הוסף מתכון", icon: Plus },
    { id: "ingredients" as Tab, label: "ניהול מצרכים", icon: Apple },
    ...(isSuperAdmin ? [{ id: "admins" as Tab, label: "ניהול מנהלים", icon: Users }] : []),
  ];

  return (
    <div className="max-w-4xl mx-auto pb-20">
      <div className="flex items-center justify-between gap-2 mb-6">
        <div>
          <h1 className="text-3xl font-black" data-testid="text-admin-title">לוח בקרה</h1>
          <p className="text-muted-foreground">
            שלום, <span className="font-medium text-foreground">{user.username}</span>
            {isSuperAdmin && <Badge variant="secondary" className="mr-2">סופר מנהל</Badge>}
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="ghost" size="sm" onClick={() => setLocation("/change-password")} data-testid="button-change-password">
            <KeyRound className="w-4 h-4 ml-1" />
            שנה סיסמה
          </Button>
          <Button variant="outline" size="sm" onClick={() => logout()} data-testid="button-logout">
            <LogOut className="w-4 h-4 ml-1" />
            יציאה
          </Button>
        </div>
      </div>

      {activeTab !== "edit-recipe" && (
        <div className="flex gap-2 mb-6 overflow-x-auto no-scrollbar">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => { setActiveTab(tab.id); setEditingRecipe(null); }}
                data-testid={`tab-${tab.id}`}
                className={`flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium whitespace-nowrap transition-all
                  ${activeTab === tab.id ? "bg-primary text-primary-foreground shadow-md" : "bg-secondary text-secondary-foreground"}`}
              >
                <Icon className="w-4 h-4" />
                {tab.label}
              </button>
            );
          })}
        </div>
      )}

      {activeTab === "recipes" && <RecipesList onEdit={handleEditRecipe} isSuperAdmin={isSuperAdmin} currentAdminId={user.id} />}
      {activeTab === "add-recipe" && <RecipeForm onSuccess={() => setActiveTab("recipes")} />}
      {activeTab === "edit-recipe" && editingRecipe && (
        <RecipeForm recipeId={editingRecipe.id} onSuccess={handleBackToList} onCancel={handleBackToList} />
      )}
      {activeTab === "ingredients" && <IngredientsManagement />}
      {activeTab === "admins" && isSuperAdmin && <AdminsManagement currentAdminId={user.id} />}
    </div>
  );
}

function RecipesList({ onEdit, isSuperAdmin, currentAdminId }: { onEdit: (r: RecipeWithAdmin) => void; isSuperAdmin: boolean; currentAdminId: number }) {
  const { data: recipes, isLoading } = useRecipes();
  const deleteRecipe = useDeleteRecipe();

  if (isLoading) {
    return (
      <div className="space-y-4">
        {[1, 2, 3].map((i) => <div key={i} className="h-20 bg-muted/50 rounded-md animate-pulse" />)}
      </div>
    );
  }

  if (!recipes?.length) {
    return (
      <div className="text-center py-20 text-muted-foreground">
        <ChefHat className="w-12 h-12 mx-auto mb-4 opacity-30" />
        <p className="text-lg font-medium">אין מתכונים עדיין</p>
        <p className="text-sm">לחץ על "הוסף מתכון" כדי להתחיל</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <p className="text-sm text-muted-foreground mb-4">{recipes.length} מתכונים</p>
      {recipes.map((recipe) => {
        const canEdit = isSuperAdmin || recipe.createdByAdminId === currentAdminId;
        return (
          <Card key={recipe.id} className="overflow-visible" data-testid={`card-recipe-${recipe.id}`}>
            <CardContent className="p-4">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-md overflow-hidden bg-muted flex-shrink-0">
                  {recipe.imageUrl ? (
                    <img src={recipe.imageUrl} alt={recipe.title} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center"><ChefHat className="w-6 h-6 text-muted-foreground/30" /></div>
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-bold truncate">{recipe.title}</h3>
                  <div className="flex flex-wrap items-center gap-1 mt-1">
                    <Badge variant="secondary">{recipe.category}</Badge>
                    {recipe.difficulty && <Badge variant="outline">{recipe.difficulty}</Badge>}
                    {recipe.origin && <Badge variant="outline">{recipe.origin}</Badge>}
                    {recipe.createdByAdmin && (
                      <span className="text-xs text-muted-foreground">נוצר ע״י {recipe.createdByAdmin}</span>
                    )}
                  </div>
                </div>
                {canEdit && (
                  <div className="flex gap-1 flex-shrink-0">
                    <Button size="icon" variant="ghost" onClick={() => onEdit(recipe)} data-testid={`button-edit-recipe-${recipe.id}`}>
                      <Edit2 className="w-4 h-4" />
                    </Button>
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={() => {
                        if (confirm("האם למחוק את המתכון?")) deleteRecipe.mutate(recipe.id);
                      }}
                      data-testid={`button-delete-recipe-${recipe.id}`}
                    >
                      <Trash2 className="w-4 h-4 text-destructive" />
                    </Button>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}

interface StepInput { stepText: string; stepImagePath: string | null; }
interface IngredientInput { ingredientName: string; quantity: string; unit: string; }
interface ImageInput { imagePath: string; }

function RecipeForm({ recipeId, onSuccess, onCancel }: { recipeId?: number; onSuccess: () => void; onCancel?: () => void }) {
  const createRecipe = useCreateRecipe();
  const updateRecipe = useUpdateRecipe();
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const galleryInputRef = useRef<HTMLInputElement>(null);
  const galleryCameraRef = useRef<HTMLInputElement>(null);

  const isEditing = !!recipeId;

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("Parve");
  const [preparationTime, setPreparationTime] = useState("");
  const [totalTime, setTotalTime] = useState("");
  const [servings, setServings] = useState("");
  const [difficulty, setDifficulty] = useState("");
  const [origin, setOrigin] = useState("");
  const [customOrigin, setCustomOrigin] = useState("");
  const [authorName, setAuthorName] = useState("");
  const [tags, setTags] = useState<string[]>([]);
  const [suitableDays, setSuitableDays] = useState<string[]>([]);
  const [suitableHolidays, setSuitableHolidays] = useState<string[]>([]);
  const [imageUrl, setImageUrl] = useState("");

  const [galleryImages, setGalleryImages] = useState<ImageInput[]>([]);
  const [steps, setSteps] = useState<StepInput[]>([{ stepText: "", stepImagePath: null }]);
  const [structuredIngredients, setStructuredIngredients] = useState<IngredientInput[]>([{ ingredientName: "", quantity: "", unit: "" }]);

  const [uploading, setUploading] = useState(false);
  const [loaded, setLoaded] = useState(!isEditing);

  useEffect(() => {
    if (isEditing && recipeId) {
      fetch(`/api/recipes/${recipeId}`, { credentials: "include" })
        .then(r => r.json())
        .then((recipe: any) => {
          setTitle(recipe.title || "");
          setDescription(recipe.description || "");
          setCategory(recipe.category || "Parve");
          setPreparationTime(recipe.preparationTime?.toString() || "");
          setTotalTime(recipe.totalTime?.toString() || "");
          setServings(recipe.servings?.toString() || "");
          setDifficulty(recipe.difficulty || "");
          setOrigin(recipe.origin || "");
          setAuthorName(recipe.authorName || "");
          setTags(recipe.tags || []);
          setSuitableDays(recipe.suitableDays || []);
          setSuitableHolidays(recipe.suitableHolidays || []);
          setImageUrl(recipe.imageUrl || "");

          if (recipe.images?.length > 0) {
            setGalleryImages(recipe.images.map((img: any) => ({ imagePath: img.imagePath })));
          }

          if (recipe.steps?.length > 0) {
            setSteps(recipe.steps.map((s: any) => ({ stepText: s.stepText, stepImagePath: s.stepImagePath || null })));
          } else if (recipe.preparation?.length > 0) {
            setSteps(recipe.preparation.map((p: string) => ({ stepText: p, stepImagePath: null })));
          }

          if (recipe.structuredIngredients?.length > 0) {
            setStructuredIngredients(recipe.structuredIngredients.map((ing: any) => ({
              ingredientName: ing.ingredientName, quantity: ing.quantity || "", unit: ing.unit || "",
            })));
          } else if (recipe.ingredients?.length > 0) {
            setStructuredIngredients(recipe.ingredients.map((name: string) => ({
              ingredientName: name, quantity: "", unit: "",
            })));
          }

          setLoaded(true);
        });
    }
  }, [isEditing, recipeId]);

  const handleImageUpload = async (file: File, callback: (url: string) => void) => {
    setUploading(true);
    try {
      const url = await uploadImage(file);
      callback(url);
      toast({ title: "התמונה הועלתה בהצלחה" });
    } catch (err) {
      toast({ title: "שגיאה בהעלאת התמונה", variant: "destructive" });
    } finally {
      setUploading(false);
    }
  };

  const handleGalleryUpload = async (files: FileList) => {
    setUploading(true);
    try {
      const newImages: ImageInput[] = [];
      for (const file of Array.from(files)) {
        const url = await uploadImage(file);
        newImages.push({ imagePath: url });
      }
      setGalleryImages(prev => [...prev, ...newImages]);
      toast({ title: `${newImages.length} תמונות הועלו בהצלחה` });
    } catch (err) {
      toast({ title: "שגיאה בהעלאת תמונות", variant: "destructive" });
    } finally {
      setUploading(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      toast({ title: "יש להזין כותרת למתכון", variant: "destructive" });
      return;
    }

    if (!authorName.trim()) {
      toast({ title: "יש להזין שם מחבר", variant: "destructive" });
      return;
    }

    const finalOrigin = origin === "__custom" ? customOrigin : origin;

    const legacyIngredients = structuredIngredients.filter(i => i.ingredientName.trim()).map(i => {
      const parts = [i.quantity, i.unit, i.ingredientName].filter(Boolean);
      return parts.join(" ");
    });

    const legacyPreparation = steps.filter(s => s.stepText.trim()).map(s => s.stepText);

    const payload: any = {
      title: title.trim(),
      description: description.trim(),
      category,
      preparationTime: preparationTime ? parseInt(preparationTime) : null,
      totalTime: totalTime ? parseInt(totalTime) : null,
      servings: servings ? parseInt(servings) : null,
      difficulty: difficulty || null,
      origin: finalOrigin || null,
      authorName: authorName.trim(),
      tags,
      suitableDays,
      suitableHolidays,
      imageUrl: galleryImages.length > 0 ? galleryImages[0].imagePath : imageUrl || null,
      ingredients: legacyIngredients,
      preparation: legacyPreparation,
      images: galleryImages,
      steps: steps.filter(s => s.stepText.trim()),
      structuredIngredients: structuredIngredients.filter(i => i.ingredientName.trim()),
    };

    if (isEditing && recipeId) {
      updateRecipe.mutate({ id: recipeId, ...payload }, { onSuccess });
    } else {
      createRecipe.mutate(payload, { onSuccess: () => { onSuccess(); } });
    }
  };

  if (!loaded) {
    return <div className="flex justify-center p-20"><Loader2 className="animate-spin" /></div>;
  }

  const TAG_OPTIONS = ["שבת", "יום חול", "חג", "חורף", "קיץ", "קינוח", "בשרי", "חלבי", "פרווה", "מהיר", "קל", "טבעוני", "צמחוני"];
  const DAY_OPTIONS = ["ראשון", "שני", "שלישי", "רביעי", "חמישי", "שישי", "שבת"];
  const HOLIDAY_OPTIONS = ["ראש השנה", "יום כיפור", "סוכות", "חנוכה", "פורים", "פסח", "שבועות", "ט״ו בשבט"];

  return (
    <div>
      {isEditing && (
        <div className="flex items-center justify-between gap-2 mb-4">
          <h2 className="text-xl font-bold">עריכת מתכון</h2>
          <Button variant="ghost" size="sm" onClick={onCancel} data-testid="button-cancel-edit">
            <X className="w-4 h-4 ml-1" /> ביטול
          </Button>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        <Card>
          <CardHeader><CardTitle>פרטים כלליים</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-sm font-medium block mb-1.5">כותרת המתכון</label>
              <Input value={title} onChange={e => setTitle(e.target.value)} placeholder="לדוגמה: עוגת גבינה פירורים" data-testid="input-recipe-title" />
            </div>
            <div>
              <label className="text-sm font-medium block mb-1.5">תיאור קצר</label>
              <Textarea value={description} onChange={e => setDescription(e.target.value)} placeholder="כמה מילים על המתכון..." data-testid="input-recipe-description" />
            </div>
            <div>
              <label className="text-sm font-medium block mb-1.5">שם המחבר <span className="text-destructive">*</span></label>
              <Input value={authorName} onChange={e => setAuthorName(e.target.value)} placeholder="לדוגמה: דוד כהן" data-testid="input-author-name" />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium block mb-1.5">קטגוריה</label>
                <Select value={category} onValueChange={setCategory}>
                  <SelectTrigger data-testid="select-category"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Meat">בשרי</SelectItem>
                    <SelectItem value="Dairy">חלבי</SelectItem>
                    <SelectItem value="Parve">פרווה</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-sm font-medium block mb-1.5">רמת קושי</label>
                <Select value={difficulty} onValueChange={setDifficulty}>
                  <SelectTrigger data-testid="select-difficulty"><SelectValue placeholder="בחר רמת קושי" /></SelectTrigger>
                  <SelectContent>
                    {DIFFICULTY_OPTIONS.map(d => <SelectItem key={d} value={d}>{d}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div>
                <label className="text-sm font-medium block mb-1.5">זמן הכנה (דקות)</label>
                <Input type="number" min={0} value={preparationTime} onChange={e => setPreparationTime(e.target.value)} placeholder="15" data-testid="input-prep-time" />
              </div>
              <div>
                <label className="text-sm font-medium block mb-1.5">זמן כולל (דקות)</label>
                <Input type="number" min={0} value={totalTime} onChange={e => setTotalTime(e.target.value)} placeholder="60" data-testid="input-total-time" />
              </div>
              <div>
                <label className="text-sm font-medium block mb-1.5">מנות</label>
                <Input type="number" min={1} value={servings} onChange={e => setServings(e.target.value)} placeholder="4" data-testid="input-servings" />
              </div>
            </div>

            <div>
              <label className="text-sm font-medium block mb-1.5">מוצא המתכון</label>
              <Select value={origin} onValueChange={(v) => { setOrigin(v); if (v !== "__custom") setCustomOrigin(""); }}>
                <SelectTrigger data-testid="select-origin"><SelectValue placeholder="בחר מוצא" /></SelectTrigger>
                <SelectContent>
                  {ORIGIN_OPTIONS.map(o => <SelectItem key={o} value={o}>{o}</SelectItem>)}
                  <SelectItem value="__custom">אחר (הקלד)</SelectItem>
                </SelectContent>
              </Select>
              {origin === "__custom" && (
                <Input className="mt-2" value={customOrigin} onChange={e => setCustomOrigin(e.target.value)} placeholder="הכנס מוצא..." data-testid="input-custom-origin" />
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>גלריית תמונות</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            {galleryImages.length > 0 && (
              <div className="grid grid-cols-3 gap-3">
                {galleryImages.map((img, i) => (
                  <div key={i} className="relative aspect-square rounded-md overflow-hidden bg-muted">
                    <img src={img.imagePath} alt={`תמונה ${i + 1}`} className="w-full h-full object-cover" />
                    <Button
                      type="button"
                      size="icon"
                      variant="secondary"
                      className="absolute top-1 left-1 h-6 w-6"
                      onClick={() => setGalleryImages(prev => prev.filter((_, idx) => idx !== i))}
                    >
                      <X className="w-3 h-3" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
            <div className="flex flex-wrap gap-2">
              <input type="file" ref={galleryInputRef} accept="image/*" multiple className="hidden" onChange={(e) => {
                if (e.target.files) handleGalleryUpload(e.target.files);
                e.target.value = "";
              }} />
              <input type="file" ref={galleryCameraRef} accept="image/*" capture="environment" className="hidden" onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) handleImageUpload(file, (url) => setGalleryImages(prev => [...prev, { imagePath: url }]));
                e.target.value = "";
              }} />
              <Button type="button" variant="outline" onClick={() => galleryInputRef.current?.click()} disabled={uploading} data-testid="button-upload-gallery">
                {uploading ? <Loader2 className="w-4 h-4 ml-2 animate-spin" /> : <Upload className="w-4 h-4 ml-2" />}
                העלה תמונות
              </Button>
              <Button type="button" variant="outline" onClick={() => galleryCameraRef.current?.click()} disabled={uploading} data-testid="button-capture-gallery">
                <Camera className="w-4 h-4 ml-2" />
                צלם תמונה
              </Button>
            </div>
            {galleryImages.length === 0 && (
              <div>
                <label className="text-sm font-medium block mb-1.5">או הכנס קישור לתמונה ראשית</label>
                <Input value={imageUrl} onChange={e => setImageUrl(e.target.value)} placeholder="https://..." dir="ltr" data-testid="input-image-url" />
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>מצרכים</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            {structuredIngredients.map((ing, index) => (
              <div key={index} className="flex gap-2 items-start">
                <div className="w-20">
                  <Input
                    placeholder="כמות"
                    value={ing.quantity}
                    onChange={e => {
                      const updated = [...structuredIngredients];
                      updated[index] = { ...updated[index], quantity: e.target.value };
                      setStructuredIngredients(updated);
                    }}
                    data-testid={`input-ing-qty-${index}`}
                  />
                </div>
                <div className="w-24">
                  <Select
                    value={ing.unit}
                    onValueChange={v => {
                      const updated = [...structuredIngredients];
                      updated[index] = { ...updated[index], unit: v };
                      setStructuredIngredients(updated);
                    }}
                  >
                    <SelectTrigger data-testid={`select-ing-unit-${index}`}><SelectValue placeholder="יחידה" /></SelectTrigger>
                    <SelectContent>
                      {UNIT_OPTIONS.map(u => <SelectItem key={u} value={u}>{u}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <IngredientAutocomplete
                  placeholder={`מצרך ${index + 1}`}
                  value={ing.ingredientName}
                  onChange={v => {
                    const updated = [...structuredIngredients];
                    updated[index] = { ...updated[index], ingredientName: v };
                    setStructuredIngredients(updated);
                  }}
                  testId={`input-ing-name-${index}`}
                />
                <Button type="button" variant="ghost" size="icon" onClick={() => {
                  setStructuredIngredients(prev => prev.filter((_, i) => i !== index));
                }}>
                  <Trash2 className="h-4 w-4 text-destructive" />
                </Button>
              </div>
            ))}
            <Button type="button" variant="outline" size="sm" className="w-full border-dashed" onClick={() => setStructuredIngredients(prev => [...prev, { ingredientName: "", quantity: "", unit: "" }])} data-testid="button-add-ingredient">
              <Plus className="h-4 w-4 ml-2" /> הוסף מצרך
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>שלבי הכנה</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            {steps.map((step, index) => (
              <div key={index} className="border rounded-md p-3 space-y-3">
                <div className="flex items-start gap-2">
                  <span className="mt-2.5 text-sm font-bold text-muted-foreground w-6 text-center">{index + 1}.</span>
                  <div className="flex-1">
                    <Textarea
                      placeholder={`שלב ${index + 1}`}
                      value={step.stepText}
                      onChange={e => {
                        const updated = [...steps];
                        updated[index] = { ...updated[index], stepText: e.target.value };
                        setSteps(updated);
                      }}
                      data-testid={`input-step-${index}`}
                    />
                  </div>
                  <Button type="button" variant="ghost" size="icon" onClick={() => setSteps(prev => prev.filter((_, i) => i !== index))}>
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </div>
                {step.stepImagePath && (
                  <div className="relative w-32 h-24 rounded-md overflow-hidden bg-muted mr-8">
                    <img src={step.stepImagePath} alt={`שלב ${index + 1}`} className="w-full h-full object-cover" />
                    <Button type="button" size="icon" variant="secondary" className="absolute top-1 left-1 h-5 w-5" onClick={() => {
                      const updated = [...steps];
                      updated[index] = { ...updated[index], stepImagePath: null };
                      setSteps(updated);
                    }}>
                      <X className="w-3 h-3" />
                    </Button>
                  </div>
                )}
                <div className="mr-8">
                  <StepImageUploader
                    index={index}
                    uploading={uploading}
                    onUpload={(url) => {
                      const updated = [...steps];
                      updated[index] = { ...updated[index], stepImagePath: url };
                      setSteps(updated);
                    }}
                    handleImageUpload={handleImageUpload}
                  />
                </div>
              </div>
            ))}
            <Button type="button" variant="outline" size="sm" className="w-full border-dashed" onClick={() => setSteps(prev => [...prev, { stepText: "", stepImagePath: null }])} data-testid="button-add-step">
              <Plus className="h-4 w-4 ml-2" /> הוסף שלב
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>תגיות וסיווג</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-2 block">תגיות</label>
              <div className="flex flex-wrap gap-2">
                {TAG_OPTIONS.map((tag) => {
                  const isActive = tags.includes(tag);
                  return (
                    <Badge
                      key={tag}
                      variant={isActive ? "default" : "outline"}
                      className="cursor-pointer"
                      onClick={() => setTags(prev => isActive ? prev.filter(t => t !== tag) : [...prev, tag])}
                      data-testid={`tag-${tag}`}
                    >
                      {isActive && <Check className="w-3 h-3 ml-1" />}
                      {tag}
                    </Badge>
                  );
                })}
              </div>
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">מתאים לימים</label>
              <div className="flex flex-wrap gap-2">
                {DAY_OPTIONS.map((day) => {
                  const isActive = suitableDays.includes(day);
                  return (
                    <Badge
                      key={day}
                      variant={isActive ? "default" : "outline"}
                      className="cursor-pointer"
                      onClick={() => setSuitableDays(prev => isActive ? prev.filter(d => d !== day) : [...prev, day])}
                      data-testid={`day-${day}`}
                    >
                      {isActive && <Check className="w-3 h-3 ml-1" />}
                      {day}
                    </Badge>
                  );
                })}
              </div>
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">מתאים לחגים</label>
              <div className="flex flex-wrap gap-2">
                {HOLIDAY_OPTIONS.map((holiday) => {
                  const isActive = suitableHolidays.includes(holiday);
                  return (
                    <Badge
                      key={holiday}
                      variant={isActive ? "default" : "outline"}
                      className="cursor-pointer"
                      onClick={() => setSuitableHolidays(prev => isActive ? prev.filter(h => h !== holiday) : [...prev, holiday])}
                      data-testid={`holiday-${holiday}`}
                    >
                      {isActive && <Check className="w-3 h-3 ml-1" />}
                      {holiday}
                    </Badge>
                  );
                })}
              </div>
            </div>
          </CardContent>
        </Card>

        <Button
          type="submit"
          className="w-full h-12 text-lg font-bold shadow-lg shadow-primary/20"
          disabled={createRecipe.isPending || updateRecipe.isPending}
          data-testid="button-save-recipe"
        >
          {(createRecipe.isPending || updateRecipe.isPending) ? (
            <><Loader2 className="ml-2 h-5 w-5 animate-spin" /> שומר...</>
          ) : (
            <><Save className="ml-2 h-5 w-5" /> {isEditing ? "עדכן מתכון" : "שמור מתכון"}</>
          )}
        </Button>
      </form>
    </div>
  );
}

function StepImageUploader({ index, uploading, onUpload, handleImageUpload }: {
  index: number; uploading: boolean;
  onUpload: (url: string) => void;
  handleImageUpload: (file: File, callback: (url: string) => void) => void;
}) {
  const fileRef = useRef<HTMLInputElement>(null);
  const camRef = useRef<HTMLInputElement>(null);

  return (
    <div className="flex gap-2">
      <input type="file" ref={fileRef} accept="image/*" className="hidden" onChange={(e) => {
        const file = e.target.files?.[0];
        if (file) handleImageUpload(file, onUpload);
        e.target.value = "";
      }} />
      <input type="file" ref={camRef} accept="image/*" capture="environment" className="hidden" onChange={(e) => {
        const file = e.target.files?.[0];
        if (file) handleImageUpload(file, onUpload);
        e.target.value = "";
      }} />
      <Button type="button" variant="ghost" size="sm" onClick={() => fileRef.current?.click()} disabled={uploading}>
        <ImagePlus className="w-3 h-3 ml-1" />
        תמונה לשלב
      </Button>
      <Button type="button" variant="ghost" size="sm" onClick={() => camRef.current?.click()} disabled={uploading}>
        <Camera className="w-3 h-3 ml-1" />
        צלם
      </Button>
    </div>
  );
}

function IngredientsManagement() {
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [filterCategoryId, setFilterCategoryId] = useState<string>("all");
  const [showCategoryForm, setShowCategoryForm] = useState(false);
  const [newCategoryName, setNewCategoryName] = useState("");
  const [editingCategoryId, setEditingCategoryId] = useState<number | null>(null);
  const [editingCategoryName, setEditingCategoryName] = useState("");
  const [showIngredientForm, setShowIngredientForm] = useState(false);
  const [newIngName, setNewIngName] = useState("");
  const [newIngCategoryId, setNewIngCategoryId] = useState<string>("");
  const [newIngSubcategory, setNewIngSubcategory] = useState("");
  const [editingIngId, setEditingIngId] = useState<number | null>(null);
  const [editingIngName, setEditingIngName] = useState("");
  const [editingIngCategoryId, setEditingIngCategoryId] = useState<string>("");
  const [editingIngSubcategory, setEditingIngSubcategory] = useState("");

  const { data: categories, isLoading: catsLoading } = useQuery<IngredientCategory[]>({
    queryKey: ["/api/ingredient-categories"],
  });

  const searchParam = search ? `?search=${encodeURIComponent(search)}` : "";
  const categoryParam = filterCategoryId !== "all"
    ? `${searchParam ? "&" : "?"}categoryId=${filterCategoryId}`
    : "";
  const { data: ingredients, isLoading: ingsLoading } = useQuery<IngredientMasterWithCategory[]>({
    queryKey: ["/api/ingredients", search, filterCategoryId],
    queryFn: () => fetch(`/api/ingredients${searchParam}${categoryParam}`).then(r => r.json()),
  });

  const createCategory = useMutation({
    mutationFn: (nameHebrew: string) => apiRequest("POST", "/api/admin/ingredient-categories", { nameHebrew }),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["/api/ingredient-categories"] }); setNewCategoryName(""); setShowCategoryForm(false); toast({ title: "הקטגוריה נוספה" }); },
    onError: () => toast({ title: "שגיאה ביצירת קטגוריה", variant: "destructive" }),
  });

  const updateCategory = useMutation({
    mutationFn: ({ id, nameHebrew }: { id: number; nameHebrew: string }) => apiRequest("PUT", `/api/admin/ingredient-categories/${id}`, { nameHebrew }),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["/api/ingredient-categories"] }); queryClient.invalidateQueries({ queryKey: ["/api/ingredients"] }); setEditingCategoryId(null); toast({ title: "הקטגוריה עודכנה" }); },
  });

  const deleteCategory = useMutation({
    mutationFn: (id: number) => apiRequest("DELETE", `/api/admin/ingredient-categories/${id}`),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["/api/ingredient-categories"] }); queryClient.invalidateQueries({ queryKey: ["/api/ingredients"] }); toast({ title: "הקטגוריה נמחקה" }); },
  });

  const createIngredient = useMutation({
    mutationFn: (data: { nameHebrew: string; categoryId: number | null; subcategory?: string | null }) => apiRequest("POST", "/api/admin/ingredients", data),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["/api/ingredients"] }); queryClient.invalidateQueries({ queryKey: ["/api/ingredient-categories"] }); setNewIngName(""); setNewIngCategoryId(""); setNewIngSubcategory(""); setShowIngredientForm(false); toast({ title: "המצרך נוסף" }); },
    onError: () => toast({ title: "שגיאה ביצירת מצרך", variant: "destructive" }),
  });

  const updateIngredient = useMutation({
    mutationFn: ({ id, nameHebrew, categoryId, subcategory }: { id: number; nameHebrew: string; categoryId: number | null; subcategory?: string | null }) =>
      apiRequest("PUT", `/api/admin/ingredients/${id}`, { nameHebrew, categoryId, subcategory }),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["/api/ingredients"] }); queryClient.invalidateQueries({ queryKey: ["/api/ingredient-categories"] }); setEditingIngId(null); toast({ title: "המצרך עודכן" }); },
  });

  const deleteIngredient = useMutation({
    mutationFn: (id: number) => apiRequest("DELETE", `/api/admin/ingredients/${id}`),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["/api/ingredients"] }); queryClient.invalidateQueries({ queryKey: ["/api/ingredient-categories"] }); toast({ title: "המצרך נמחק" }); },
  });

  if (catsLoading || ingsLoading) {
    return <div className="space-y-4">{[1, 2, 3].map((i) => <div key={i} className="h-16 bg-muted/50 rounded-md animate-pulse" />)}</div>;
  }

  const groupedBySubcategory = (ingredients || []).reduce((acc, ing) => {
    const key = ing.subcategory || "";
    if (!acc[key]) acc[key] = [];
    acc[key].push(ing);
    return acc;
  }, {} as Record<string, IngredientMasterWithCategory[]>);

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>קטגוריות מצרכים</CardTitle>
            <Button size="sm" onClick={() => setShowCategoryForm(!showCategoryForm)} data-testid="button-add-category">
              <Plus className="w-4 h-4 ml-1" /> הוסף קטגוריה
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          {showCategoryForm && (
            <form onSubmit={(e) => { e.preventDefault(); if (newCategoryName.trim()) createCategory.mutate(newCategoryName.trim()); }} className="flex gap-2">
              <Input value={newCategoryName} onChange={(e) => setNewCategoryName(e.target.value)} placeholder="שם הקטגוריה" data-testid="input-new-category" />
              <Button type="submit" size="sm" disabled={createCategory.isPending} data-testid="button-submit-category">
                {createCategory.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
              </Button>
              <Button type="button" variant="ghost" size="sm" onClick={() => setShowCategoryForm(false)}>
                <X className="w-4 h-4" />
              </Button>
            </form>
          )}
          <div className="flex flex-wrap gap-2">
            {categories?.map((cat) => (
              <div key={cat.id} className="flex items-center gap-1">
                {editingCategoryId === cat.id ? (
                  <form onSubmit={(e) => { e.preventDefault(); if (editingCategoryName.trim()) updateCategory.mutate({ id: cat.id, nameHebrew: editingCategoryName.trim() }); }} className="flex gap-1">
                    <Input value={editingCategoryName} onChange={(e) => setEditingCategoryName(e.target.value)} className="h-8 w-32 text-sm" data-testid={`input-edit-category-${cat.id}`} />
                    <Button type="submit" size="icon" variant="ghost" className="h-8 w-8"><Check className="w-3 h-3" /></Button>
                    <Button type="button" size="icon" variant="ghost" className="h-8 w-8" onClick={() => setEditingCategoryId(null)}><X className="w-3 h-3" /></Button>
                  </form>
                ) : (
                  <Badge variant="secondary" className="text-sm py-1 px-3 gap-1.5" data-testid={`badge-category-${cat.id}`}>
                    {cat.nameHebrew}
                    <button onClick={() => { setEditingCategoryId(cat.id); setEditingCategoryName(cat.nameHebrew); }} className="hover:text-primary" data-testid={`button-edit-category-${cat.id}`}>
                      <Edit2 className="w-3 h-3" />
                    </button>
                    <button onClick={() => { if (confirm("למחוק קטגוריה?")) deleteCategory.mutate(cat.id); }} className="hover:text-destructive" data-testid={`button-delete-category-${cat.id}`}>
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </Badge>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>מצרכים ({ingredients?.length || 0})</CardTitle>
            <Button size="sm" onClick={() => setShowIngredientForm(!showIngredientForm)} data-testid="button-add-master-ingredient">
              <Plus className="w-4 h-4 ml-1" /> הוסף מצרך
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="חיפוש מצרכים..." className="pr-10" data-testid="input-search-ingredients" />
            </div>
            <Select value={filterCategoryId} onValueChange={setFilterCategoryId}>
              <SelectTrigger className="w-36" data-testid="select-filter-category">
                <SelectValue placeholder="כל הקטגוריות" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">כל הקטגוריות</SelectItem>
                {categories?.map((cat) => <SelectItem key={cat.id} value={String(cat.id)}>{cat.nameHebrew}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>

          {showIngredientForm && (
            <form onSubmit={(e) => { e.preventDefault(); if (newIngName.trim()) createIngredient.mutate({ nameHebrew: newIngName.trim(), categoryId: newIngCategoryId ? Number(newIngCategoryId) : null, subcategory: newIngSubcategory.trim() || null }); }} className="bg-secondary/30 rounded-lg p-3 space-y-2">
              <div className="flex gap-2 items-end">
                <div className="flex-1">
                  <label className="text-xs font-medium mb-1 block">שם המצרך</label>
                  <Input value={newIngName} onChange={(e) => setNewIngName(e.target.value)} placeholder="שם המצרך" data-testid="input-new-ingredient-name" />
                </div>
                <div className="w-36">
                  <label className="text-xs font-medium mb-1 block">קטגוריה</label>
                  <Select value={newIngCategoryId} onValueChange={setNewIngCategoryId}>
                    <SelectTrigger data-testid="select-new-ingredient-category"><SelectValue placeholder="בחר" /></SelectTrigger>
                    <SelectContent>
                      {categories?.map((cat) => <SelectItem key={cat.id} value={String(cat.id)}>{cat.nameHebrew}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="flex gap-2 items-end">
                <div className="flex-1">
                  <label className="text-xs font-medium mb-1 block">תת-קטגוריה (אופציונלי)</label>
                  <Input value={newIngSubcategory} onChange={(e) => setNewIngSubcategory(e.target.value)} placeholder="למשל: נתחי בקר" data-testid="input-new-ingredient-subcategory" />
                </div>
                <Button type="submit" size="sm" disabled={createIngredient.isPending} data-testid="button-submit-ingredient">
                  {createIngredient.isPending ? <Loader2 className="w-4 h-4 animate-spin ml-1" /> : <Check className="w-4 h-4 ml-1" />}
                  הוסף
                </Button>
                <Button type="button" variant="ghost" size="sm" onClick={() => setShowIngredientForm(false)}>
                  ביטול
                </Button>
              </div>
            </form>
          )}

          <div className="divide-y max-h-[500px] overflow-y-auto">
            {Object.entries(groupedBySubcategory).map(([subcategory, ings]) => (
              <div key={subcategory}>
                {subcategory && (
                  <div className="py-1.5 px-2 bg-muted/30 text-xs font-semibold text-muted-foreground sticky top-0">
                    {subcategory}
                  </div>
                )}
                {ings.map((ing) => (
                  <div key={ing.id} className="flex items-center justify-between py-2 px-1" data-testid={`row-ingredient-${ing.id}`}>
                    {editingIngId === ing.id ? (
                      <form onSubmit={(e) => { e.preventDefault(); if (editingIngName.trim()) updateIngredient.mutate({ id: ing.id, nameHebrew: editingIngName.trim(), categoryId: editingIngCategoryId ? Number(editingIngCategoryId) : null, subcategory: editingIngSubcategory.trim() || null }); }} className="flex gap-2 items-center flex-1 flex-wrap">
                        <Input value={editingIngName} onChange={(e) => setEditingIngName(e.target.value)} className="h-8 text-sm flex-1 min-w-[120px]" data-testid={`input-edit-ingredient-${ing.id}`} />
                        <Select value={editingIngCategoryId} onValueChange={setEditingIngCategoryId}>
                          <SelectTrigger className="h-8 w-28 text-sm"><SelectValue placeholder="קטגוריה" /></SelectTrigger>
                          <SelectContent>
                            {categories?.map((cat) => <SelectItem key={cat.id} value={String(cat.id)}>{cat.nameHebrew}</SelectItem>)}
                          </SelectContent>
                        </Select>
                        <Input value={editingIngSubcategory} onChange={(e) => setEditingIngSubcategory(e.target.value)} placeholder="תת-קטגוריה" className="h-8 text-sm w-28" />
                        <Button type="submit" size="icon" variant="ghost" className="h-8 w-8"><Check className="w-3 h-3" /></Button>
                        <Button type="button" size="icon" variant="ghost" className="h-8 w-8" onClick={() => setEditingIngId(null)}><X className="w-3 h-3" /></Button>
                      </form>
                    ) : (
                      <>
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-sm font-medium">{ing.nameHebrew}</span>
                          {ing.categoryName && <Badge variant="outline" className="text-xs">{ing.categoryName}</Badge>}
                          {ing.subcategory && <Badge variant="secondary" className="text-xs">{ing.subcategory}</Badge>}
                        </div>
                        <div className="flex gap-1 shrink-0">
                          <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => { setEditingIngId(ing.id); setEditingIngName(ing.nameHebrew); setEditingIngCategoryId(ing.categoryId ? String(ing.categoryId) : ""); setEditingIngSubcategory(ing.subcategory || ""); }} data-testid={`button-edit-ingredient-${ing.id}`}>
                            <Edit2 className="w-3 h-3" />
                          </Button>
                          <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => { if (confirm("למחוק מצרך?")) deleteIngredient.mutate(ing.id); }} data-testid={`button-delete-ingredient-${ing.id}`}>
                            <Trash2 className="w-3 h-3 text-destructive" />
                          </Button>
                        </div>
                      </>
                    )}
                  </div>
                ))}
              </div>
            ))}
            {ingredients?.length === 0 && (
              <p className="text-center py-8 text-muted-foreground text-sm">
                {search ? "לא נמצאו מצרכים" : "אין מצרכים עדיין"}
              </p>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function AdminsManagement({ currentAdminId }: { currentAdminId: number }) {
  const { data: adminsList, isLoading } = useAdmins();
  const createAdmin = useCreateAdmin();
  const deleteAdmin = useDeleteAdmin();
  const toggleActive = useToggleAdminActive();
  const [showForm, setShowForm] = useState(false);
  const [newUsername, setNewUsername] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [newRole, setNewRole] = useState("admin");

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUsername.trim() || !newPassword.trim()) return;
    await createAdmin.mutateAsync({
      username: newUsername.trim(),
      password: newPassword,
      role: newRole,
      active: true,
      forcePasswordChange: true,
    });
    setNewUsername("");
    setNewPassword("");
    setShowForm(false);
  };

  if (isLoading) {
    return <div className="space-y-4">{[1, 2].map((i) => <div key={i} className="h-16 bg-muted/50 rounded-md animate-pulse" />)}</div>;
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-2">
        <p className="text-sm text-muted-foreground">{adminsList?.length || 0} מנהלים</p>
        <Button size="sm" onClick={() => setShowForm(!showForm)} data-testid="button-add-admin">
          <Plus className="w-4 h-4 ml-1" />
          הוסף מנהל
        </Button>
      </div>

      {showForm && (
        <Card>
          <CardContent className="p-4">
            <form onSubmit={handleCreate} className="space-y-3">
              <Input placeholder="שם משתמש" value={newUsername} onChange={(e) => setNewUsername(e.target.value)} data-testid="input-new-admin-username" />
              <Input placeholder="סיסמה" type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} data-testid="input-new-admin-password" />
              <Select value={newRole} onValueChange={setNewRole}>
                <SelectTrigger data-testid="select-admin-role"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="admin">מנהל</SelectItem>
                  <SelectItem value="super_admin">סופר מנהל</SelectItem>
                </SelectContent>
              </Select>
              <div className="flex gap-2">
                <Button type="submit" size="sm" disabled={createAdmin.isPending} data-testid="button-submit-admin">
                  {createAdmin.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : "צור מנהל"}
                </Button>
                <Button type="button" variant="ghost" size="sm" onClick={() => setShowForm(false)}>ביטול</Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {adminsList?.map((admin) => (
        <Card key={admin.id} className="overflow-visible" data-testid={`card-admin-${admin.id}`}>
          <CardContent className="p-4">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-3">
                <div className={`p-2 rounded-full ${admin.role === "super_admin" ? "bg-primary/10 text-primary" : "bg-secondary text-secondary-foreground"}`}>
                  {admin.role === "super_admin" ? <ShieldCheck className="w-4 h-4" /> : <Shield className="w-4 h-4" />}
                </div>
                <div>
                  <p className="font-medium">{admin.username}</p>
                  <div className="flex items-center gap-2">
                    <Badge variant={admin.role === "super_admin" ? "default" : "secondary"}>
                      {admin.role === "super_admin" ? "סופר מנהל" : "מנהל"}
                    </Badge>
                    <Badge variant={admin.active ? "outline" : "destructive"}>
                      {admin.active ? "פעיל" : "לא פעיל"}
                    </Badge>
                  </div>
                </div>
              </div>
              {admin.id !== currentAdminId && admin.role !== "super_admin" && (
                <div className="flex gap-1">
                  <Button size="icon" variant="ghost" onClick={() => toggleActive.mutate(admin.id)} data-testid={`button-toggle-admin-${admin.id}`}>
                    <Power className="w-4 h-4" />
                  </Button>
                  <Button size="icon" variant="ghost" onClick={() => { if (confirm("למחוק מנהל?")) deleteAdmin.mutate(admin.id); }} data-testid={`button-delete-admin-${admin.id}`}>
                    <Trash2 className="w-4 h-4 text-destructive" />
                  </Button>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
