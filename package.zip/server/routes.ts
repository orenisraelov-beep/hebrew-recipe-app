import express, { type Request, type Response, type NextFunction } from "express";
import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { insertRecipeSchema, insertAdminSchema } from "@shared/schema";
import bcrypt from "bcryptjs";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { supabase, BUCKET_NAME, FOLDER } from "./supabase";
import { randomUUID } from "crypto";
import multer from "multer";

const NON_KOSHER_NAMES = ["shrimp", "prawn", "lobster", "crab", "calamari", "octopus", "שרימפס", "לובסטר", "סרטן", "קלמרי", "תמנון"];

function isNonKosher(name: string): boolean {
  const lower = name.toLowerCase().trim();
  return NON_KOSHER_NAMES.some(nk => lower.includes(nk));
}

declare module "express-session" {
  interface SessionData {
    adminId?: number;
  }
}

function requireAdmin(req: Request, res: Response, next: NextFunction) {
  if (!req.session.adminId) {
    return res.status(401).json({ message: "יש להתחבר למערכת" });
  }
  next();
}

async function requireSuperAdmin(req: Request, res: Response, next: NextFunction) {
  if (!req.session.adminId) {
    return res.status(401).json({ message: "יש להתחבר למערכת" });
  }
  const admin = await storage.getAdmin(req.session.adminId);
  if (!admin || admin.role !== "super_admin") {
    return res.status(403).json({ message: "אין לך הרשאות מספיקות" });
  }
  next();
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  const pgStore = connectPg(session);
  app.set("trust proxy", 1);
  app.use(
    session({
      store: new pgStore({
        conString: process.env.DATABASE_URL,
        createTableIfMissing: false,
        tableName: "admin_sessions",
      }),
      secret: process.env.SESSION_SECRET!,
      resave: false,
      saveUninitialized: false,
      cookie: {
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        sameSite: "lax",
        maxAge: 7 * 24 * 60 * 60 * 1000,
      },
    })
  );

  const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 10 * 1024 * 1024 } });

  app.post("/api/upload/image", requireAdmin, upload.single("image"), async (req, res) => {
    try {
      if (!req.file) return res.status(400).json({ message: "No file uploaded" });
      const ext = req.file.originalname.split(".").pop() || "jpg";
      const fileName = `${FOLDER}/${randomUUID()}.${ext}`;
      const { error } = await supabase.storage
        .from(BUCKET_NAME)
        .upload(fileName, req.file.buffer, {
          contentType: req.file.mimetype,
          upsert: false,
        });
      if (error) throw error;
      const { data: urlData } = supabase.storage.from(BUCKET_NAME).getPublicUrl(fileName);
      res.json({ url: urlData.publicUrl });
    } catch (err: any) {
      console.error("Upload error:", err);
      res.status(500).json({ message: err.message || "Upload failed" });
    }
  });

  app.post("/api/upload/images", requireAdmin, upload.array("images", 10), async (req, res) => {
    try {
      const files = req.files as Express.Multer.File[];
      if (!files || files.length === 0) return res.status(400).json({ message: "No files uploaded" });
      const urls: string[] = [];
      for (const file of files) {
        const ext = file.originalname.split(".").pop() || "jpg";
        const fileName = `${FOLDER}/${randomUUID()}.${ext}`;
        const { error } = await supabase.storage
          .from(BUCKET_NAME)
          .upload(fileName, file.buffer, {
            contentType: file.mimetype,
            upsert: false,
          });
        if (error) throw error;
        const { data: urlData } = supabase.storage.from(BUCKET_NAME).getPublicUrl(fileName);
        urls.push(urlData.publicUrl);
      }
      res.json({ urls });
    } catch (err: any) {
      console.error("Upload error:", err);
      res.status(500).json({ message: err.message || "Upload failed" });
    }
  });

  // === AUTH ===
  app.post(api.admins.login.path, async (req, res) => {
    try {
      const { username, password } = api.admins.login.input.parse(req.body);
      const admin = await storage.getAdminByUsername(username);
      if (!admin) return res.status(401).json({ message: "שם משתמש או סיסמה שגויים" });
      if (!admin.active) return res.status(401).json({ message: "חשבון זה אינו פעיל" });

      const valid = await bcrypt.compare(password, admin.password);
      if (!valid) return res.status(401).json({ message: "שם משתמש או סיסמה שגויים" });

      req.session.adminId = admin.id;
      const { password: _, ...safe } = admin;
      res.json(safe);
    } catch (err) {
      res.status(400).json({ message: "נתונים שגויים" });
    }
  });

  app.post(api.admins.logout.path, (req, res) => {
    req.session.destroy(() => {
      res.json({ message: "התנתקת בהצלחה" });
    });
  });

  app.get(api.admins.me.path, async (req, res) => {
    if (!req.session.adminId) return res.status(401).json({ message: "Unauthorized" });
    const admin = await storage.getAdmin(req.session.adminId);
    if (!admin) return res.status(401).json({ message: "Unauthorized" });
    const { password: _, ...safe } = admin;
    res.json(safe);
  });

  app.post(api.admins.changePassword.path, requireAdmin, async (req, res) => {
    try {
      const { oldPassword, newPassword } = api.admins.changePassword.input.parse(req.body);
      const admin = await storage.getAdmin(req.session.adminId!);
      if (!admin) return res.status(401).json({ message: "Unauthorized" });

      const valid = await bcrypt.compare(oldPassword, admin.password);
      if (!valid) return res.status(400).json({ message: "הסיסמה הנוכחית שגויה" });

      await storage.updateAdmin(admin.id, { password: newPassword, forcePasswordChange: false });
      res.json({ message: "הסיסמה שונתה בהצלחה" });
    } catch (err) {
      res.status(400).json({ message: "נתונים שגויים" });
    }
  });

  // === ADMIN MANAGEMENT ===
  app.get(api.admins.list.path, requireSuperAdmin, async (req, res) => {
    const adminsList = await storage.getAdmins();
    res.json(adminsList);
  });

  app.post(api.admins.create.path, requireSuperAdmin, async (req, res) => {
    try {
      const input = insertAdminSchema.parse(req.body);
      const existing = await storage.getAdminByUsername(input.username);
      if (existing) return res.status(400).json({ message: "שם משתמש כבר קיים" });
      const admin = await storage.createAdmin(input);
      res.status(201).json(admin);
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: err.errors[0].message });
      res.status(500).json({ message: "שגיאה פנימית" });
    }
  });

  app.put(api.admins.update.path, requireSuperAdmin, async (req, res) => {
    const id = Number(req.params.id);
    const updates = insertAdminSchema.partial().parse(req.body);
    const admin = await storage.updateAdmin(id, updates);
    if (!admin) return res.status(404).json({ message: "מנהל לא נמצא" });
    res.json(admin);
  });

  app.delete(api.admins.delete.path, requireSuperAdmin, async (req, res) => {
    const id = Number(req.params.id);
    const admin = await storage.getAdmin(id);
    if (!admin) return res.status(404).json({ message: "מנהל לא נמצא" });
    if (admin.role === "super_admin") return res.status(403).json({ message: "לא ניתן למחוק סופר מנהל" });
    await storage.deleteAdmin(id);
    res.status(204).send();
  });

  app.patch(api.admins.toggleActive.path, requireSuperAdmin, async (req, res) => {
    const id = Number(req.params.id);
    const admin = await storage.getAdmin(id);
    if (!admin) return res.status(404).json({ message: "מנהל לא נמצא" });
    if (admin.role === "super_admin") return res.status(403).json({ message: "לא ניתן לשנות סטטוס סופר מנהל" });
    const updated = await storage.toggleAdminActive(id);
    res.json(updated);
  });

  function getUserId(req: Request): string | null {
    return (req.headers["x-user-id"] as string) || null;
  }

  // === RECIPES ===
  app.get(api.recipes.suggest.path, async (req, res) => {
    const today = new Date();
    const dayOfWeek = today.toLocaleString("en-us", { weekday: "long" });
    const month = today.getMonth();
    let season = "Summer";
    if (month >= 10 || month <= 2) season = "Winter";
    const suggestion = await storage.suggestRecipe({ day: dayOfWeek, season, isHoliday: false });
    if (!suggestion) return res.status(404).json({ message: "אין מתכונים זמינים" });
    res.json(suggestion);
  });

  app.get(api.recipes.list.path, async (req, res) => {
    const params = {
      search: req.query.search as string,
      category: req.query.category as string,
      tag: req.query.tag as string,
      difficulty: req.query.difficulty as string,
      origin: req.query.origin as string,
      maxPrepTime: req.query.maxPrepTime ? Number(req.query.maxPrepTime) : undefined,
      maxTotalTime: req.query.maxTotalTime ? Number(req.query.maxTotalTime) : undefined,
      ingredients: req.query.ingredients as string,
      ingredientIds: req.query.ingredientIds as string,
      author: req.query.author as string,
    };
    const recipesList = await storage.getRecipes(params);
    res.json(recipesList);
  });

  app.get(api.recipes.get.path, async (req, res) => {
    const recipe = await storage.getRecipe(Number(req.params.id));
    if (!recipe) return res.status(404).json({ message: "מתכון לא נמצא" });
    const userId = getUserId(req);
    if (userId) {
      recipe.userRating = (await storage.getUserRating(userId, recipe.id)) ?? undefined;
    }
    res.json(recipe);
  });

  app.post(api.recipes.create.path, requireAdmin, async (req, res) => {
    try {
      const { images, steps, structuredIngredients, ...recipeData } = req.body;
      const input = insertRecipeSchema.parse(recipeData);
      input.createdByAdminId = req.session.adminId!;
      const recipe = await storage.createRecipe(input);

      if (images && Array.isArray(images)) {
        await storage.setRecipeImages(recipe.id, images.map((img: any, i: number) => ({
          recipeId: recipe.id, imagePath: img.imagePath, displayOrder: i,
        })));
      }

      if (steps && Array.isArray(steps)) {
        await storage.setRecipeSteps(recipe.id, steps.map((step: any, i: number) => ({
          recipeId: recipe.id, stepNumber: i + 1, stepText: step.stepText, stepImagePath: step.stepImagePath || null,
        })));
      }

      if (structuredIngredients && Array.isArray(structuredIngredients)) {
        await storage.setRecipeIngredients(recipe.id, structuredIngredients.map((ing: any) => ({
          recipeId: recipe.id, ingredientName: ing.ingredientName, quantity: ing.quantity || null, unit: ing.unit || null,
        })));
      }

      const full = await storage.getRecipe(recipe.id);
      res.status(201).json(full);
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: err.errors[0].message });
      console.error("Create recipe error:", err);
      res.status(500).json({ message: "שגיאה פנימית" });
    }
  });

  app.put(api.recipes.update.path, requireAdmin, async (req, res) => {
    try {
      const id = Number(req.params.id);
      const existing = await storage.getRecipe(id);
      if (!existing) return res.status(404).json({ message: "מתכון לא נמצא" });

      const admin = await storage.getAdmin(req.session.adminId!);
      if (admin?.role !== "super_admin" && existing.createdByAdminId !== req.session.adminId) {
        return res.status(403).json({ message: "אין לך הרשאה לערוך מתכון זה" });
      }

      const { images, steps, structuredIngredients, ...recipeData } = req.body;
      const input = insertRecipeSchema.partial().parse(recipeData);
      await storage.updateRecipe(id, input);

      if (images && Array.isArray(images)) {
        await storage.setRecipeImages(id, images.map((img: any, i: number) => ({
          recipeId: id, imagePath: img.imagePath, displayOrder: i,
        })));
      }

      if (steps && Array.isArray(steps)) {
        await storage.setRecipeSteps(id, steps.map((step: any, i: number) => ({
          recipeId: id, stepNumber: i + 1, stepText: step.stepText, stepImagePath: step.stepImagePath || null,
        })));
      }

      if (structuredIngredients && Array.isArray(structuredIngredients)) {
        await storage.setRecipeIngredients(id, structuredIngredients.map((ing: any) => ({
          recipeId: id, ingredientName: ing.ingredientName, quantity: ing.quantity || null, unit: ing.unit || null,
        })));
      }

      const full = await storage.getRecipe(id);
      res.json(full);
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: err.errors[0].message });
      console.error("Update recipe error:", err);
      res.status(500).json({ message: "שגיאה פנימית" });
    }
  });

  app.delete(api.recipes.delete.path, requireAdmin, async (req, res) => {
    const id = Number(req.params.id);
    const existing = await storage.getRecipe(id);
    if (!existing) return res.status(404).json({ message: "מתכון לא נמצא" });

    const admin = await storage.getAdmin(req.session.adminId!);
    if (admin?.role !== "super_admin" && existing.createdByAdminId !== req.session.adminId) {
      return res.status(403).json({ message: "אין לך הרשאה למחוק מתכון זה" });
    }

    await storage.deleteRecipe(id);
    res.status(204).send();
  });

  // === USER FEATURES (device-based userId via header) ===

  // Favorites count (public, no user ID needed)
  app.get("/api/favorites/counts", async (_req, res) => {
    const counts = await storage.getRecipeFavoriteCounts();
    res.json(counts);
  });

  app.get("/api/favorites/count/:recipeId", async (req, res) => {
    const count = await storage.getRecipeFavoriteCount(Number(req.params.recipeId));
    res.json({ count });
  });

  // Ratings (public averages)
  app.get("/api/ratings", async (_req, res) => {
    const ratings = await storage.getAllRecipeRatings();
    res.json(ratings);
  });

  app.get("/api/ratings/:recipeId", async (req, res) => {
    const data = await storage.getRecipeAverageRating(Number(req.params.recipeId));
    res.json(data);
  });

  // Rating (user-specific)
  app.get("/api/user/rating/:recipeId", async (req, res) => {
    const userId = getUserId(req);
    if (!userId) return res.status(400).json({ message: "Missing user ID" });
    const rating = await storage.getUserRating(userId, Number(req.params.recipeId));
    res.json({ rating });
  });

  app.post("/api/user/rating/:recipeId", async (req, res) => {
    const userId = getUserId(req);
    if (!userId) return res.status(400).json({ message: "Missing user ID" });
    const { rating } = req.body;
    const parsedRating = Number(rating);
    if (!Number.isInteger(parsedRating) || parsedRating < 1 || parsedRating > 10) {
      return res.status(400).json({ message: "Rating must be an integer between 1 and 10" });
    }
    const recipeId = Number(req.params.recipeId);
    const recipe = await storage.getRecipe(recipeId);
    if (!recipe) {
      return res.status(404).json({ message: "Recipe not found" });
    }
    const result = await storage.rateRecipe(userId, recipeId, parsedRating);
    res.json(result);
  });

  // Authors list (public)
  app.get("/api/authors", async (_req, res) => {
    const authors = await storage.getUniqueAuthors();
    res.json(authors);
  });

  // Favorites (user-specific)
  app.get("/api/user/favorites", async (req, res) => {
    const userId = getUserId(req);
    if (!userId) return res.status(400).json({ message: "Missing user ID" });
    const ids = await storage.getUserFavorites(userId);
    res.json(ids);
  });

  app.get("/api/user/favorites/recipes", async (req, res) => {
    const userId = getUserId(req);
    if (!userId) return res.status(400).json({ message: "Missing user ID" });
    const recipes = await storage.getFavoriteRecipes(userId);
    res.json(recipes);
  });

  app.post("/api/user/favorites/:recipeId", async (req, res) => {
    const userId = getUserId(req);
    if (!userId) return res.status(400).json({ message: "Missing user ID" });
    await storage.addFavorite(userId, Number(req.params.recipeId));
    res.json({ success: true });
  });

  app.delete("/api/user/favorites/:recipeId", async (req, res) => {
    const userId = getUserId(req);
    if (!userId) return res.status(400).json({ message: "Missing user ID" });
    await storage.removeFavorite(userId, Number(req.params.recipeId));
    res.json({ success: true });
  });

  // Shopping List
  app.get("/api/user/shopping-list", async (req, res) => {
    const userId = getUserId(req);
    if (!userId) return res.status(400).json({ message: "Missing user ID" });
    const items = await storage.getShoppingList(userId);
    res.json(items);
  });

  app.post("/api/user/shopping-list", async (req, res) => {
    const userId = getUserId(req);
    if (!userId) return res.status(400).json({ message: "Missing user ID" });
    const { items } = req.body;
    if (!Array.isArray(items)) return res.status(400).json({ message: "Items array required" });
    const created = await storage.addShoppingItems(userId, items);
    res.json(created);
  });

  app.patch("/api/user/shopping-list/:id/toggle", async (req, res) => {
    const userId = getUserId(req);
    if (!userId) return res.status(400).json({ message: "Missing user ID" });
    const item = await storage.toggleShoppingItem(Number(req.params.id), userId);
    if (!item) return res.status(404).json({ message: "Item not found" });
    res.json(item);
  });

  app.delete("/api/user/shopping-list/:id", async (req, res) => {
    const userId = getUserId(req);
    if (!userId) return res.status(400).json({ message: "Missing user ID" });
    await storage.removeShoppingItem(Number(req.params.id), userId);
    res.json({ success: true });
  });

  app.post("/api/user/shopping-list/batch", async (req, res) => {
    const userId = getUserId(req);
    if (!userId) return res.status(400).json({ message: "Missing user ID" });
    const { items } = req.body;
    if (!items || !Array.isArray(items)) return res.status(400).json({ message: "items array required" });
    const mappedItems = items.map((item: any) => ({
      ingredientName: item.ingredientName,
      quantity: item.quantity || null,
      unit: item.unit || null,
      recipeTitle: item.recipeTitle || null,
      completed: false,
    }));
    const result = await storage.addShoppingItems(userId, mappedItems);
    res.json(result);
  });

  app.delete("/api/user/shopping-list", async (req, res) => {
    const userId = getUserId(req);
    if (!userId) return res.status(400).json({ message: "Missing user ID" });
    await storage.clearShoppingList(userId);
    res.json({ success: true });
  });

  // Meal Plans
  app.get("/api/user/meal-plans", async (req, res) => {
    const userId = getUserId(req);
    if (!userId) return res.status(400).json({ message: "Missing user ID" });
    const plans = await storage.getMealPlans(userId);
    res.json(plans);
  });

  app.post("/api/user/meal-plans", async (req, res) => {
    const userId = getUserId(req);
    if (!userId) return res.status(400).json({ message: "Missing user ID" });
    const { dayOfWeek, recipeId } = req.body;
    if (!dayOfWeek || !recipeId) return res.status(400).json({ message: "dayOfWeek and recipeId required" });
    const plan = await storage.addMealPlan(userId, dayOfWeek, recipeId);
    res.json(plan);
  });

  app.delete("/api/user/meal-plans/item/:id", async (req, res) => {
    const userId = getUserId(req);
    if (!userId) return res.status(400).json({ message: "Missing user ID" });
    await storage.removeMealPlanItem(Number(req.params.id), userId);
    res.json({ success: true });
  });

  app.delete("/api/user/meal-plans/:day", async (req, res) => {
    const userId = getUserId(req);
    if (!userId) return res.status(400).json({ message: "Missing user ID" });
    await storage.removeMealPlanDay(userId, req.params.day);
    res.json({ success: true });
  });

  // === INGREDIENT CATEGORIES (public) ===
  app.get("/api/ingredient-categories", async (req, res) => {
    const categories = await storage.getIngredientCategoriesWithIngredients();
    res.json(categories);
  });

  // === INGREDIENTS MASTER (public, with search) ===
  app.get("/api/ingredients", async (req, res) => {
    const search = req.query.search as string | undefined;
    const categoryId = req.query.categoryId ? Number(req.query.categoryId) : undefined;
    const ingredients = await storage.getIngredientsMaster(search, categoryId);
    res.json(ingredients);
  });

  // === ADMIN INGREDIENT CATEGORIES ===
  app.post("/api/admin/ingredient-categories", requireAdmin, async (req, res) => {
    try {
      const { nameHebrew } = req.body;
      if (!nameHebrew) return res.status(400).json({ message: "שם קטגוריה נדרש" });
      const cat = await storage.createIngredientCategory({ nameHebrew });
      res.status(201).json(cat);
    } catch (err: any) {
      if (err.message?.includes("unique")) return res.status(400).json({ message: "קטגוריה כבר קיימת" });
      res.status(500).json({ message: "שגיאה פנימית" });
    }
  });

  app.put("/api/admin/ingredient-categories/:id", requireAdmin, async (req, res) => {
    const id = Number(req.params.id);
    const { nameHebrew } = req.body;
    if (!nameHebrew) return res.status(400).json({ message: "שם קטגוריה נדרש" });
    const updated = await storage.updateIngredientCategory(id, { nameHebrew });
    if (!updated) return res.status(404).json({ message: "קטגוריה לא נמצאה" });
    res.json(updated);
  });

  app.delete("/api/admin/ingredient-categories/:id", requireAdmin, async (req, res) => {
    const id = Number(req.params.id);
    await storage.deleteIngredientCategory(id);
    res.status(204).send();
  });

  // === ADMIN INGREDIENTS MASTER ===
  app.post("/api/admin/ingredients", requireAdmin, async (req, res) => {
    try {
      const { nameHebrew, categoryId, subcategory, displayOrder } = req.body;
      if (!nameHebrew) return res.status(400).json({ message: "שם מצרך נדרש" });
      if (isNonKosher(nameHebrew)) return res.status(400).json({ message: "מצרך לא כשר - לא ניתן להוסיף" });
      const ing = await storage.createIngredientMaster({
        nameHebrew,
        categoryId: categoryId || null,
        subcategory: subcategory || null,
        displayOrder: displayOrder || 0,
      });
      res.status(201).json(ing);
    } catch (err: any) {
      if (err.message?.includes("unique")) return res.status(400).json({ message: "מצרך כבר קיים" });
      res.status(500).json({ message: "שגיאה פנימית" });
    }
  });

  app.put("/api/admin/ingredients/:id", requireAdmin, async (req, res) => {
    const id = Number(req.params.id);
    const { nameHebrew, categoryId, subcategory, displayOrder } = req.body;
    if (!nameHebrew) return res.status(400).json({ message: "שם מצרך נדרש" });
    if (isNonKosher(nameHebrew)) return res.status(400).json({ message: "מצרך לא כשר - לא ניתן להוסיף" });
    const updated = await storage.updateIngredientMaster(id, {
      nameHebrew,
      categoryId: categoryId || null,
      subcategory: subcategory || null,
      displayOrder: displayOrder ?? 0,
    });
    if (!updated) return res.status(404).json({ message: "מצרך לא נמצא" });
    res.json(updated);
  });

  app.delete("/api/admin/ingredients/:id", requireAdmin, async (req, res) => {
    const id = Number(req.params.id);
    await storage.deleteIngredientMaster(id);
    res.status(204).send();
  });

  app.post("/api/ingredients", async (req, res) => {
    try {
      const { nameHebrew, categoryId } = req.body;
      if (!nameHebrew) return res.status(400).json({ message: "שם מצרך נדרש" });
      if (isNonKosher(nameHebrew)) return res.status(400).json({ message: "מצרך לא כשר - לא ניתן להוסיף" });
      const ing = await storage.createIngredientMaster({
        nameHebrew,
        categoryId: categoryId || null,
        subcategory: null,
        displayOrder: 0,
      });
      res.status(201).json(ing);
    } catch (err: any) {
      if (err.message?.includes("unique")) return res.status(400).json({ message: "מצרך כבר קיים" });
      res.status(500).json({ message: "שגיאה פנימית" });
    }
  });

  // === USER INGREDIENTS ===
  app.get("/api/user/ingredients", async (req, res) => {
    const userId = getUserId(req);
    if (!userId) return res.status(400).json({ message: "Missing user ID" });
    const ids = await storage.getUserIngredientIds(userId);
    res.json(ids);
  });

  app.post("/api/user/ingredients", async (req, res) => {
    const userId = getUserId(req);
    if (!userId) return res.status(400).json({ message: "Missing user ID" });
    const { ingredientIds } = req.body;
    if (!Array.isArray(ingredientIds)) return res.status(400).json({ message: "ingredientIds array required" });
    await storage.setUserIngredients(userId, ingredientIds);
    res.json({ success: true });
  });

  app.post("/api/user/ingredients/:ingredientId/toggle", async (req, res) => {
    const userId = getUserId(req);
    if (!userId) return res.status(400).json({ message: "Missing user ID" });
    const ingredientId = Number(req.params.ingredientId);
    const selected = await storage.toggleUserIngredient(userId, ingredientId);
    res.json({ selected });
  });

  // Seed defaults
  await storage.seedDefaultAdmin();
  await storage.seedIngredientCategories();
  await storage.migrateExistingIngredients();
  await storage.seedFullIngredientList();
  await seedRecipes();

  return httpServer;
}

async function seedRecipes() {
  const existing = await storage.getRecipes();
  if (existing.length === 0) {
    console.log("Seeding recipes...");
    const sampleRecipes = [
      {
        title: "חמין לשבת",
        description: "תבשיל קדרה מסורתי בבישול איטי, מושלם לשבת חורפית.",
        ingredients: ["בשר בקר", "תפוחי אדמה", "שעועית", "חיטה", "ביצים", "בצל", "שום", "תבלינים"],
        preparation: ["משרים את השעועית והחיטה ללילה.", "מטגנים בצל ושום בסיר גדול.", "מוסיפים את הבשר וסוגרים אותו.", "מסדרים את כל המרכיבים בסיר בשכבות.", "מוסיפים מים ותבלינים.", "מביאים לרתיחה ומעבירים לפלטה או תנור לבישול איטי לכל הלילה."],
        category: "Meat",
        tags: ["שבת", "חורף", "בשרי"],
        imageUrl: "https://images.unsplash.com/photo-1547592166-23acbe3a624b?w=800&q=80",
        suitableDays: ["שישי", "שבת"],
        suitableHolidays: [],
        createdByAdminId: 1,
        preparationTime: 30,
        totalTime: 720,
        servings: 8,
        difficulty: "בינוני",
        origin: "מרוקאי",
      },
      {
        title: "עוגת גבינה פירורים",
        description: "עוגה קלאסית וקלילה, מתאימה לשבועות ולכל אירוח חלבי.",
        ingredients: ["גבינה לבנה", "שמנת מתוקה", "אינסטנט פודינג", "סוכר", "ביסקוויטים", "חמאה"],
        preparation: ["טוחנים את הביסקוויטים ומערבבים עם חמאה מומסת לתחתית.", "מקציפים שמנת מתוקה עם פודינג וסוכר.", "מקפלים פנימה את הגבינה.", "יוצקים על התחתית ומפזרים פירורים מעל.", "מקררים למשך 4 שעות לפחות."],
        category: "Dairy",
        tags: ["חג", "קיץ", "חלבי", "קינוח"],
        imageUrl: "https://images.unsplash.com/photo-1533134242443-d4fd215305ad?w=800&q=80",
        suitableDays: ["ראשון", "שני", "שלישי", "רביעי", "חמישי"],
        suitableHolidays: ["שבועות"],
        createdByAdminId: 1,
        preparationTime: 20,
        totalTime: 280,
        servings: 10,
        difficulty: "קל",
        origin: "אשכנזי",
      },
      {
        title: "שקשוקה חריפה",
        description: "ארוחת בוקר או ערב מושלמת, מלאה בטעמים.",
        ingredients: ["ביצים", "עגבניות", "פלפל חריף", "שום", "שמן זית", "פפריקה", "כמון"],
        preparation: ["קוצצים עגבניות ופלפלים.", "מטגנים שום ופלפל חריף בשמן זית.", "מוסיפים עגבניות ומבשלים עד לרוטב סמיך.", "מתבלים ושוברים פנימה את הביצים.", "מבשלים עד למידת העשייה הרצויה."],
        category: "Parve",
        tags: ["יום חול", "קיץ", "מהיר"],
        imageUrl: "https://images.unsplash.com/photo-1590412200988-a436970781fa?w=800&q=80",
        suitableDays: ["ראשון", "שני", "שלישי", "רביעי", "חמישי"],
        suitableHolidays: [],
        createdByAdminId: 1,
        preparationTime: 10,
        totalTime: 25,
        servings: 4,
        difficulty: "קל",
        origin: "ישראלי",
      },
    ];
    for (const recipe of sampleRecipes) {
      await storage.createRecipe(recipe);
    }
    console.log("Recipes seeded!");
  }
}
