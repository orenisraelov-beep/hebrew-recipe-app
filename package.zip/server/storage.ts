import { db } from "./db";
import {
  recipes, admins, recipeImages, recipeSteps, recipeIngredients,
  ingredientCategories, ingredientsMaster, userIngredients,
  userFavorites, shoppingListItems, mealPlans, recipeRatings,
  type Recipe, type InsertRecipe, type UpdateRecipeRequest, type RecipeQueryParams,
  type Admin, type InsertAdmin, type AdminSafe, type RecipeWithAdmin, type RecipeFull,
  type RecipeImage, type InsertRecipeImage, type RecipeStep, type InsertRecipeStep,
  type RecipeIngredient, type InsertRecipeIngredient,
  type UserFavorite, type ShoppingListItem, type InsertShoppingListItem, type MealPlan,
  type IngredientCategory, type InsertIngredientCategory,
  type IngredientMaster, type InsertIngredientMaster, type IngredientMasterWithCategory,
  type IngredientCategoryWithIngredients,
  type RecipeRating
} from "@shared/schema";
import { eq, ilike, and, or, desc, asc, lte, inArray, sql } from "drizzle-orm";
import bcrypt from "bcryptjs";

export interface IStorage {
  getRecipes(params?: RecipeQueryParams): Promise<RecipeWithAdmin[]>;
  getRecipe(id: number): Promise<RecipeFull | undefined>;
  createRecipe(recipe: InsertRecipe): Promise<Recipe>;
  updateRecipe(id: number, recipe: UpdateRecipeRequest): Promise<Recipe | undefined>;
  deleteRecipe(id: number): Promise<boolean>;
  suggestRecipe(criteria: { day?: string; season?: string; isHoliday?: boolean }): Promise<{ recipe: RecipeWithAdmin; reason: string } | undefined>;

  getRecipeImages(recipeId: number): Promise<RecipeImage[]>;
  setRecipeImages(recipeId: number, images: InsertRecipeImage[]): Promise<RecipeImage[]>;
  getRecipeSteps(recipeId: number): Promise<RecipeStep[]>;
  setRecipeSteps(recipeId: number, steps: InsertRecipeStep[]): Promise<RecipeStep[]>;
  getRecipeIngredients(recipeId: number): Promise<RecipeIngredient[]>;
  setRecipeIngredients(recipeId: number, ingredients: InsertRecipeIngredient[]): Promise<RecipeIngredient[]>;

  // User Favorites
  getUserFavorites(userId: string): Promise<number[]>;
  addFavorite(userId: string, recipeId: number): Promise<void>;
  removeFavorite(userId: string, recipeId: number): Promise<void>;
  getFavoriteRecipes(userId: string): Promise<RecipeWithAdmin[]>;

  // Shopping List
  getShoppingList(userId: string): Promise<ShoppingListItem[]>;
  addShoppingItems(userId: string, items: Omit<InsertShoppingListItem, "userId">[]): Promise<ShoppingListItem[]>;
  toggleShoppingItem(id: number, userId: string): Promise<ShoppingListItem | undefined>;
  removeShoppingItem(id: number, userId: string): Promise<boolean>;
  clearShoppingList(userId: string): Promise<void>;

  // Meal Plans (multiple recipes per day)
  getMealPlans(userId: string): Promise<MealPlan[]>;
  addMealPlan(userId: string, dayOfWeek: string, recipeId: number): Promise<MealPlan>;
  removeMealPlanItem(id: number, userId: string): Promise<boolean>;
  removeMealPlanDay(userId: string, dayOfWeek: string): Promise<boolean>;

  // Favorites Count
  getRecipeFavoriteCounts(): Promise<Record<number, number>>;
  getRecipeFavoriteCount(recipeId: number): Promise<number>;

  // Ratings
  rateRecipe(userId: string, recipeId: number, rating: number): Promise<RecipeRating>;
  getUserRating(userId: string, recipeId: number): Promise<number | null>;
  getRecipeAverageRating(recipeId: number): Promise<{ average: number; count: number }>;
  getAllRecipeRatings(): Promise<Record<number, { average: number; count: number }>>;

  // Authors
  getUniqueAuthors(): Promise<string[]>;

  // Ingredient Categories
  getIngredientCategories(): Promise<IngredientCategory[]>;
  getIngredientCategoriesWithIngredients(): Promise<IngredientCategoryWithIngredients[]>;
  createIngredientCategory(cat: InsertIngredientCategory): Promise<IngredientCategory>;
  updateIngredientCategory(id: number, cat: InsertIngredientCategory): Promise<IngredientCategory | undefined>;
  deleteIngredientCategory(id: number): Promise<boolean>;

  // Ingredients Master
  getIngredientsMaster(search?: string, categoryId?: number): Promise<IngredientMasterWithCategory[]>;
  getIngredientMaster(id: number): Promise<IngredientMaster | undefined>;
  createIngredientMaster(ing: InsertIngredientMaster): Promise<IngredientMaster>;
  updateIngredientMaster(id: number, ing: InsertIngredientMaster): Promise<IngredientMaster | undefined>;
  deleteIngredientMaster(id: number): Promise<boolean>;

  // User Ingredients (selected at home)
  getUserIngredientIds(userId: string): Promise<number[]>;
  setUserIngredients(userId: string, ingredientIds: number[]): Promise<void>;
  toggleUserIngredient(userId: string, ingredientId: number): Promise<boolean>;

  // Seed
  seedIngredientCategories(): Promise<void>;
  migrateExistingIngredients(): Promise<void>;
  seedFullIngredientList(): Promise<void>;

  // Admins
  getAdmins(): Promise<AdminSafe[]>;
  getAdmin(id: number): Promise<Admin | undefined>;
  getAdminByUsername(username: string): Promise<Admin | undefined>;
  createAdmin(admin: InsertAdmin): Promise<AdminSafe>;
  updateAdmin(id: number, updates: Partial<InsertAdmin>): Promise<AdminSafe | undefined>;
  deleteAdmin(id: number): Promise<boolean>;
  toggleAdminActive(id: number): Promise<AdminSafe | undefined>;
  seedDefaultAdmin(): Promise<void>;
}

function stripPassword(admin: Admin): AdminSafe {
  const { password, ...safe } = admin;
  return safe;
}

export class DatabaseStorage implements IStorage {
  private async enrichRecipeWithAdmin(recipe: Recipe): Promise<RecipeWithAdmin> {
    let createdByAdmin: string | undefined;
    if (recipe.createdByAdminId) {
      const admin = await this.getAdmin(recipe.createdByAdminId);
      createdByAdmin = admin?.username;
    }
    const images = await this.getRecipeImages(recipe.id);
    const { average, count } = await this.getRecipeAverageRating(recipe.id);
    return { ...recipe, createdByAdmin, images, averageRating: average, ratingCount: count };
  }

  private async enrichRecipeFull(recipe: Recipe): Promise<RecipeFull> {
    const base = await this.enrichRecipeWithAdmin(recipe);
    const [steps, structuredIngredients] = await Promise.all([
      this.getRecipeSteps(recipe.id),
      this.getRecipeIngredients(recipe.id),
    ]);
    return { ...base, images: base.images || [], steps, structuredIngredients };
  }

  async getRecipes(params?: RecipeQueryParams): Promise<RecipeWithAdmin[]> {
    let conditions = [];

    if (params?.search) {
      const searchTerms = params.search.split(",").map(s => s.trim()).filter(Boolean);
      if (searchTerms.length > 0) {
        const searchConditions = searchTerms.map(term =>
          or(
            ilike(recipes.title, `%${term}%`),
            ilike(recipes.description, `%${term}%`)
          )
        );
        conditions.push(or(...searchConditions));
      }
    }

    if (params?.category) {
      conditions.push(eq(recipes.category, params.category));
    }

    if (params?.difficulty) {
      conditions.push(eq(recipes.difficulty, params.difficulty));
    }

    if (params?.origin) {
      conditions.push(eq(recipes.origin, params.origin));
    }

    if (params?.maxPrepTime) {
      conditions.push(lte(recipes.preparationTime, params.maxPrepTime));
    }

    if (params?.maxTotalTime) {
      conditions.push(lte(recipes.totalTime, params.maxTotalTime));
    }

    if (params?.author) {
      conditions.push(eq(recipes.authorName, params.author));
    }

    const result = await db
      .select()
      .from(recipes)
      .where(conditions.length > 0 ? and(...conditions) : undefined)
      .orderBy(desc(recipes.createdAt));

    let filtered = result;
    if (params?.tag) {
      filtered = result.filter(r => r.tags?.some(t => t === params.tag));
    }

    if (params?.search) {
      const searchTerms = params.search.split(",").map(s => s.trim().toLowerCase()).filter(Boolean);
      if (searchTerms.length > 0) {
        let ingredientBaseConditions: any[] = [];
        if (params?.category) ingredientBaseConditions.push(eq(recipes.category, params.category));
        if (params?.difficulty) ingredientBaseConditions.push(eq(recipes.difficulty, params.difficulty));
        if (params?.origin) ingredientBaseConditions.push(eq(recipes.origin, params.origin));
        if (params?.maxPrepTime) ingredientBaseConditions.push(lte(recipes.preparationTime, params.maxPrepTime));
        if (params?.maxTotalTime) ingredientBaseConditions.push(lte(recipes.totalTime, params.maxTotalTime));
        if (params?.author) ingredientBaseConditions.push(eq(recipes.authorName, params.author));

        const candidateRecipes = await db.select().from(recipes)
          .where(ingredientBaseConditions.length > 0 ? and(...ingredientBaseConditions) : undefined)
          .orderBy(desc(recipes.createdAt));

        const ingredientMatches = candidateRecipes.filter(r => {
          const ingredientStr = (r.ingredients as string[]).join(" ").toLowerCase();
          return searchTerms.some(term => ingredientStr.includes(term));
        });
        const ids = new Set(filtered.map(r => r.id));
        for (const r of ingredientMatches) {
          if (!ids.has(r.id)) {
            filtered.push(r);
            ids.add(r.id);
          }
        }
      }
    }

    if (params?.ingredientIds) {
      const selectedIds = params.ingredientIds.split(",").map(Number).filter(n => !isNaN(n));
      if (selectedIds.length > 0) {
        const allRecipeIngs = await db.select().from(recipeIngredients);
        const recipeIngMap = new Map<number, number[]>();
        for (const ri of allRecipeIngs) {
          if (ri.ingredientId) {
            if (!recipeIngMap.has(ri.recipeId)) recipeIngMap.set(ri.recipeId, []);
            recipeIngMap.get(ri.recipeId)!.push(ri.ingredientId);
          }
        }

        const masterIngs = await db.select().from(ingredientsMaster);
        const idToName = new Map(masterIngs.map(m => [m.id, m.nameHebrew.toLowerCase()]));
        const selectedNames = selectedIds.map(id => idToName.get(id)).filter(Boolean) as string[];

        filtered = filtered.filter(r => {
          const linkedIds = recipeIngMap.get(r.id) || [];
          const hasLinkedMatch = linkedIds.some(id => selectedIds.includes(id));
          if (hasLinkedMatch) return true;
          const recipeIngStr = (r.ingredients as string[]).join(" ").toLowerCase();
          return selectedNames.some(name => recipeIngStr.includes(name));
        });
        filtered.sort((a, b) => {
          const aLinked = recipeIngMap.get(a.id) || [];
          const bLinked = recipeIngMap.get(b.id) || [];
          const aCount = aLinked.filter(id => selectedIds.includes(id)).length +
            selectedNames.filter(name => (a.ingredients as string[]).join(" ").toLowerCase().includes(name)).length;
          const bCount = bLinked.filter(id => selectedIds.includes(id)).length +
            selectedNames.filter(name => (b.ingredients as string[]).join(" ").toLowerCase().includes(name)).length;
          return bCount - aCount;
        });
      }
    }
    if (params?.ingredients) {
      const selectedIngredients = params.ingredients.split(",").map(s => s.trim().toLowerCase()).filter(Boolean);
      if (selectedIngredients.length > 0) {
        filtered = filtered.filter(r => {
          const recipeIngStr = (r.ingredients as string[]).join(" ").toLowerCase();
          return selectedIngredients.some(ing => recipeIngStr.includes(ing));
        });
        filtered.sort((a, b) => {
          const aCount = selectedIngredients.filter(ing => (a.ingredients as string[]).join(" ").toLowerCase().includes(ing)).length;
          const bCount = selectedIngredients.filter(ing => (b.ingredients as string[]).join(" ").toLowerCase().includes(ing)).length;
          return bCount - aCount;
        });
      }
    }

    return Promise.all(filtered.map(r => this.enrichRecipeWithAdmin(r)));
  }

  async getRecipe(id: number): Promise<RecipeFull | undefined> {
    const [recipe] = await db.select().from(recipes).where(eq(recipes.id, id));
    if (!recipe) return undefined;
    return this.enrichRecipeFull(recipe);
  }

  async createRecipe(recipe: InsertRecipe): Promise<Recipe> {
    const [newRecipe] = await db.insert(recipes).values(recipe).returning();
    return newRecipe;
  }

  async updateRecipe(id: number, recipe: UpdateRecipeRequest): Promise<Recipe | undefined> {
    const [updatedRecipe] = await db.update(recipes).set({ ...recipe, updatedAt: new Date() }).where(eq(recipes.id, id)).returning();
    return updatedRecipe;
  }

  async deleteRecipe(id: number): Promise<boolean> {
    await db.delete(recipeImages).where(eq(recipeImages.recipeId, id));
    await db.delete(recipeSteps).where(eq(recipeSteps.recipeId, id));
    await db.delete(recipeIngredients).where(eq(recipeIngredients.recipeId, id));
    await db.delete(recipeRatings).where(eq(recipeRatings.recipeId, id));
    const [deleted] = await db.delete(recipes).where(eq(recipes.id, id)).returning();
    return !!deleted;
  }

  async suggestRecipe(criteria: { day?: string; season?: string; isHoliday?: boolean }): Promise<{ recipe: RecipeWithAdmin; reason: string } | undefined> {
    const allRecipes = await db.select().from(recipes).orderBy(desc(recipes.createdAt));
    if (allRecipes.length === 0) return undefined;

    let candidates: Recipe[] = [];
    let reason = "המלצה כללית";

    if (criteria.isHoliday) {
      candidates = allRecipes.filter(r => r.tags?.some(t => ["Holiday", "חג"].includes(t)));
      if (candidates.length > 0) {
        reason = "מתכון מומלץ לחג";
        const recipe = await this.enrichRecipeWithAdmin(this.random(candidates));
        return { recipe, reason };
      }
    }

    if (criteria.day === "Friday" || criteria.day === "Saturday") {
      candidates = allRecipes.filter(r => r.tags?.some(t => ["Shabbat", "שבת"].includes(t)));
      if (candidates.length > 0) {
        reason = "מתכון מומלץ לשבת";
        const recipe = await this.enrichRecipeWithAdmin(this.random(candidates));
        return { recipe, reason };
      }
    }

    if (criteria.season) {
      const heb = criteria.season === "Winter" ? "חורף" : "קיץ";
      candidates = allRecipes.filter(r => r.tags?.some(t => [criteria.season!, heb].includes(t)));
      if (candidates.length > 0) {
        reason = `מתכון מומלץ ל${heb}`;
        const recipe = await this.enrichRecipeWithAdmin(this.random(candidates));
        return { recipe, reason };
      }
    }

    const recipe = await this.enrichRecipeWithAdmin(this.random(allRecipes));
    return { recipe, reason: "משהו טעים בשבילך" };
  }

  private random(items: Recipe[]): Recipe {
    return items[Math.floor(Math.random() * items.length)];
  }

  // === RECIPE IMAGES ===
  async getRecipeImages(recipeId: number): Promise<RecipeImage[]> {
    return db.select().from(recipeImages).where(eq(recipeImages.recipeId, recipeId)).orderBy(asc(recipeImages.displayOrder));
  }

  async setRecipeImages(recipeId: number, images: InsertRecipeImage[]): Promise<RecipeImage[]> {
    await db.delete(recipeImages).where(eq(recipeImages.recipeId, recipeId));
    if (images.length === 0) return [];
    const toInsert = images.map((img, i) => ({ ...img, recipeId, displayOrder: i }));
    return db.insert(recipeImages).values(toInsert).returning();
  }

  // === RECIPE STEPS ===
  async getRecipeSteps(recipeId: number): Promise<RecipeStep[]> {
    return db.select().from(recipeSteps).where(eq(recipeSteps.recipeId, recipeId)).orderBy(asc(recipeSteps.stepNumber));
  }

  async setRecipeSteps(recipeId: number, steps: InsertRecipeStep[]): Promise<RecipeStep[]> {
    await db.delete(recipeSteps).where(eq(recipeSteps.recipeId, recipeId));
    if (steps.length === 0) return [];
    const toInsert = steps.map((step, i) => ({ ...step, recipeId, stepNumber: i + 1 }));
    return db.insert(recipeSteps).values(toInsert).returning();
  }

  // === RECIPE INGREDIENTS ===
  async getRecipeIngredients(recipeId: number): Promise<RecipeIngredient[]> {
    return db.select().from(recipeIngredients).where(eq(recipeIngredients.recipeId, recipeId));
  }

  async setRecipeIngredients(recipeId: number, ingredients: InsertRecipeIngredient[]): Promise<RecipeIngredient[]> {
    await db.delete(recipeIngredients).where(eq(recipeIngredients.recipeId, recipeId));
    if (ingredients.length === 0) return [];
    const toInsert = ingredients.map(ing => ({ ...ing, recipeId }));
    return db.insert(recipeIngredients).values(toInsert).returning();
  }

  // === ADMINS ===
  async getAdmins(): Promise<AdminSafe[]> {
    const result = await db.select().from(admins).orderBy(desc(admins.createdAt));
    return result.map(stripPassword);
  }

  async getAdmin(id: number): Promise<Admin | undefined> {
    const [admin] = await db.select().from(admins).where(eq(admins.id, id));
    return admin;
  }

  async getAdminByUsername(username: string): Promise<Admin | undefined> {
    const [admin] = await db.select().from(admins).where(eq(admins.username, username));
    return admin;
  }

  async createAdmin(admin: InsertAdmin): Promise<AdminSafe> {
    const hashedPassword = await bcrypt.hash(admin.password, 10);
    const [newAdmin] = await db.insert(admins).values({ ...admin, password: hashedPassword }).returning();
    return stripPassword(newAdmin);
  }

  async updateAdmin(id: number, updates: Partial<InsertAdmin>): Promise<AdminSafe | undefined> {
    if (updates.password) {
      updates.password = await bcrypt.hash(updates.password, 10);
    }
    const [updated] = await db.update(admins).set(updates).where(eq(admins.id, id)).returning();
    if (!updated) return undefined;
    return stripPassword(updated);
  }

  async deleteAdmin(id: number): Promise<boolean> {
    const [deleted] = await db.delete(admins).where(eq(admins.id, id)).returning();
    return !!deleted;
  }

  async toggleAdminActive(id: number): Promise<AdminSafe | undefined> {
    const admin = await this.getAdmin(id);
    if (!admin) return undefined;
    const [updated] = await db.update(admins).set({ active: !admin.active }).where(eq(admins.id, id)).returning();
    return stripPassword(updated);
  }

  // === USER FAVORITES ===
  async getUserFavorites(userId: string): Promise<number[]> {
    const result = await db.select().from(userFavorites).where(eq(userFavorites.userId, userId));
    return result.map(f => f.recipeId);
  }

  async addFavorite(userId: string, recipeId: number): Promise<void> {
    const existing = await db.select().from(userFavorites)
      .where(and(eq(userFavorites.userId, userId), eq(userFavorites.recipeId, recipeId)));
    if (existing.length === 0) {
      await db.insert(userFavorites).values({ userId, recipeId });
    }
  }

  async removeFavorite(userId: string, recipeId: number): Promise<void> {
    await db.delete(userFavorites)
      .where(and(eq(userFavorites.userId, userId), eq(userFavorites.recipeId, recipeId)));
  }

  async getFavoriteRecipes(userId: string): Promise<RecipeWithAdmin[]> {
    const favIds = await this.getUserFavorites(userId);
    if (favIds.length === 0) return [];
    const allRecipes = await db.select().from(recipes).orderBy(desc(recipes.createdAt));
    const favRecipes = allRecipes.filter(r => favIds.includes(r.id));
    return Promise.all(favRecipes.map(r => this.enrichRecipeWithAdmin(r)));
  }

  // === SHOPPING LIST ===
  async getShoppingList(userId: string): Promise<ShoppingListItem[]> {
    return db.select().from(shoppingListItems)
      .where(eq(shoppingListItems.userId, userId))
      .orderBy(desc(shoppingListItems.createdAt));
  }

  async addShoppingItems(userId: string, items: Omit<InsertShoppingListItem, "userId">[]): Promise<ShoppingListItem[]> {
    if (items.length === 0) return [];
    const toInsert = items.map(item => ({ ...item, userId }));
    return db.insert(shoppingListItems).values(toInsert).returning();
  }

  async toggleShoppingItem(id: number, userId: string): Promise<ShoppingListItem | undefined> {
    const [item] = await db.select().from(shoppingListItems)
      .where(and(eq(shoppingListItems.id, id), eq(shoppingListItems.userId, userId)));
    if (!item) return undefined;
    const [updated] = await db.update(shoppingListItems)
      .set({ completed: !item.completed })
      .where(eq(shoppingListItems.id, id))
      .returning();
    return updated;
  }

  async removeShoppingItem(id: number, userId: string): Promise<boolean> {
    const [deleted] = await db.delete(shoppingListItems)
      .where(and(eq(shoppingListItems.id, id), eq(shoppingListItems.userId, userId)))
      .returning();
    return !!deleted;
  }

  async clearShoppingList(userId: string): Promise<void> {
    await db.delete(shoppingListItems).where(eq(shoppingListItems.userId, userId));
  }

  // === MEAL PLANS (multiple recipes per day) ===
  async getMealPlans(userId: string): Promise<MealPlan[]> {
    return db.select().from(mealPlans)
      .where(eq(mealPlans.userId, userId))
      .orderBy(asc(mealPlans.createdAt));
  }

  async addMealPlan(userId: string, dayOfWeek: string, recipeId: number): Promise<MealPlan> {
    const [plan] = await db.insert(mealPlans).values({ userId, dayOfWeek, recipeId }).returning();
    return plan;
  }

  async removeMealPlanItem(id: number, userId: string): Promise<boolean> {
    const [deleted] = await db.delete(mealPlans)
      .where(and(eq(mealPlans.id, id), eq(mealPlans.userId, userId)))
      .returning();
    return !!deleted;
  }

  async removeMealPlanDay(userId: string, dayOfWeek: string): Promise<boolean> {
    const result = await db.delete(mealPlans)
      .where(and(eq(mealPlans.userId, userId), eq(mealPlans.dayOfWeek, dayOfWeek)))
      .returning();
    return result.length > 0;
  }

  // === FAVORITES COUNT ===
  async getRecipeFavoriteCounts(): Promise<Record<number, number>> {
    const result = await db.select({
      recipeId: userFavorites.recipeId,
      count: sql<number>`count(*)::int`,
    }).from(userFavorites).groupBy(userFavorites.recipeId);
    const counts: Record<number, number> = {};
    for (const row of result) {
      counts[row.recipeId] = row.count;
    }
    return counts;
  }

  async getRecipeFavoriteCount(recipeId: number): Promise<number> {
    const [result] = await db.select({
      count: sql<number>`count(*)::int`,
    }).from(userFavorites).where(eq(userFavorites.recipeId, recipeId));
    return result?.count ?? 0;
  }

  // === RATINGS ===
  async rateRecipe(userId: string, recipeId: number, rating: number): Promise<RecipeRating> {
    const [result] = await db.insert(recipeRatings)
      .values({ userId, recipeId, rating })
      .onConflictDoUpdate({
        target: [recipeRatings.userId, recipeRatings.recipeId],
        set: { rating },
      })
      .returning();
    return result;
  }

  async getUserRating(userId: string, recipeId: number): Promise<number | null> {
    const [result] = await db.select().from(recipeRatings)
      .where(and(eq(recipeRatings.userId, userId), eq(recipeRatings.recipeId, recipeId)));
    return result?.rating ?? null;
  }

  async getRecipeAverageRating(recipeId: number): Promise<{ average: number; count: number }> {
    const [result] = await db.select({
      avg: sql<number>`COALESCE(AVG(rating), 0)`,
      count: sql<number>`count(*)::int`,
    }).from(recipeRatings).where(eq(recipeRatings.recipeId, recipeId));
    return { average: Math.round((result?.avg ?? 0) * 10) / 10, count: result?.count ?? 0 };
  }

  async getAllRecipeRatings(): Promise<Record<number, { average: number; count: number }>> {
    const result = await db.select({
      recipeId: recipeRatings.recipeId,
      avg: sql<number>`ROUND(AVG(rating)::numeric, 1)`,
      count: sql<number>`count(*)::int`,
    }).from(recipeRatings).groupBy(recipeRatings.recipeId);
    const map: Record<number, { average: number; count: number }> = {};
    for (const row of result) {
      map[row.recipeId] = { average: Number(row.avg), count: row.count };
    }
    return map;
  }

  // === AUTHORS ===
  async getUniqueAuthors(): Promise<string[]> {
    const result = await db.selectDistinct({ authorName: recipes.authorName })
      .from(recipes)
      .where(sql`${recipes.authorName} IS NOT NULL AND ${recipes.authorName} != ''`)
      .orderBy(asc(recipes.authorName));
    return result.map(r => r.authorName!).filter(Boolean);
  }

  // === INGREDIENT CATEGORIES ===
  async getIngredientCategories(): Promise<IngredientCategory[]> {
    return db.select().from(ingredientCategories).orderBy(asc(ingredientCategories.id));
  }

  async getIngredientCategoriesWithIngredients(): Promise<IngredientCategoryWithIngredients[]> {
    const cats = await this.getIngredientCategories();
    const allIngs = await db.select().from(ingredientsMaster).orderBy(asc(ingredientsMaster.displayOrder), asc(ingredientsMaster.nameHebrew));
    return cats.map(cat => ({
      ...cat,
      ingredients: allIngs.filter(ing => ing.categoryId === cat.id),
    }));
  }

  async createIngredientCategory(cat: InsertIngredientCategory): Promise<IngredientCategory> {
    const [created] = await db.insert(ingredientCategories).values(cat).returning();
    return created;
  }

  async updateIngredientCategory(id: number, cat: InsertIngredientCategory): Promise<IngredientCategory | undefined> {
    const [updated] = await db.update(ingredientCategories).set(cat).where(eq(ingredientCategories.id, id)).returning();
    return updated;
  }

  async deleteIngredientCategory(id: number): Promise<boolean> {
    await db.update(ingredientsMaster).set({ categoryId: null }).where(eq(ingredientsMaster.categoryId, id));
    const [deleted] = await db.delete(ingredientCategories).where(eq(ingredientCategories.id, id)).returning();
    return !!deleted;
  }

  // === INGREDIENTS MASTER ===
  async getIngredientsMaster(search?: string, categoryId?: number): Promise<IngredientMasterWithCategory[]> {
    let conditions: any[] = [];
    if (search) {
      conditions.push(ilike(ingredientsMaster.nameHebrew, `%${search}%`));
    }
    if (categoryId) {
      conditions.push(eq(ingredientsMaster.categoryId, categoryId));
    }

    const ings = await db.select().from(ingredientsMaster)
      .where(conditions.length > 0 ? and(...conditions) : undefined)
      .orderBy(asc(ingredientsMaster.displayOrder), asc(ingredientsMaster.nameHebrew));

    const cats = await this.getIngredientCategories();
    const catMap = new Map(cats.map(c => [c.id, c.nameHebrew]));

    return ings.map(ing => ({
      ...ing,
      categoryName: ing.categoryId ? catMap.get(ing.categoryId) : undefined,
    }));
  }

  async getIngredientMaster(id: number): Promise<IngredientMaster | undefined> {
    const [ing] = await db.select().from(ingredientsMaster).where(eq(ingredientsMaster.id, id));
    return ing;
  }

  async createIngredientMaster(ing: InsertIngredientMaster): Promise<IngredientMaster> {
    const [created] = await db.insert(ingredientsMaster).values(ing).returning();
    return created;
  }

  async updateIngredientMaster(id: number, ing: InsertIngredientMaster): Promise<IngredientMaster | undefined> {
    const [updated] = await db.update(ingredientsMaster).set(ing).where(eq(ingredientsMaster.id, id)).returning();
    return updated;
  }

  async deleteIngredientMaster(id: number): Promise<boolean> {
    await db.delete(userIngredients).where(eq(userIngredients.ingredientId, id));
    await db.update(recipeIngredients).set({ ingredientId: null }).where(eq(recipeIngredients.ingredientId, id));
    const [deleted] = await db.delete(ingredientsMaster).where(eq(ingredientsMaster.id, id)).returning();
    return !!deleted;
  }

  // === USER INGREDIENTS ===
  async getUserIngredientIds(userId: string): Promise<number[]> {
    const result = await db.select().from(userIngredients).where(eq(userIngredients.userId, userId));
    return result.map(r => r.ingredientId);
  }

  async setUserIngredients(userId: string, ingredientIds: number[]): Promise<void> {
    await db.delete(userIngredients).where(eq(userIngredients.userId, userId));
    if (ingredientIds.length > 0) {
      const values = ingredientIds.map(ingredientId => ({ userId, ingredientId }));
      await db.insert(userIngredients).values(values);
    }
  }

  async toggleUserIngredient(userId: string, ingredientId: number): Promise<boolean> {
    const existing = await db.select().from(userIngredients)
      .where(and(eq(userIngredients.userId, userId), eq(userIngredients.ingredientId, ingredientId)));
    if (existing.length > 0) {
      await db.delete(userIngredients)
        .where(and(eq(userIngredients.userId, userId), eq(userIngredients.ingredientId, ingredientId)));
      return false;
    } else {
      await db.insert(userIngredients).values({ userId, ingredientId });
      return true;
    }
  }

  // === SEED & MIGRATION ===
  async seedIngredientCategories(): Promise<void> {
    const defaultCategories = [
      "ירקות", "פירות", "בשר", "עוף", "דגים", "מוצרי חלב", "ביצים",
      "דגנים", "קטניות", "תבלינים", "שמנים", "רטבים", "אפייה", "אגוזים וזרעים", "אחר"
    ];
    const existing = await db.select().from(ingredientCategories);
    const existingNames = new Set(existing.map(c => c.nameHebrew));
    const toInsert = defaultCategories.filter(name => !existingNames.has(name));
    if (toInsert.length > 0) {
      await db.insert(ingredientCategories).values(toInsert.map(name => ({ nameHebrew: name })));
      console.log(`✔ Seeded ${toInsert.length} ingredient categories`);
    }
  }

  async migrateExistingIngredients(): Promise<void> {
    const allRecipeIngs = await db.select().from(recipeIngredients);
    const uniqueNames = new Set<string>();
    for (const ri of allRecipeIngs) {
      const name = ri.ingredientName.trim();
      if (name) uniqueNames.add(name);
    }
    const allRecipes = await db.select().from(recipes);
    for (const r of allRecipes) {
      const ings = r.ingredients as string[] | null;
      if (ings && Array.isArray(ings)) {
        for (const ing of ings) {
          const name = ing.trim();
          if (name) uniqueNames.add(name);
        }
      }
    }
    if (uniqueNames.size > 0) {
      const cats = await db.select().from(ingredientCategories);
      const otherCat = cats.find(c => c.nameHebrew === "אחר");
      const categoryId = otherCat?.id || null;
      for (const name of Array.from(uniqueNames)) {
        try {
          await db.insert(ingredientsMaster).values({ nameHebrew: name, categoryId }).onConflictDoNothing();
        } catch (e) {}
      }
    }
    const masterList = await db.select().from(ingredientsMaster);
    const nameToId = new Map(masterList.map(m => [m.nameHebrew, m.id]));
    for (const ri of allRecipeIngs) {
      const masterId = nameToId.get(ri.ingredientName.trim());
      if (masterId && !ri.ingredientId) {
        await db.update(recipeIngredients).set({ ingredientId: masterId }).where(eq(recipeIngredients.id, ri.id));
      }
    }
  }

  async seedFullIngredientList(): Promise<void> {
    const cats = await db.select().from(ingredientCategories);
    const catMap = new Map(cats.map(c => [c.nameHebrew, c.id]));

    const ingredientData: { category: string; items: { name: string; subcategory?: string }[] }[] = [
      {
        category: "ירקות",
        items: [
          { name: "עגבניות" }, { name: "מלפפונים" }, { name: "בצל" }, { name: "בצל סגול" },
          { name: "שום" }, { name: "גזר" }, { name: "תפוחי אדמה" }, { name: "בטטה" },
          { name: "פלפל ירוק" }, { name: "פלפל אדום" }, { name: "פלפל צהוב" }, { name: "פלפל חריף" },
          { name: "חציל" }, { name: "קישוא" }, { name: "כרובית" }, { name: "ברוקולי" },
          { name: "כרוב לבן" }, { name: "כרוב סגול" }, { name: "חסה" }, { name: "תרד" },
          { name: "פטרוזיליה" }, { name: "כוסברה" }, { name: "שמיר" }, { name: "נענע" },
          { name: "בזיליקום" }, { name: "סלרי" }, { name: "שעועית ירוקה" }, { name: "אפונה" },
          { name: "תירס" }, { name: "פטריות" }, { name: "צנון" }, { name: "סלק" },
          { name: "דלעת" }, { name: "ארטישוק" }, { name: "אספרגוס" }, { name: "קולורבי" },
          { name: "לפת" }, { name: "רוקט" }, { name: "עירית" }, { name: "כרישה" },
          { name: "שאלוט" },
        ],
      },
      {
        category: "פירות",
        items: [
          { name: "תפוח" }, { name: "בננה" }, { name: "תפוז" }, { name: "לימון" },
          { name: "ליים" }, { name: "אשכולית" }, { name: "קלמנטינה" }, { name: "ענבים" },
          { name: "תות שדה" }, { name: "אוכמניות" }, { name: "פטל" }, { name: "אבטיח" },
          { name: "מלון" }, { name: "אננס" }, { name: "מנגו" }, { name: "אבוקדו" },
          { name: "אפרסק" }, { name: "נקטרינה" }, { name: "שזיף" }, { name: "דובדבן" },
          { name: "אגס" }, { name: "רימון" }, { name: "תמר" }, { name: "תאנה" },
          { name: "פסיפלורה" }, { name: "קיווי" }, { name: "פפאיה" }, { name: "חבוש" },
          { name: "לוקט" }, { name: "משמש" }, { name: "קוקוס" },
        ],
      },
      {
        category: "בשר",
        items: [
          { name: "1 - צוואר", subcategory: "נתחי בקר" },
          { name: "2 - צלעות", subcategory: "נתחי בקר" },
          { name: "3 - חזה", subcategory: "נתחי בקר" },
          { name: "4 - כתף", subcategory: "נתחי בקר" },
          { name: "5 - צ׳אק", subcategory: "נתחי בקר" },
          { name: "6 - פילה מדומה", subcategory: "נתחי בקר" },
          { name: "7 - כיסוי צלעות", subcategory: "נתחי בקר" },
          { name: "8 - שוק קדמי", subcategory: "נתחי בקר" },
          { name: "9 - שוק אחורי", subcategory: "נתחי בקר" },
          { name: "10 - שריר הצוואר", subcategory: "נתחי בקר" },
          { name: "11 - סינטה", subcategory: "נתחי בקר" },
          { name: "12 - פילה", subcategory: "נתחי בקר" },
          { name: "13 - שייטל", subcategory: "נתחי בקר" },
          { name: "14 - קילו", subcategory: "נתחי בקר" },
          { name: "15 - צלי כתף", subcategory: "נתחי בקר" },
          { name: "16 - פיקניה", subcategory: "נתחי בקר" },
          { name: "17 - עין הכתף", subcategory: "נתחי בקר" },
          { name: "18 - סילבר סייד", subcategory: "נתחי בקר" },
          { name: "19 - טרי טיפ", subcategory: "נתחי בקר" },
          { name: "בשר טחון", subcategory: "טחון" },
          { name: "קבב", subcategory: "טחון" },
          { name: "המבורגר", subcategory: "טחון" },
          { name: "נקניקיות בקר", subcategory: "מוצרי בשר" },
          { name: "פסטרמה", subcategory: "מוצרי בשר" },
          { name: "בשר כבש", subcategory: "כבש" },
          { name: "צלעות כבש", subcategory: "כבש" },
          { name: "כתף כבש", subcategory: "כבש" },
          { name: "שוק כבש", subcategory: "כבש" },
        ],
      },
      {
        category: "עוף",
        items: [
          { name: "חזה עוף" }, { name: "שוק עוף" }, { name: "כנפיים" },
          { name: "עוף שלם" }, { name: "ירכיים עוף" }, { name: "כבד עוף" },
          { name: "עוף טחון" }, { name: "חזה הודו" }, { name: "שניצל עוף" },
          { name: "שניצל הודו" }, { name: "פרגיות" }, { name: "צוואר עוף" },
        ],
      },
      {
        category: "דגים",
        items: [
          { name: "סלמון" }, { name: "טונה" }, { name: "דניס" }, { name: "לברק" },
          { name: "אמנון (מושט)" }, { name: "נסיכה" }, { name: "בורי" }, { name: "קוד" },
          { name: "פילה דג לבן" },
          { name: "סרדינים" }, { name: "מקרל" }, { name: "פורל" },
          { name: "טונה בקופסה" }, { name: "דג מעושן" },
        ],
      },
      {
        category: "מוצרי חלב",
        items: [
          { name: "חלב" }, { name: "שמנת מתוקה" }, { name: "שמנת חמוצה" },
          { name: "גבינה לבנה" }, { name: "גבינה צהובה" }, { name: "גבינת שמנת" },
          { name: "קוטג׳" }, { name: "לבן" }, { name: "יוגורט" },
          { name: "מוצרלה" }, { name: "פרמזן" }, { name: "גבינת פטה" },
          { name: "גבינת ריקוטה" }, { name: "גבינת עיזים" }, { name: "חמאה" },
          { name: "מרגרינה" }, { name: "גבינת צפתית" }, { name: "גבינת בולגרית" },
          { name: "חלב קוקוס" }, { name: "חלב שקדים" }, { name: "חלב סויה" },
        ],
      },
      {
        category: "ביצים",
        items: [
          { name: "ביצים" }, { name: "ביצי שליו" },
        ],
      },
      {
        category: "דגנים",
        items: [
          { name: "אורז לבן" }, { name: "אורז בסמטי" }, { name: "אורז מלא" },
          { name: "פסטה" }, { name: "קוסקוס" }, { name: "בורגול" },
          { name: "קינואה" }, { name: "שיבולת שועל" }, { name: "חיטה" },
          { name: "קמח לבן" }, { name: "קמח מלא" }, { name: "קמח תירס" },
          { name: "פתיתים" }, { name: "לחם" }, { name: "פיתות" },
          { name: "טורטיה" }, { name: "לחמניות" }, { name: "פירורי לחם" },
          { name: "מצות" }, { name: "אטריות אורז" }, { name: "נודלס" },
          { name: "גריסים" }, { name: "פולנטה" },
        ],
      },
      {
        category: "קטניות",
        items: [
          { name: "חומוס" }, { name: "עדשים כתומות" }, { name: "עדשים ירוקות" },
          { name: "שעועית לבנה" }, { name: "שעועית אדומה" }, { name: "שעועית שחורה" },
          { name: "פול" }, { name: "אדממה" }, { name: "חומוס מוכן" },
          { name: "טחינה" }, { name: "טחינה גולמית" },
        ],
      },
      {
        category: "תבלינים",
        items: [
          { name: "מלח" }, { name: "פלפל שחור" }, { name: "כורכום" },
          { name: "פפריקה" }, { name: "פפריקה מעושנת" }, { name: "כמון" },
          { name: "קינמון" }, { name: "זנגביל טחון" }, { name: "זנגביל טרי" },
          { name: "שום טחון" }, { name: "בצל טחון" }, { name: "כוסברה טחונה" },
          { name: "אורגנו" }, { name: "טימין" }, { name: "רוזמרין" },
          { name: "מרווה" }, { name: "עלי דפנה" }, { name: "ציפורן" },
          { name: "כמון שחור" }, { name: "חילבה" }, { name: "סומאק" },
          { name: "זעתר" }, { name: "בהרט" }, { name: "הוואייג׳" },
          { name: "חריף" }, { name: "תבלין למרק" }, { name: "תבלין לאורז" },
          { name: "פלפל לבן" }, { name: "אגוז מוסקט" }, { name: "קרדמון" },
          { name: "כרכום" },
        ],
      },
      {
        category: "שמנים",
        items: [
          { name: "שמן זית" }, { name: "שמן זית כתית מעולה" },
          { name: "שמן קנולה" }, { name: "שמן חמניות" },
          { name: "שמן שומשום" }, { name: "שמן קוקוס" },
          { name: "ספריי שמן" },
        ],
      },
      {
        category: "רטבים",
        items: [
          { name: "רסק עגבניות" }, { name: "עגבניות מרוסקות" },
          { name: "עגבניות חתוכות בקופסה" }, { name: "סויה" },
          { name: "חרדל" }, { name: "מיונז" }, { name: "קטשופ" },
          { name: "חומץ" }, { name: "חומץ בלסמי" }, { name: "חומץ תפוחים" },
          { name: "יין אדום לבישול" }, { name: "יין לבן לבישול" },
          { name: "רוטב צ׳ילי מתוק" }, { name: "רוטב טריאקי" },
          { name: "שמן שומשום קלוי" }, { name: "רוטב חריף" },
          { name: "דבש" }, { name: "סילאן" }, { name: "מייפל" },
          { name: "רוטב פסטו" }, { name: "רוטב ברביקיו" },
        ],
      },
      {
        category: "אפייה",
        items: [
          { name: "סוכר" }, { name: "סוכר חום" }, { name: "סוכר דמררה" },
          { name: "סוכר דקורטיבי" }, { name: "אבקת אפייה" }, { name: "סודה לשתייה" },
          { name: "שמרים יבשים" }, { name: "שמרים טריים" }, { name: "קקאו" },
          { name: "שוקולד מריר" }, { name: "שוקולד חלב" }, { name: "שוקולד לבן" },
          { name: "שבבי שוקולד" }, { name: "וניל" }, { name: "תמצית וניל" },
          { name: "חלב מרוכז" }, { name: "קורנפלור" }, { name: "ג׳לטין" },
          { name: "אינסטנט פודינג" }, { name: "ביסקוויטים" },
          { name: "עלי פילו" }, { name: "בצק עלים" }, { name: "בצק פריך" },
          { name: "קצפת" }, { name: "ריבה" },
        ],
      },
      {
        category: "אגוזים וזרעים",
        items: [
          { name: "שקדים" }, { name: "אגוזי מלך" }, { name: "אגוזי קשיו" },
          { name: "אגוזי לוז" }, { name: "בוטנים" }, { name: "פקאן" },
          { name: "פיסטוק" }, { name: "צנוברים" }, { name: "שומשום" },
          { name: "זרעי חמניה" }, { name: "זרעי דלעת" }, { name: "זרעי צ׳יה" },
          { name: "זרעי פשתן" }, { name: "חמאת בוטנים" }, { name: "טחינה מלאה" },
        ],
      },
      {
        category: "אחר",
        items: [
          { name: "מרק עוף (אבקה/קוביות)" }, { name: "מרק ירקות (אבקה/קוביות)" },
          { name: "זיתים ירוקים" }, { name: "זיתים שחורים" },
          { name: "לימון כבוש" }, { name: "חמוצים" }, { name: "קפרס" },
          { name: "טופו" }, { name: "תמרים מג׳הול" }, { name: "חלבה" },
          { name: "צימוקים" }, { name: "חמוציות" }, { name: "משמש מיובש" },
        ],
      },
    ];

    let insertedCount = 0;
    for (const group of ingredientData) {
      const categoryId = catMap.get(group.category) || null;
      for (let i = 0; i < group.items.length; i++) {
        const item = group.items[i];
        try {
          await db.insert(ingredientsMaster).values({
            nameHebrew: item.name,
            categoryId,
            subcategory: item.subcategory || null,
            displayOrder: i + 1,
          }).onConflictDoNothing();
          insertedCount++;
        } catch (e) {}
      }
    }
    if (insertedCount > 0) {
      console.log(`✔ Seeded ${insertedCount} master ingredients`);
    }
  }

  async seedDefaultAdmin(): Promise<void> {
    const existing = await this.getAdminByUsername("admin");
    if (!existing) {
      const hashedPassword = await bcrypt.hash("1234", 10);
      await db.insert(admins).values({
        username: "admin",
        password: hashedPassword,
        role: "super_admin",
        active: true,
        forcePasswordChange: true,
      });
      console.log("✔ Default super admin created (username: admin, password: 1234)");
    } else {
      const canLogin = await bcrypt.compare("1234", existing.password);
      if (!canLogin || !existing.active) {
        const hashedPassword = await bcrypt.hash("1234", 10);
        await db.update(admins)
          .set({
            password: hashedPassword,
            active: true,
            forcePasswordChange: true,
            role: "super_admin",
          })
          .where(eq(admins.username, "admin"));
        console.log("✔ Default super admin password reset to 1234");
      } else {
        console.log("✔ Default super admin exists and is ready");
      }
    }
  }
}

export const storage = new DatabaseStorage();
